extends Node3D
# Builds the Dark Forest map, player, creature and HUD at runtime. Attached to main.tscn.
# World layout: spawn at +Z, cabin at origin (door on +Z side), exit gate at -Z.

const HALF := 90.0
const TREES := 360
const FOG := Color(0.09, 0.12, 0.16)

const PTex = preload("res://scripts/ptex.gd")
const UIScript = preload("res://scripts/ui.gd")
const PlayerScript = preload("res://scripts/player.gd")
const CreatureScript = preload("res://scripts/creature.gd")
const PickupScript = preload("res://scripts/pickup.gd")
const HideScript = preload("res://scripts/hidespot.gd")

var m_ground: StandardMaterial3D
var m_path: StandardMaterial3D
var m_bark: StandardMaterial3D
var m_dead: StandardMaterial3D
var m_leaf: StandardMaterial3D
var m_wood: StandardMaterial3D
var m_floor: StandardMaterial3D
var m_dark: StandardMaterial3D
var m_roof: StandardMaterial3D
var m_stone: StandardMaterial3D
var m_metal: StandardMaterial3D
var flick := []
var gate_pos := Vector3(0, 1, -(HALF - 4.0))
var gate_msg_t := 0.0
var moon_light: DirectionalLight3D
var moon_mesh: MeshInstance3D
var moon_halo: MeshInstance3D

func _ready():
    randomize()
    Game.reset()
    _materials()
    _env()
    add_child(UIScript.new())
    _ground()
    _trees()
    _rocks_logs()
    _cabin()
    _car(Vector3(7, 0, 62), 200.0)
    _gate()
    _bounds()

    var pl := PlayerScript.new()
    pl.position = Vector3(0, 0.1, HALF - 10.0)
    add_child(pl)
    _mist(pl)
    _vignette()

    _scatter()
    var cr := CreatureScript.new()
    cr.position = Vector3(35, 0, -35)
    add_child(cr)

    var wind := AudioStreamPlayer.new()
    wind.stream = Game.s_wind
    wind.volume_db = linear_to_db(0.3)
    add_child(wind)
    wind.play()
    Game.refresh_objective()

func _process(_d):
    var t := Time.get_ticks_msec() * 0.001
    for f in flick:
        var n := 0.5 + 0.25 * sin(t * 7.0 + f[2]) + 0.25 * sin(t * 13.1 + f[2] * 1.7)
        f[0].light_energy = f[1] * (0.15 if n < 0.25 else 0.7 + 0.3 * n)
    var p = Game.player
    if p != null:
        var dir: Vector3 = moon_light.global_transform.basis.z
        moon_mesh.global_position = p.global_position + dir * 110.0
        moon_halo.global_position = moon_mesh.global_position
        if not Game.over and p.global_position.distance_to(gate_pos) < 4.0:
            if Game.keys >= Game.keys_needed:
                Game.win()
            elif t > gate_msg_t:
                gate_msg_t = t + 3.0
                Game.toast("The gate is locked. Keys: %d/%d" % [Game.keys, Game.keys_needed])

# ---------- materials ----------
func _plain(c: Color, rough := 0.9, metal := 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = rough
    m.metallic = metal
    return m

func _emit(c: Color, energy := 2.0, unshaded := false) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.emission_enabled = true
    m.emission = c
    m.emission_energy_multiplier = energy
    if unshaded:
        m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    return m

func _materials():
    m_ground = PTex.material(PTex.img_ground(), Color(0.2, 0.23, 0.17), 0.18, 5.0)
    m_path = PTex.material(PTex.img_ground(), Color(0.36, 0.28, 0.2), 0.3, 5.0)
    m_bark = PTex.material(PTex.img_bark(), Color(0.34, 0.28, 0.25), 0.8, 4.0)
    m_dead = PTex.material(PTex.img_bark(), Color(0.28, 0.25, 0.24), 0.8, 4.0)
    m_leaf = PTex.material(PTex.img_ground(), Color(0.07, 0.16, 0.12), 0.5, 3.0)
    m_wood = PTex.material(PTex.img_wood(), Color(0.66, 0.52, 0.42), 0.45, 5.0)
    m_floor = PTex.material(PTex.img_wood(), Color(0.4, 0.32, 0.26), 0.5, 5.0)
    m_dark = PTex.material(PTex.img_wood(), Color(0.3, 0.22, 0.17), 0.6, 5.0)
    m_roof = PTex.material(PTex.img_shingle(), Color(0.42, 0.38, 0.38), 0.6, 6.0)
    m_stone = PTex.material(PTex.img_stone(), Color(0.5, 0.5, 0.54), 0.6, 6.0)
    m_metal = _plain(Color(0.14, 0.12, 0.12), 0.5, 0.6)

func _env():
    var e := Environment.new()
    e.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sm := ProceduralSkyMaterial.new()
    sm.sky_top_color = Color(0.02, 0.035, 0.08)
    sm.sky_horizon_color = Color(0.1, 0.14, 0.2)
    sm.ground_horizon_color = Color(0.08, 0.11, 0.15)
    sm.ground_bottom_color = Color(0.03, 0.04, 0.05)
    sky.sky_material = sm
    e.sky = sky
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color(0.2, 0.26, 0.38)
    e.ambient_light_energy = 1.0
    e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    e.tonemap_exposure = 1.25
    e.fog_enabled = true
    e.fog_light_color = FOG
    e.fog_density = 0.022
    e.fog_sky_affect = 0.4
    e.glow_enabled = true
    e.glow_intensity = 0.8
    e.glow_bloom = 0.05
    e.glow_hdr_threshold = 0.8
    var we := WorldEnvironment.new()
    we.environment = e
    add_child(we)
    moon_light = DirectionalLight3D.new()
    moon_light.light_color = Color(0.5, 0.6, 0.9)
    moon_light.light_energy = 0.7
    moon_light.rotation_degrees = Vector3(-50, -30, 0)
    add_child(moon_light)
    var mm := _emit(Color(0.9, 0.93, 1.0), 1.5, true)
    mm.disable_fog = true
    moon_mesh = MeshInstance3D.new()
    var sp := SphereMesh.new()
    sp.radius = 4.0
    sp.height = 8.0
    moon_mesh.mesh = sp
    moon_mesh.material_override = mm
    moon_mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(moon_mesh)
    moon_halo = MeshInstance3D.new()
    var sp2 := SphereMesh.new()
    sp2.radius = 10.0
    sp2.height = 20.0
    moon_halo.mesh = sp2
    var hm := StandardMaterial3D.new()
    hm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    hm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    hm.albedo_color = Color(0.45, 0.6, 0.95, 0.1)
    hm.disable_fog = true
    moon_halo.material_override = hm
    moon_halo.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(moon_halo)

# ---------- helpers ----------
func _box(parent: Node, pos: Vector3, size: Vector3, mat: Material, collide := true, rot := Vector3.ZERO) -> Node3D:
    var body: Node3D
    if collide:
        body = StaticBody3D.new()
    else:
        body = Node3D.new()
    body.position = pos
    body.rotation_degrees = rot
    parent.add_child(body)
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = mat
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if collide else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    body.add_child(mi)
    if collide:
        var cs := CollisionShape3D.new()
        var sh := BoxShape3D.new()
        sh.size = size
        cs.shape = sh
        body.add_child(cs)
    return body

func _mesh_at(parent: Node, mesh: Mesh, pos: Vector3, mat: Material, rot := Vector3.ZERO) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    mi.position = pos
    mi.rotation_degrees = rot
    mi.material_override = mat
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(mi)
    return mi

func _cyl(r: float, h: float, seg := 12) -> CylinderMesh:
    var c := CylinderMesh.new()
    c.top_radius = r
    c.bottom_radius = r
    c.height = h
    c.radial_segments = seg
    c.rings = 1
    return c

# ---------- ground ----------
func _ground():
    var g := StaticBody3D.new()
    add_child(g)
    var cs := CollisionShape3D.new()
    cs.shape = WorldBoundaryShape3D.new()
    g.add_child(cs)
    var tiles := 6
    var ts := HALF * 2.0 / tiles
    for ix in tiles:
        for iz in tiles:
            var pm := PlaneMesh.new()
            pm.size = Vector2(ts, ts)
            var mi := MeshInstance3D.new()
            mi.mesh = pm
            mi.material_override = m_ground
            mi.position = Vector3(-HALF + ts * (ix + 0.5), 0, -HALF + ts * (iz + 0.5))
            mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
            g.add_child(mi)
    _box(self, Vector3(0, 0.02, 0), Vector3(4, 0.02, HALF * 2.0), m_path, false)

# ---------- trees ----------
func _pine_mesh() -> ArrayMesh:
    var tr := SurfaceTool.new()
    tr.begin(Mesh.PRIMITIVE_TRIANGLES)
    var cm := CylinderMesh.new()
    cm.top_radius = 0.014
    cm.bottom_radius = 0.028
    cm.height = 1.0
    cm.radial_segments = 7
    cm.rings = 1
    tr.append_from(cm, 0, Transform3D(Basis(), Vector3(0, 0.5, 0)))
    var am: ArrayMesh = tr.commit()
    var fo := SurfaceTool.new()
    fo.begin(Mesh.PRIMITIVE_TRIANGLES)
    for i in 5:
        var c := CylinderMesh.new()
        c.top_radius = 0.0
        c.bottom_radius = 0.24 - i * 0.038
        c.height = 0.3
        c.radial_segments = 8
        c.rings = 1
        fo.append_from(c, 0, Transform3D(Basis(), Vector3(0, 0.24 + i * 0.16 + 0.15, 0)))
    fo.commit(am)
    am.surface_set_material(0, m_bark)
    am.surface_set_material(1, m_leaf)
    return am

func _dead_mesh() -> ArrayMesh:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var cm := CylinderMesh.new()
    cm.top_radius = 0.006
    cm.bottom_radius = 0.03
    cm.height = 1.0
    cm.radial_segments = 6
    cm.rings = 1
    st.append_from(cm, 0, Transform3D(Basis(), Vector3(0, 0.5, 0)))
    for i in 9:
        var y := 0.3 + i * 0.07
        var ln := 0.28 - i * 0.02
        var b := Basis(Vector3.UP, randf() * TAU) * Basis(Vector3.RIGHT, deg_to_rad(randf_range(35.0, 65.0)))
        var br := CylinderMesh.new()
        br.top_radius = 0.001
        br.bottom_radius = 0.008 - i * 0.0005
        br.height = ln
        br.radial_segments = 4
        br.rings = 1
        var dir: Vector3 = b * Vector3.UP
        st.append_from(br, 0, Transform3D(b, Vector3(0, y, 0) + dir * ln * 0.5))
    var am: ArrayMesh = st.commit()
    am.surface_set_material(0, m_dead)
    return am

func _trees():
    var pts := []
    var tries := 0
    while pts.size() < TREES and tries < 4000:
        tries += 1
        var p := Vector2(randf_range(-HALF, HALF), randf_range(-HALF, HALF))
        if absf(p.x) < 4.0 or p.length() < 16.0 or p.distance_to(Vector2(7, 62)) < 6.0:
            continue
        pts.append(p)
    var groups := [[], [], []]
    for i in pts.size():
        var gi := 0
        if i % 9 >= 7:
            gi = 2
        elif i % 9 >= 5:
            gi = 1
        groups[gi].append(pts[i])
    var meshes := [_pine_mesh(), _dead_mesh(), _dead_mesh()]
    var body := StaticBody3D.new()
    add_child(body)
    for g in 3:
        var arr: Array = groups[g]
        var mm := MultiMesh.new()
        mm.transform_format = MultiMesh.TRANSFORM_3D
        mm.mesh = meshes[g]
        mm.instance_count = arr.size()
        for i in arr.size():
            var p: Vector2 = arr[i]
            var h := randf_range(12.0, 20.0) if g == 0 else randf_range(14.0, 24.0)
            var sx := h * randf_range(0.8, 1.2)
            var b := Basis(Vector3.UP, randf() * TAU) * Basis.from_scale(Vector3(sx, h, sx))
            mm.set_instance_transform(i, Transform3D(b, Vector3(p.x, 0, p.y)))
            var cs := CollisionShape3D.new()
            var sh := CylinderShape3D.new()
            sh.radius = 0.4
            sh.height = h
            cs.shape = sh
            cs.position = Vector3(p.x, h / 2.0, p.y)
            body.add_child(cs)
        var inst := MultiMeshInstance3D.new()
        inst.multimesh = mm
        inst.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
        add_child(inst)

func _rocks_logs():
    var count := 150
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_3D
    var sp := SphereMesh.new()
    sp.radial_segments = 8
    sp.rings = 4
    mm.mesh = sp
    mm.instance_count = count
    for i in count:
        var p := Vector2(randf_range(-HALF + 3, HALF - 3), randf_range(-HALF + 3, HALF - 3))
        if absf(p.x) < 2.5:
            p.x += 5.0
        var s := Vector3(randf_range(0.4, 1.4), randf_range(0.3, 0.8), randf_range(0.4, 1.4))
        var b := Basis(Vector3.UP, randf() * TAU) * Basis.from_scale(s)
        mm.set_instance_transform(i, Transform3D(b, Vector3(p.x, s.y * 0.15, p.y)))
    var inst := MultiMeshInstance3D.new()
    inst.multimesh = mm
    inst.material_override = m_stone
    add_child(inst)
    for i in 28:
        var p := Vector3(randf_range(-HALF + 5, HALF - 5), 0, randf_range(-HALF + 5, HALF - 5))
        if absf(p.x) < 3.5 or Vector2(p.x, p.z).length() < 14.0:
            continue
        var r := randf_range(0.22, 0.4)
        var ln := randf_range(3.0, 6.0)
        var lg := StaticBody3D.new()
        lg.position = Vector3(p.x, r * 0.8, p.z)
        lg.rotation_degrees = Vector3(0, randf() * 360.0, 90)
        add_child(lg)
        _mesh_at(lg, _cyl(r, ln, 8), Vector3.ZERO, m_bark)
        var cs := CollisionShape3D.new()
        var sh := CylinderShape3D.new()
        sh.radius = r
        sh.height = ln
        cs.shape = sh
        lg.add_child(cs)

# ---------- cabin ----------
func _prism(parent: Node, pos: Vector3, size: Vector3, mat: Material):
    var pm := PrismMesh.new()
    pm.size = size
    _mesh_at(parent, pm, pos, mat)

func _pane(parent: Node, pos: Vector3, yaw: float, size: Vector2):
    var q := QuadMesh.new()
    q.size = size
    var mi := _mesh_at(parent, q, pos, _emit(Color(1.0, 0.6, 0.25), 2.2, true), Vector3(0, yaw, 0))
    var f := _plain(Color(0.08, 0.05, 0.03))
    _box(mi, Vector3(0, size.y / 2.0 + 0.04, 0.0), Vector3(size.x + 0.2, 0.08, 0.08), f, false)
    _box(mi, Vector3(0, -size.y / 2.0 - 0.04, 0.0), Vector3(size.x + 0.2, 0.08, 0.08), f, false)
    _box(mi, Vector3(0, 0, 0.01), Vector3(0.06, size.y, 0.04), f, false)
    _box(mi, Vector3(0, 0, 0.01), Vector3(size.x, 0.06, 0.04), f, false)

func _chair(parent: Node, pos: Vector3, yaw: float, tip := 0.0):
    var c := Node3D.new()
    c.position = pos
    c.rotation_degrees = Vector3(tip, yaw, 0)
    parent.add_child(c)
    _box(c, Vector3(0, 0.45, 0), Vector3(0.5, 0.06, 0.5), m_wood, false)
    _box(c, Vector3(0, 0.78, 0.22), Vector3(0.5, 0.6, 0.05), m_wood, false)
    for o in [Vector2(-0.2, -0.2), Vector2(0.2, -0.2), Vector2(-0.2, 0.2), Vector2(0.2, 0.2)]:
        _box(c, Vector3(o.x, 0.22, o.y), Vector3(0.05, 0.44, 0.05), m_dark, false)

func _cabin():
    var c := Node3D.new()
    c.name = "Cabin"
    add_child(c)
    _box(c, Vector3(0, 0.03, 0), Vector3(10.6, 0.04, 8.6), m_floor, false)
    _box(c, Vector3(0, 1.5, -4.15), Vector3(10.6, 3, 0.3), m_wood)
    _box(c, Vector3(-5.15, 1.5, 0), Vector3(0.3, 3, 8.6), m_wood)
    _box(c, Vector3(5.15, 1.5, 0), Vector3(0.3, 3, 8.6), m_wood)
    _box(c, Vector3(-3.1, 1.5, 4.15), Vector3(4.4, 3, 0.3), m_wood)
    _box(c, Vector3(3.1, 1.5, 4.15), Vector3(4.4, 3, 0.3), m_wood)
    _box(c, Vector3(0, 2.7, 4.15), Vector3(1.8, 0.6, 0.3), m_wood)
    # gabled roof + gable ends
    _prism(c, Vector3(0, 4.55, -4.15), Vector3(10.6, 3.1, 0.3), m_wood)
    _prism(c, Vector3(0, 4.55, 4.15), Vector3(10.6, 3.1, 0.3), m_wood)
    _box(c, Vector3(-2.9, 4.55, 0), Vector3(6.6, 0.22, 9.8), m_roof, false, Vector3(0, 0, 28))
    _box(c, Vector3(2.9, 4.55, 0), Vector3(6.6, 0.22, 9.8), m_roof, false, Vector3(0, 0, -28))
    _box(c, Vector3(0, 6.1, 0), Vector3(0.3, 0.2, 9.9), m_dark, false)
    # porch
    _box(c, Vector3(0, 0.03, 5.6), Vector3(6, 0.06, 2.6), m_floor, false)
    _box(c, Vector3(-2.7, 1.5, 6.7), Vector3(0.25, 3, 0.25), m_dark)
    _box(c, Vector3(2.7, 1.5, 6.7), Vector3(0.25, 3, 0.25), m_dark)
    _box(c, Vector3(0, 3.05, 5.6), Vector3(6.4, 0.15, 3.0), m_roof, false, Vector3(10, 0, 0))
    # chimney
    _box(c, Vector3(5.9, 3.5, -1.0), Vector3(1.0, 7.0, 1.0), m_stone)
    # open door
    var hinge := Node3D.new()
    hinge.position = Vector3(-0.9, 0, 4.15)
    hinge.rotation_degrees.y = -70.0
    c.add_child(hinge)
    _box(hinge, Vector3(0.45, 1.15, 0), Vector3(0.9, 2.3, 0.08), m_dark)
    # glowing windows
    _pane(c, Vector3(-3.2, 1.7, 4.32), 0.0, Vector2(1.0, 1.1))
    _pane(c, Vector3(3.2, 1.7, 4.32), 0.0, Vector2(1.0, 1.1))
    _pane(c, Vector3(-5.32, 1.7, -1.0), -90.0, Vector2(1.0, 1.1))
    # interior light
    var lg := OmniLight3D.new()
    lg.position = Vector3(0, 2.6, 0)
    lg.light_color = Color(1.0, 0.7, 0.35)
    lg.omni_range = 9.0
    lg.light_energy = 1.2
    c.add_child(lg)
    flick.append([lg, 1.2, randf() * 50.0])
    # table (hide under) + document + lantern
    _box(c, Vector3(-2, 0.8, -1.5), Vector3(1.8, 0.1, 1.0), m_wood, false)
    for o in [Vector2(-0.8, -0.4), Vector2(0.8, -0.4), Vector2(-0.8, 0.4), Vector2(0.8, 0.4)]:
        _box(c, Vector3(-2 + o.x, 0.4, -1.5 + o.y), Vector3(0.1, 0.8, 0.1), m_dark, false)
    _hide(c, Vector3(-2, 0.4, -1.5), Vector3(-2, 0.4, -1.5), 0.0, Vector3(-2, 0.0, -0.1), 180.0)
    _box(c, Vector3(-2.6, 0.95, -1.7), Vector3(0.14, 0.2, 0.14), _emit(Color(1, 0.6, 0.2), 2.0, true), false)
    var ll := OmniLight3D.new()
    ll.position = Vector3(-2.6, 1.2, -1.7)
    ll.light_color = Color(1, 0.65, 0.3)
    ll.omni_range = 6.0
    ll.light_energy = 0.9
    c.add_child(ll)
    flick.append([ll, 0.9, randf() * 50.0])
    _chair(c, Vector3(-2, 0, -0.5), 180.0)
    _chair(c, Vector3(-0.6, 0.25, -1.9), 70.0, 80.0)
    # bed (hide under)
    _box(c, Vector3(3.6, 0.6, -2.8), Vector3(2, 0.2, 1), m_dark, false)
    _box(c, Vector3(4.35, 0.76, -2.8), Vector3(0.5, 0.12, 0.38), _plain(Color(0.6, 0.58, 0.5)), false)
    _box(c, Vector3(3.2, 0.73, -2.8), Vector3(1.2, 0.06, 0.95), _plain(Color(0.25, 0.08, 0.07)), false)
    for o in [Vector2(-0.95, -0.45), Vector2(0.95, -0.45), Vector2(-0.95, 0.45), Vector2(0.95, 0.45)]:
        _box(c, Vector3(3.6 + o.x, 0.3, -2.8 + o.y), Vector3(0.1, 0.6, 0.1), m_dark, false)
    _hide(c, Vector3(3.6, 0.3, -2.8), Vector3(3.6, 0.3, -2.8), 180.0, Vector3(3.6, 0.0, -1.2), 180.0)
    # wardrobe (hide inside)
    _box(c, Vector3(-4.2, 1.2, -3.5), Vector3(1.3, 2.4, 0.7), m_dark)
    _box(c, Vector3(-4.2, 1.2, -3.14), Vector3(0.02, 2.2, 0.02), _plain(Color(0.02, 0.02, 0.02)), false)
    _hide(c, Vector3(-4.2, 1.2, -3.5), Vector3(-4.2, 1.5, -3.5), 180.0, Vector3(-4.2, 0.0, -2.4), 180.0)
    # stove + shelf with key
    var st := _mesh_at(c, _cyl(0.45, 1.0, 12), Vector3(-4.4, 0.5, 1.0), m_metal)
    var sb := StaticBody3D.new()
    st.add_child(sb)
    var scs := CollisionShape3D.new()
    scs.shape = CylinderShape3D.new()
    sb.add_child(scs)
    _box(c, Vector3(4.7, 1.0, 1.5), Vector3(0.6, 0.1, 1.4), m_wood)
    _item("key", Vector3(4.6, 1.3, 1.5))
    _item("doc", Vector3(-2, 0.95, -1.5), "Note: \"It only walks when it thinks the woods are empty. Do not run in the dark.\"")
    _item("battery", Vector3(-4.5, 0.3, 3.0))
    _item("battery", Vector3(2.0, 0.3, -3.3))
    _item("medkit", Vector3(0.5, 0.3, -3.4))

func _hide(parent: Node, pos: Vector3, cam_pos: Vector3, cam_yaw: float, exit_pos: Vector3, exit_yaw: float):
    var h := HideScript.new()
    h.position = pos
    h.cam_pos = cam_pos
    h.cam_yaw = cam_yaw
    h.exit_pos = exit_pos
    h.exit_yaw = exit_yaw
    parent.add_child(h)

# ---------- abandoned car (headlights on) ----------
func _car(pos: Vector3, yaw: float):
    var c := Node3D.new()
    c.position = pos
    c.rotation_degrees.y = yaw
    add_child(c)
    var paint := _plain(Color(0.08, 0.1, 0.15), 0.35, 0.5)
    var glass := _plain(Color(0.02, 0.03, 0.05), 0.1, 0.2)
    _box(c, Vector3(0, 0.7, 0), Vector3(1.9, 0.65, 4.8), paint)
    _box(c, Vector3(0, 1.28, 0.3), Vector3(1.65, 0.55, 2.5), paint)
    _box(c, Vector3(0, 1.3, 0.3), Vector3(1.69, 0.42, 2.2), glass, false)
    var wm := _plain(Color(0.03, 0.03, 0.03))
    for wx in [-0.95, 0.95]:
        for wz in [-1.5, 1.5]:
            _mesh_at(c, _cyl(0.35, 0.25, 12), Vector3(wx, 0.35, wz), wm, Vector3(0, 0, 90))
    var hl := _emit(Color(1.0, 0.85, 0.55), 3.0, true)
    for sx in [-0.65, 0.65]:
        _box(c, Vector3(sx, 0.78, -2.41), Vector3(0.35, 0.2, 0.06), hl, false)
        var sp := SpotLight3D.new()
        sp.position = Vector3(sx, 0.8, -2.5)
        sp.spot_range = 24.0
        sp.spot_angle = 30.0
        sp.light_energy = 3.0
        sp.light_color = Color(1.0, 0.9, 0.7)
        c.add_child(sp)

# ---------- gate / bounds ----------
func _gate():
    var g := Node3D.new()
    g.position = Vector3(0, 0, gate_pos.z)
    add_child(g)
    _box(g, Vector3(-2.6, 3, 0), Vector3(0.7, 6, 0.7), m_stone)
    _box(g, Vector3(2.6, 3, 0), Vector3(0.7, 6, 0.7), m_stone)
    _box(g, Vector3(-1.2, 2, 0), Vector3(2.2, 4, 0.2), m_metal)
    _box(g, Vector3(1.2, 2, 0), Vector3(2.2, 4, 0.2), m_metal)
    var l := OmniLight3D.new()
    l.position = Vector3(0, 3, 2)
    l.light_color = Color(1.0, 0.1, 0.05)
    l.omni_range = 14.0
    l.light_energy = 2.0
    g.add_child(l)

func _bounds():
    var e := HALF + 2.0
    for d in [Vector3(0, 0, e), Vector3(0, 0, -e), Vector3(e, 0, 0), Vector3(-e, 0, 0)]:
        var sz := Vector3(2, 10, HALF * 2 + 8) if d.x != 0.0 else Vector3(HALF * 2 + 8, 10, 2)
        _box(self, d + Vector3(0, 5, 0), sz, m_ground, true).visible = false

# ---------- atmosphere ----------
func _mist(pl: Node):
    var ps := CPUParticles3D.new()
    var q := QuadMesh.new()
    q.size = Vector2(1, 1)
    ps.mesh = q
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
    mat.vertex_color_use_as_albedo = true
    var gt := GradientTexture2D.new()
    var gr := Gradient.new()
    gr.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0)])
    gr.offsets = PackedFloat32Array([0.0, 1.0])
    gt.gradient = gr
    gt.fill = GradientTexture2D.FILL_RADIAL
    gt.fill_from = Vector2(0.5, 0.5)
    gt.fill_to = Vector2(1.0, 0.5)
    gt.width = 128
    gt.height = 128
    mat.albedo_texture = gt
    ps.material_override = mat
    ps.amount = 36
    ps.lifetime = 12.0
    ps.preprocess = 12.0
    ps.local_coords = false
    ps.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    ps.emission_box_extents = Vector3(26, 1.0, 26)
    ps.gravity = Vector3.ZERO
    ps.direction = Vector3(1, 0, 0)
    ps.spread = 180.0
    ps.initial_velocity_min = 0.1
    ps.initial_velocity_max = 0.35
    ps.scale_amount_min = 7.0
    ps.scale_amount_max = 12.0
    var ramp := Gradient.new()
    ramp.colors = PackedColorArray([Color(0.6, 0.7, 0.85, 0.0), Color(0.6, 0.7, 0.85, 0.16), Color(0.6, 0.7, 0.85, 0.0)])
    ramp.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
    ps.color_ramp = ramp
    ps.position = Vector3(0, 1.2, 0)
    ps.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    pl.add_child(ps)

func _vignette():
    var cl := CanvasLayer.new()
    cl.layer = 1
    add_child(cl)
    var gt := GradientTexture2D.new()
    var gr := Gradient.new()
    gr.colors = PackedColorArray([Color(0, 0, 0, 0), Color(0, 0, 0, 0.8)])
    gr.offsets = PackedFloat32Array([0.5, 1.0])
    gt.gradient = gr
    gt.fill = GradientTexture2D.FILL_RADIAL
    gt.fill_from = Vector2(0.5, 0.5)
    gt.fill_to = Vector2(1.0, 1.0)
    gt.width = 256
    gt.height = 256
    var tr := TextureRect.new()
    tr.texture = gt
    tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    tr.stretch_mode = TextureRect.STRETCH_SCALE
    tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
    cl.add_child(tr)
    tr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

# ---------- items ----------
func _rand_spot() -> Vector3:
    for i in 50:
        var v := Vector3(randf_range(-HALF + 6, HALF - 6), 0.4, randf_range(-HALF + 6, HALF - 6))
        if v.length() > 17.0 and v.distance_to(Vector3(0, 0.4, HALF - 10)) > 12.0:
            return v
    return Vector3(30, 0.4, 30)

func _scatter():
    _item("key", Vector3(-55, 0.4, 40))
    _item("key", Vector3(50, 0.4, -55))
    for i in 4:
        _item("battery", _rand_spot())
    for i in 3:
        _item("medkit", _rand_spot())
    for i in 3:
        _item("ammo", _rand_spot())
    _item("doc", _rand_spot(), "Torn page: \"The gate needs three keys. One is in the cabin. The others... the trees keep them.\"")

func _item(type: String, pos: Vector3, note := ""):
    var pk := PickupScript.new()
    pk.type = type
    pk.note = note
    pk.position = pos
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    match type:
        "key":
            bm.size = Vector3(0.12, 0.04, 0.3)
            mi.material_override = _emit(Color(0.9, 0.7, 0.1), 1.8)
        "battery":
            var cm := CylinderMesh.new()
            cm.top_radius = 0.05
            cm.bottom_radius = 0.05
            cm.height = 0.28
            mi.mesh = cm
            mi.material_override = _emit(Color(0.1, 0.6, 0.2), 1.2)
        "medkit":
            bm.size = Vector3(0.35, 0.2, 0.25)
            mi.material_override = _plain(Color(0.85, 0.85, 0.85))
        "ammo":
            bm.size = Vector3(0.25, 0.15, 0.15)
            mi.material_override = _plain(Color(0.25, 0.28, 0.15))
        _:
            bm.size = Vector3(0.25, 0.02, 0.33)
            mi.material_override = _plain(Color(0.8, 0.75, 0.6))
    if type != "battery":
        mi.mesh = bm
    pk.add_child(mi)
    pk.visual = mi
    add_child(pk)
