extends Node3D
# Builds the Dark Forest map, player, creature and HUD at runtime. Attached to main.tscn.
# World layout: spawn at +Z, cabin at origin (door on +Z side), exit gate at -Z.

const HALF := 180.0
const TREES := 650
const FOG := Color(0.09, 0.12, 0.16)

const PTex = preload("res://scripts/ptex.gd")
const Assets = preload("res://scripts/assets.gd")
const UIScript = preload("res://scripts/ui.gd")
const PlayerScript = preload("res://scripts/player.gd")
const CreatureScript = preload("res://scripts/creature.gd")
const PickupScript = preload("res://scripts/pickup.gd")
const HideScript = preload("res://scripts/hidespot.gd")
const CarScript = preload("res://scripts/car.gd")

var m_ground: StandardMaterial3D
var m_path: StandardMaterial3D
var m_bark: StandardMaterial3D
var m_dead: StandardMaterial3D
var m_leaf: StandardMaterial3D
var m_wood: StandardMaterial3D
var m_floor: StandardMaterial3D
var m_dark: StandardMaterial3D
var m_roof: StandardMaterial3D
var m_stone: StandardMaterial3D
var m_metal: StandardMaterial3D
var flick := []
var gate_pos := Vector3(0, 1, HALF - 4.0)
var gate_msg_t := 0.0
var moon_light: DirectionalLight3D
var moon_mesh: MeshInstance3D
var moon_halo: MeshInstance3D
var m_plaster: StandardMaterial3D
var m_walls: StandardMaterial3D
var big_house: Node3D
var tex_ok := 0
var m_tile: StandardMaterial3D
var m_rust: StandardMaterial3D
var m_glass: StandardMaterial3D
var m_cracks: StandardMaterial3D
var m_rubber: StandardMaterial3D
var m_locker_front: StandardMaterial3D
var m_locker_in: StandardMaterial3D
var m_porc: StandardMaterial3D
var m_sheet: StandardMaterial3D
var m_blanket: StandardMaterial3D
var nav := AStar3D.new()
var nav_n := 0
var stair_top := 0
var amb_t := 20.0
var lm := []   # landmarks: Vector3(x, z, radius)
var pond_c := Vector2(-95, 55)
const Y1 := 4.7

func _ready():
    randomize()
    Game.reset()
    lm = [Vector3(70, -50, 24), Vector3(-65, -55, 18), Vector3(pond_c.x, pond_c.y, 38)]
    _plain_materials()
    _tex_a()
    _tex_b()
    _tex_c()
    _tex_d()
    _env()
    add_child(UIScript.new())
    _ground()
    _hero_trees()
    _rocks_logs()
    _mansion()
    _build_nav()
    _landmarks()
    _vehicles()
    _gate()
    _bounds()

    var pl := PlayerScript.new()
    pl.position = Vector3(-5, 0.1, -7)
    pl.rotation.y = PI
    add_child(pl)
    _mist(pl)
    _vignette()

    _scatter()
    var gh := CreatureScript.new()
    gh.kind = "ghost"
    gh.bounds = HALF - 6.0
    gh.home_zone = 1
    gh.home_pos = big_house.global_position if big_house != null else Vector3(70, 0, -50)
    gh.position = big_house.to_global(Vector3(3.5, 0.1, -2.6)) if big_house != null else Vector3(35, 0, -35)
    add_child(gh)
    var rv := CreatureScript.new()
    rv.kind = "raven"
    rv.bounds = HALF - 6.0
    rv.position = Vector3(-60, 0, -110)
    add_child(rv)

    var drone := AudioStreamPlayer.new()
    drone.stream = Game.s_drone
    drone.volume_db = linear_to_db(0.4)
    add_child(drone)
    drone.play()
    Game.refresh_objective()
    Game.toast("Loaded: %s, textures %d/4" % [Assets.status(), tex_ok])

func _free(x: float, z: float, m := 0.0) -> bool:
    if absf(x) < 4.0 + m:
        return false
    if absf(x) < 28.0 + m and z > -19.0 - m and z < 38.0 + m:
        return false
    for l in lm:
        if Vector2(x - l.x, z - l.y).length() < l.z + m:
            return false
    return true

func _process(_d):
    var t := Time.get_ticks_msec() * 0.001
    for f in flick:
        var n := 0.5 + 0.25 * sin(t * 7.0 + f[2]) + 0.25 * sin(t * 13.1 + f[2] * 1.7)
        f[0].light_energy = f[1] * (0.15 if n < 0.25 else 0.7 + 0.3 * n)
    amb_t -= _d
    if amb_t <= 0.0:
        amb_t = randf_range(15.0, 40.0)
        _ambient_event()
    var p = Game.player
    if p != null:
        var dir: Vector3 = moon_light.global_transform.basis.z
        moon_mesh.global_position = p.global_position + dir * 110.0
        moon_halo.global_position = moon_mesh.global_position
        if not Game.over and p.global_position.distance_to(gate_pos) < 4.0:
            if Game.keys >= Game.keys_needed:
                Game.win()
            elif t > gate_msg_t:
                gate_msg_t = t + 3.0
                Game.toast("The gate is locked. Keys: %d/%d" % [Game.keys, Game.keys_needed])

# ---------- materials ----------
func _plain(c: Color, rough := 0.9, metal := 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = rough
    m.metallic = metal
    return m

func _emit(c: Color, energy := 2.0, unshaded := false) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.emission_enabled = true
    m.emission = c
    m.emission_energy_multiplier = energy
    if unshaded:
        m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    return m

func _plain_materials():
    m_ground = _plain(Color(0.12, 0.14, 0.1))
    m_path = _plain(Color(0.2, 0.15, 0.1))
    m_bark = _plain(Color(0.2, 0.15, 0.12))
    m_dead = _plain(Color(0.2, 0.18, 0.17))
    m_leaf = _plain(Color(0.05, 0.12, 0.09))
    m_wood = _plain(Color(0.45, 0.32, 0.2))
    m_walls = _plain(Color(0.5, 0.36, 0.22))
    m_floor = _plain(Color(0.25, 0.17, 0.11))
    m_dark = _plain(Color(0.2, 0.13, 0.08))
    m_roof = _plain(Color(0.22, 0.2, 0.2))
    m_stone = _plain(Color(0.35, 0.35, 0.38))
    m_metal = _plain(Color(0.14, 0.12, 0.12), 0.5, 0.6)
    m_plaster = _plain(Color(0.4, 0.36, 0.3))
    m_tile = _plain(Color(0.6, 0.6, 0.62))
    m_rust = _plain(Color(0.35, 0.2, 0.1))
    m_glass = StandardMaterial3D.new()
    m_glass.albedo_color = Color(0.03, 0.05, 0.06, 0.55)
    m_glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    m_glass.roughness = 0.1
    m_cracks = m_glass
    m_rubber = _plain(Color(0.03, 0.03, 0.03), 0.9)
    m_locker_front = StandardMaterial3D.new()
    m_locker_front.albedo_color = Color(0.4, 0.3, 0.25)
    m_locker_front.roughness = 0.6
    m_locker_front.metallic = 0.3
    m_locker_in = _plain(Color(0.07, 0.06, 0.06), 0.7, 0.4)
    m_porc = _plain(Color(0.75, 0.75, 0.72), 0.3)
    m_sheet = _plain(Color(0.55, 0.52, 0.46))
    m_blanket = _plain(Color(0.28, 0.08, 0.07))

# textured upgrades; each group is its own function so one failure cannot leave the world untextured
func _tex_a():
    m_ground = PTex.material(PTex.img_ground(), Color(0.2, 0.23, 0.17), 0.18, 5.0)
    m_path = PTex.material(PTex.img_ground(), Color(0.36, 0.28, 0.2), 0.3, 5.0)
    m_bark = PTex.material(PTex.img_bark(), Color(0.34, 0.28, 0.25), 0.8, 4.0)
    m_dead = PTex.material(PTex.img_bark(), Color(0.28, 0.25, 0.24), 0.8, 4.0)
    m_leaf = PTex.material(PTex.img_ground(), Color(0.07, 0.16, 0.12), 0.5, 3.0)
    tex_ok += 1

func _tex_b():
    m_wood = PTex.material(PTex.img_wood(), Color(0.7, 0.55, 0.4), 0.45, 5.0)
    m_walls = PTex.material(PTex.img_wood(), Color(0.85, 0.62, 0.4), 0.4, 5.0)
    m_floor = PTex.material(PTex.img_wood(), Color(0.45, 0.32, 0.22), 0.5, 5.0)
    m_dark = PTex.material(PTex.img_wood(), Color(0.32, 0.22, 0.15), 0.6, 5.0)
    tex_ok += 1

func _tex_c():
    m_roof = PTex.material(PTex.img_shingle(), Color(0.42, 0.38, 0.38), 0.6, 6.0)
    m_stone = PTex.material(PTex.img_stone(), Color(0.5, 0.5, 0.54), 0.6, 6.0)
    m_tile = PTex.material(PTex.img_stone(), Color(0.7, 0.7, 0.72), 0.5, 3.0)
    m_plaster = PTex.material(PTex.img_ground(), Color(0.5, 0.46, 0.4), 0.25, 4.0)
    tex_ok += 1

func _tex_d():
    m_rust = PTex.material(PTex.img_rust(), Color(1, 1, 1), 0.5, 5.0, 0.8)
    var lt = load("res://tex/locker.jpg")
    if lt != null:
        m_locker_front.albedo_texture = lt
    tex_ok += 1

func _env():
    var e := Environment.new()
    e.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sm := ProceduralSkyMaterial.new()
    sm.sky_top_color = Color(0.02, 0.035, 0.08)
    sm.sky_horizon_color = Color(0.1, 0.14, 0.2)
    sm.ground_horizon_color = Color(0.08, 0.11, 0.15)
    sm.ground_bottom_color = Color(0.03, 0.04, 0.05)
    sky.sky_material = sm
    e.sky = sky
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color(0.2, 0.26, 0.38)
    e.ambient_light_energy = 0.8
    e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    e.tonemap_exposure = 1.15
    e.fog_enabled = true
    e.fog_light_color = FOG
    e.fog_density = 0.026
    e.fog_sky_affect = 0.4
    e.glow_enabled = true
    e.glow_intensity = 0.8
    e.glow_bloom = 0.05
    e.glow_hdr_threshold = 0.8
    var we := WorldEnvironment.new()
    we.environment = e
    add_child(we)
    moon_light = DirectionalLight3D.new()
    moon_light.light_color = Color(0.55, 0.65, 0.9)
    moon_light.light_energy = 0.3
    moon_light.rotation_degrees = Vector3(-50, -30, 0)
    add_child(moon_light)
    var mm := _emit(Color(0.9, 0.93, 1.0), 1.5, true)
    mm.disable_fog = true
    moon_mesh = MeshInstance3D.new()
    var sp := SphereMesh.new()
    sp.radius = 4.0
    sp.height = 8.0
    moon_mesh.mesh = sp
    moon_mesh.material_override = mm
    moon_mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(moon_mesh)
    moon_halo = MeshInstance3D.new()
    var sp2 := SphereMesh.new()
    sp2.radius = 10.0
    sp2.height = 20.0
    moon_halo.mesh = sp2
    var hm := StandardMaterial3D.new()
    hm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    hm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    hm.albedo_color = Color(0.45, 0.6, 0.95, 0.1)
    hm.disable_fog = true
    moon_halo.material_override = hm
    moon_halo.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(moon_halo)

# ---------- helpers ----------
func _box(parent: Node, pos: Vector3, size: Vector3, mat: Material, collide := true, rot := Vector3.ZERO) -> Node3D:
    var body: Node3D
    if collide:
        body = StaticBody3D.new()
    else:
        body = Node3D.new()
    body.position = pos
    body.rotation_degrees = rot
    parent.add_child(body)
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = mat
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if collide else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    body.add_child(mi)
    if collide:
        var cs := CollisionShape3D.new()
        var sh := BoxShape3D.new()
        sh.size = size
        cs.shape = sh
        body.add_child(cs)
    return body

func _mesh_at(parent: Node, mesh: Mesh, pos: Vector3, mat: Material, rot := Vector3.ZERO) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    mi.position = pos
    mi.rotation_degrees = rot
    mi.material_override = mat
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(mi)
    return mi

func _cyl(r: float, h: float, seg := 12) -> CylinderMesh:
    var c := CylinderMesh.new()
    c.top_radius = r
    c.bottom_radius = r
    c.height = h
    c.radial_segments = seg
    c.rings = 1
    return c

# ---------- ground ----------
func _ground_quad(g: StaticBody3D, x: float, z: float, q: float):
    var pm := PlaneMesh.new()
    pm.size = Vector2(q, q)
    var mi := MeshInstance3D.new()
    mi.mesh = pm
    mi.material_override = m_ground
    mi.position = Vector3(x, 0, z)
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    g.add_child(mi)
    var cs := CollisionShape3D.new()
    var sh := BoxShape3D.new()
    sh.size = Vector3(q, 2.0, q)
    cs.shape = sh
    cs.position = Vector3(x, -1.0, z)
    g.add_child(cs)

func _ground():
    var g := StaticBody3D.new()
    add_child(g)
    var ts := 40.0
    var tiles := int(ceil(HALF * 2.0 / ts))
    for ix in tiles:
        for iz in tiles:
            var x0 := -HALF + ts * ix
            var z0 := -HALF + ts * iz
            var c := Vector2(x0 + ts / 2.0, z0 + ts / 2.0)
            if c.distance_to(pond_c) < 55.0:
                var q := 8.0
                for jx in int(ts / q):
                    for jz in int(ts / q):
                        var qx := x0 + q * jx + q / 2.0
                        var qz := z0 + q * jz + q / 2.0
                        if Vector2(qx, qz).distance_to(pond_c) < 21.0:
                            continue
                        _ground_quad(g, qx, qz, q)
            else:
                _ground_quad(g, c.x, c.y, ts)
    _box(self, Vector3(0, 0.02, 0), Vector3(4, 0.02, HALF * 2.0), m_path, false)

# ---------- trees ----------
const HERO := {"p1": 45, "p2": 45, "mA": 40, "mB": 40, "dead": 30, "as1": 25, "as2": 25, "g1": 20, "g2": 20, "g3": 20, "g4": 20}

func _hero_trees():
    var body := StaticBody3D.new()
    add_child(body)
    var cell := 60.0
    for nm in HERO:
        var scene := Assets.load_model("tree_" + nm)
        if scene == null:
            continue
        var parts := Assets.meshes(scene)
        var chunks := {}
        var n: int = HERO[nm]
        var placed := 0
        var tries := 0
        while placed < n and tries < 800:
            tries += 1
            var x := randf_range(-HALF + 5, HALF - 5)
            var z := randf_range(-HALF + 5, HALF - 5)
            if not _free(x, z, 3.0):
                continue
            placed += 1
            var sc := randf_range(0.85, 1.3)
            var b := Basis(Vector3.UP, randf() * TAU) * Basis.from_scale(Vector3(sc, sc, sc))
            var key := Vector2i(floori(x / cell), floori(z / cell))
            if not chunks.has(key):
                chunks[key] = []
            chunks[key].append(Transform3D(b, Vector3(x, 0, z)))
            var cs := CollisionShape3D.new()
            var sh := CylinderShape3D.new()
            sh.radius = 0.5
            sh.height = 4.0
            cs.shape = sh
            cs.position = Vector3(x, 2.0, z)
            body.add_child(cs)
        for key in chunks:
            var arr: Array = chunks[key]
            for mi in parts:
                var mm := MultiMesh.new()
                mm.transform_format = MultiMesh.TRANSFORM_3D
                mm.mesh = mi.mesh
                mm.instance_count = arr.size()
                for i in arr.size():
                    mm.set_instance_transform(i, arr[i] * mi.transform)
                var inst := MultiMeshInstance3D.new()
                inst.multimesh = mm
                inst.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
                inst.visibility_range_end = 160.0
                add_child(inst)
        scene.queue_free()

func _rocks_logs():
    var count := 300
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_3D
    var sp := SphereMesh.new()
    sp.radial_segments = 8
    sp.rings = 4
    mm.mesh = sp
    mm.instance_count = count
    for i in count:
        var p := Vector2(randf_range(-HALF + 3, HALF - 3), randf_range(-HALF + 3, HALF - 3))
        if not _free(p.x, p.y, 0.0):
            p.y = HALF + 500.0
        var s := Vector3(randf_range(0.4, 1.4), randf_range(0.3, 0.8), randf_range(0.4, 1.4))
        var b := Basis(Vector3.UP, randf() * TAU) * Basis.from_scale(s)
        mm.set_instance_transform(i, Transform3D(b, Vector3(p.x, s.y * 0.15, p.y)))
    var inst := MultiMeshInstance3D.new()
    inst.multimesh = mm
    inst.material_override = m_stone
    add_child(inst)
    for i in 60:
        var p := Vector3(randf_range(-HALF + 5, HALF - 5), 0, randf_range(-HALF + 5, HALF - 5))
        if not _free(p.x, p.z, 1.0):
            continue
        var r := randf_range(0.22, 0.4)
        var ln := randf_range(3.0, 6.0)
        var lg := StaticBody3D.new()
        lg.position = Vector3(p.x, r * 0.8, p.z)
        lg.rotation_degrees = Vector3(0, randf() * 360.0, 90)
        add_child(lg)
        _mesh_at(lg, _cyl(r, ln, 8), Vector3.ZERO, m_bark)
        var cs := CollisionShape3D.new()
        var sh := CylinderShape3D.new()
        sh.radius = r
        sh.height = ln
        cs.shape = sh
        lg.add_child(cs)

# ---------- mansion (haveli) ----------
func _prism(parent: Node, pos: Vector3, size: Vector3, mat: Material, rot := Vector3.ZERO):
    var pm := PrismMesh.new()
    pm.size = size
    _mesh_at(parent, pm, pos, mat, rot)

func _pane(parent: Node, pos: Vector3, yaw: float, size: Vector2):
    var q := QuadMesh.new()
    q.size = size
    var mi := _mesh_at(parent, q, pos, _emit(Color(1.0, 0.6, 0.25), 1.6, true), Vector3(0, yaw, 0))
    var f := _plain(Color(0.08, 0.05, 0.03))
    _box(mi, Vector3(0, size.y / 2.0 + 0.04, 0.0), Vector3(size.x + 0.2, 0.08, 0.08), f, false)
    _box(mi, Vector3(0, -size.y / 2.0 - 0.04, 0.0), Vector3(size.x + 0.2, 0.08, 0.08), f, false)
    _box(mi, Vector3(0, 0, 0.01), Vector3(0.06, size.y, 0.04), f, false)
    _box(mi, Vector3(0, 0, 0.01), Vector3(size.x, 0.06, 0.04), f, false)

func _seg(parent: Node, along: String, fixed: float, a: float, b: float, ybase: float, height: float, mat: Material, th := 0.3):
    if b - a < 0.05 or height < 0.05:
        return
    var mid := (a + b) / 2.0
    var ln := b - a
    if along == "x":
        _box(parent, Vector3(mid, ybase + height / 2.0, fixed), Vector3(ln, height, th), mat)
    else:
        _box(parent, Vector3(fixed, ybase + height / 2.0, mid), Vector3(th, height, ln), mat)

# wall along "x" (at z=fixed) or "z" (at x=fixed) from a to b; doors = [Vector2(center, width)]. Doors are 3.8 tall so the tall creature fits.
func _wall(parent: Node, along: String, fixed: float, a: float, b: float, y0: float, doors: Array, h := 4.4, dh := 3.8, th := 0.3, wmat: Material = null):
    var wm: Material = wmat if wmat != null else m_walls
    var cur := a
    var ds := doors.duplicate()
    ds.sort_custom(func(p, q): return p.x < q.x)
    for d in ds:
        _seg(parent, along, fixed, cur, d.x - d.y / 2.0, y0, h, wm, th)
        _seg(parent, along, fixed, d.x - d.y / 2.0, d.x + d.y / 2.0, y0 + dh, h - dh, wm, th)
        cur = d.x + d.y / 2.0
    _seg(parent, along, fixed, cur, b, y0, h, wm, th)

func _storey(c: Node, y0: float, ground: bool):
    var d18 := Vector2(1, 1.8)
    # exterior
    _wall(c, "x", -12.0, -20.0, 20.0, y0, [])
    _wall(c, "z", -20.0, -12.0, 12.0, y0, [])
    _wall(c, "z", 20.0, -12.0, 12.0, y0, [])
    _wall(c, "x", 12.0, -20.0, 20.0, y0, [Vector2(0, 3.0)] if ground else [])
    # corridor north side (hall stays open to the corridor)
    _wall(c, "x", 2.0, -20.0, -8.0, y0, [Vector2(-14, 1.8)])
    _wall(c, "x", 2.0, 8.0, 20.0, y0, [Vector2(14, 1.8)])
    _wall(c, "z", 8.0, 2.0, 12.0, y0, [Vector2(8, 1.8)])
    _wall(c, "z", -8.0, 2.0, 12.0, y0, [])
    # corridor south side + room partitions
    _wall(c, "x", -2.0, -20.0, 20.0, y0, [Vector2(-15, 1.8), Vector2(-5, 1.8), Vector2(2.5, 1.8), Vector2(7.5, 1.8), Vector2(15, 1.8)])
    for px in [-10.0, 0.0, 5.0, 10.0]:
        _wall(c, "z", px, -12.0, -2.0, y0, [])

func _lamp(c: Node, pos: Vector3, energy: float, col := Color(1.0, 0.7, 0.35)):
    var l := OmniLight3D.new()
    l.position = pos
    l.light_color = col
    l.omni_range = 9.0
    l.light_energy = energy
    c.add_child(l)
    flick.append([l, energy, randf() * 50.0])
    _box(c, pos + Vector3(0, 0.15, 0), Vector3(0.14, 0.2, 0.14), _emit(Color(1, 0.6, 0.2), 2.0, true), false)

# ----- furniture helpers -----
func _bed(c: Node, p: Vector3, yaw: float):
    var b := Node3D.new()
    b.position = p
    b.rotation_degrees.y = yaw
    c.add_child(b)
    _box(b, Vector3(0, 0.3, 0), Vector3(2.0, 0.6, 1.4), m_dark)
    _box(b, Vector3(0, 0.68, 0), Vector3(1.9, 0.16, 1.3), m_sheet, false)
    _box(b, Vector3(0.7, 0.82, 0), Vector3(0.5, 0.14, 0.9), m_sheet, false)
    _box(b, Vector3(-0.2, 0.78, 0), Vector3(1.2, 0.06, 1.3), m_blanket, false)
    _box(b, Vector3(1.05, 0.8, 0), Vector3(0.1, 1.0, 1.5), m_dark)

func _table(c: Node, p: Vector3):
    _box(c, p + Vector3(0, 0.78, 0), Vector3(1.8, 0.08, 0.95), m_wood)
    for o in [Vector2(-0.8, -0.4), Vector2(0.8, -0.4), Vector2(-0.8, 0.4), Vector2(0.8, 0.4)]:
        _box(c, p + Vector3(o.x, 0.38, o.y), Vector3(0.1, 0.76, 0.1), m_dark, false)

func _chair(c: Node, pos: Vector3, yaw: float, tip := 0.0):
    var ch := Node3D.new()
    ch.position = pos
    ch.rotation_degrees = Vector3(tip, yaw, 0)
    c.add_child(ch)
    _box(ch, Vector3(0, 0.45, 0), Vector3(0.5, 0.06, 0.5), m_wood, false)
    _box(ch, Vector3(0, 0.78, 0.22), Vector3(0.5, 0.6, 0.05), m_wood, false)
    for o in [Vector2(-0.2, -0.2), Vector2(0.2, -0.2), Vector2(-0.2, 0.2), Vector2(0.2, 0.2)]:
        _box(ch, Vector3(o.x, 0.22, o.y), Vector3(0.05, 0.44, 0.05), m_dark, false)

func _sofa(c: Node, p: Vector3, yaw: float):
    var s := Node3D.new()
    s.position = p
    s.rotation_degrees.y = yaw
    c.add_child(s)
    var fab := _plain(Color(0.22, 0.1, 0.1))
    _box(s, Vector3(0, 0.28, 0), Vector3(2.2, 0.56, 0.9), fab)
    _box(s, Vector3(0, 0.75, -0.38), Vector3(2.2, 0.7, 0.2), fab, false)
    _box(s, Vector3(-1.05, 0.55, 0), Vector3(0.18, 0.5, 0.9), fab, false)
    _box(s, Vector3(1.05, 0.55, 0), Vector3(0.18, 0.5, 0.9), fab, false)

func _shelf(c: Node, p: Vector3, yaw: float, w: float):
    var s := Node3D.new()
    s.position = p
    s.rotation_degrees.y = yaw
    c.add_child(s)
    _box(s, Vector3(0, 1.4, 0), Vector3(w, 2.8, 0.4), m_dark)
    for i in 5:
        _box(s, Vector3(0, 0.3 + i * 0.6, 0.12), Vector3(w - 0.1, 0.05, 0.3), m_wood, false)
        for k in 7:
            var bx := -w / 2.0 + 0.2 + k * ((w - 0.4) / 7.0)
            _box(s, Vector3(bx, 0.55 + i * 0.6, 0.13), Vector3(0.12, 0.42, 0.22), _plain(Color(randf_range(0.1, 0.5), randf_range(0.05, 0.25), randf_range(0.05, 0.2))), false)

func _crate(c: Node, p: Vector3):
    _box(c, p + Vector3(0, 0.4, 0), Vector3(1.0, 0.8, 1.0), m_wood)

func _toilet(c: Node, p: Vector3, yaw: float):
    var t := Node3D.new()
    t.position = p
    t.rotation_degrees.y = yaw
    c.add_child(t)
    _mesh_at(t, _cyl(0.22, 0.4, 12), Vector3(0, 0.2, 0.1), m_porc)
    _box(t, Vector3(0, 0.6, -0.2), Vector3(0.5, 0.5, 0.2), m_porc, false)
    _mesh_at(t, _cyl(0.24, 0.05, 12), Vector3(0, 0.42, 0.1), m_porc)

func _sink(c: Node, p: Vector3, yaw: float):
    var t := Node3D.new()
    t.position = p
    t.rotation_degrees.y = yaw
    c.add_child(t)
    _box(t, Vector3(0, 0.4, 0), Vector3(0.4, 0.8, 0.3), m_porc)
    _box(t, Vector3(0, 0.85, 0.03), Vector3(0.65, 0.14, 0.46), m_porc, false)

func _tub(c: Node, p: Vector3, yaw: float):
    var t := Node3D.new()
    t.position = p
    t.rotation_degrees.y = yaw
    c.add_child(t)
    _box(t, Vector3(0, 0.28, 0), Vector3(1.8, 0.56, 0.8), m_porc)
    _box(t, Vector3(0, 0.57, 0), Vector3(1.6, 0.05, 0.6), _plain(Color(0.05, 0.07, 0.08)), false)

func _counter(c: Node, p: Vector3, ln: float):
    _box(c, p + Vector3(0, 0.45, 0), Vector3(ln, 0.9, 0.7), m_dark)
    _box(c, p + Vector3(0, 0.92, 0), Vector3(ln + 0.05, 0.06, 0.75), m_stone, false)

func _rug(c: Node, p: Vector3, size: Vector2, col: Color):
    _box(c, p + Vector3(0, 0.05, 0), Vector3(size.x, 0.02, size.y), _plain(col), false)

# ----- hiding locker (door opens/closes while you hide) -----
func _locker(parent: Node3D, pos: Vector3, yaw: float):
    var W := 2.4
    var H := 3.4
    var D := 0.8
    var cw := W / 4.0
    var l := Node3D.new()
    l.position = pos
    l.rotation_degrees.y = yaw
    parent.add_child(l)
    var body := StaticBody3D.new()
    l.add_child(body)
    var cs := CollisionShape3D.new()
    var sh := BoxShape3D.new()
    sh.size = Vector3(W, H, D)
    cs.shape = sh
    cs.position = Vector3(0, H / 2.0, 0)
    body.add_child(cs)
    _box(l, Vector3(0, H / 2.0, -D / 2.0 + 0.025), Vector3(W, H, 0.05), m_locker_in, false)
    _box(l, Vector3(-W / 2.0 + 0.025, H / 2.0, 0), Vector3(0.05, H, D), m_locker_in, false)
    _box(l, Vector3(W / 2.0 - 0.025, H / 2.0, 0), Vector3(0.05, H, D), m_locker_in, false)
    _box(l, Vector3(0, H - 0.025, 0), Vector3(W, 0.05, D), m_locker_in, false)
    _box(l, Vector3(0, 0.025, 0), Vector3(W, 0.05, D), m_locker_in, false)
    _box(l, Vector3(-W / 2.0 + cw, H / 2.0, 0), Vector3(0.05, H, D), m_locker_in, false)
    var fm: StandardMaterial3D = m_locker_front.duplicate()
    fm.uv1_scale = Vector3(0.75, 1, 1)
    fm.uv1_offset = Vector3(0.25, 0, 0)
    _box(l, Vector3(cw / 2.0, H / 2.0, D / 2.0 - 0.02), Vector3(3.0 * cw, H, 0.04), fm, false)
    var hinge := Node3D.new()
    hinge.position = Vector3(-W / 2.0 + 0.02, 0, D / 2.0 + 0.02)
    l.add_child(hinge)
    var dm: StandardMaterial3D = m_locker_front.duplicate()
    dm.uv1_scale = Vector3(0.25, 1, 1)
    _box(hinge, Vector3(cw / 2.0 - 0.02, H / 2.0, 0), Vector3(cw - 0.04, H - 0.06, 0.04), dm, false)
    var hs := HideScript.new()
    l.add_child(hs)
    var cx := -W / 2.0 + cw / 2.0
    hs.position = Vector3(cx, 1.0, D / 2.0 + 0.5)
    hs.cam_pos = l.to_global(Vector3(cx, 1.7, -0.05))
    hs.exit_pos = l.to_global(Vector3(cx, 0.0, D / 2.0 + 1.1))
    hs.cam_yaw = yaw + 180.0
    hs.exit_yaw = yaw + 180.0
    hs.door = hinge

func _mansion():
    var c := Node3D.new()
    c.name = "Mansion"
    add_child(c)
    # ground floor floor tiles (visual; the ground collides)
    var rooms := [
        [-20, 20, -2, 2, "w"], [-20, -8, 2, 12, "w"], [-8, 8, 2, 12, "w"], [8, 20, 2, 12, "w"],
        [-20, -10, -12, -2, "w"], [-10, 0, -12, -2, "w"], [0, 5, -12, -2, "t"], [5, 10, -12, -2, "t"], [10, 20, -12, -2, "w"]]
    for r in rooms:
        var sz := Vector3(r[1] - r[0], 0.04, r[3] - r[2])
        _box(c, Vector3((r[0] + r[1]) / 2.0, 0.03, (r[2] + r[3]) / 2.0), sz, m_tile if r[4] == "t" else m_floor, false)
    _storey(c, 0.0, true)
    # first floor slab with a hole for the staircase
    _box(c, Vector3(-13.75, 4.55, 0), Vector3(12.5, 0.3, 24), m_floor)
    _box(c, Vector3(7.75, 4.55, 0), Vector3(24.5, 0.3, 24), m_floor)
    _box(c, Vector3(-6, 4.55, -4.5), Vector3(3, 0.3, 15), m_floor)
    _box(c, Vector3(-6, 4.55, 11.5), Vector3(3, 0.3, 1), m_floor)
    _storey(c, Y1, false)
    # top ceiling + roof
    _box(c, Vector3(0, 9.2, 0), Vector3(40.6, 0.2, 24.6), m_dark, false)
    _box(c, Vector3(0, 12.33, 6.5), Vector3(42, 0.3, 14.34), m_roof, false, Vector3(25, 0, 0))
    _box(c, Vector3(0, 12.33, -6.5), Vector3(42, 0.3, 14.34), m_roof, false, Vector3(-25, 0, 0))
    _box(c, Vector3(0, 15.4, 0), Vector3(42, 0.3, 0.5), m_dark, false)
    _prism(c, Vector3(20.15, 12.33, 0), Vector3(26, 6.06, 0.3), m_walls, Vector3(0, 90, 0))
    _prism(c, Vector3(-20.15, 12.33, 0), Vector3(26, 6.06, 0.3), m_walls, Vector3(0, 90, 0))
    # staircase: smooth collision ramp + visual steps + rails
    _box(c, Vector3(-6, 2.22, 7.076), Vector3(3, 0.3, 9.28), m_wood, true, Vector3(-30.43, 0, 0)).visible = false
    for k in 24:
        var hh := 0.1958 * (k + 1)
        _box(c, Vector3(-6, hh / 2.0, 3.0 + 0.3333 * (k + 0.5)), Vector3(3, hh, 0.3333), m_wood, false)
    _box(c, Vector3(-4.5, Y1 + 0.55, 7), Vector3(0.1, 1.1, 8), m_dark)
    _box(c, Vector3(-6, Y1 + 0.55, 3.0), Vector3(3, 1.1, 0.1), m_dark)
    # front porch + double doors (open) + exterior windows
    _box(c, Vector3(0, 0.03, 13.7), Vector3(11, 0.06, 3.4), m_floor, false)
    for px in [-5.0, 5.0]:
        _box(c, Vector3(px, 2.3, 15.2), Vector3(0.45, 4.6, 0.45), m_dark)
    _box(c, Vector3(0, 4.75, 13.9), Vector3(11.5, 0.2, 4.0), m_roof, false, Vector3(10, 0, 0))
    for sgn in [-1.0, 1.0]:
        var hg := Node3D.new()
        hg.position = Vector3(sgn * 1.5, 0, 12.0)
        hg.rotation_degrees.y = -80.0 * sgn
        c.add_child(hg)
        _box(hg, Vector3(-sgn * 0.7, 1.85, 0), Vector3(1.4, 3.7, 0.1), m_dark)
    for wx in [-14.0, 14.0]:
        _pane(c, Vector3(wx, 2.2, 12.2), 0.0, Vector2(1.4, 1.8))
    for wx in [-14.0, 0.0, 14.0]:
        _pane(c, Vector3(wx, 6.9, 12.2), 0.0, Vector2(1.4, 1.8))
    _pane(c, Vector3(-5, 2.2, -12.2), 180.0, Vector2(1.2, 1.6))
    _pane(c, Vector3(14, 6.9, -12.2), 180.0, Vector2(1.2, 1.6))
    # lights
    _lamp(c, Vector3(-5, 2.2, -7), 0.7)
    _lamp(c, Vector3(0, 3.4, 0), 0.7)
    _lamp(c, Vector3(0, 3.6, 6), 0.9)
    _lamp(c, Vector3(14, 2.6, 7), 0.7)
    _lamp(c, Vector3(-14, 2.6, 7), 0.6)
    _lamp(c, Vector3(0, Y1 + 3.4, 0), 0.6)
    _lamp(c, Vector3(-5, Y1 + 2.2, -7), 0.7)

    # ---- ground floor rooms ----
    _bed(c, Vector3(-8.0, 0, -10.2), 0.0)                       # start bedroom
    _locker(c, Vector3(-3.0, 0, -11.45), 0.0)
    _crate(c, Vector3(-17, 0, -8))                              # storage (torch here)
    _crate(c, Vector3(-18.5, 0, -5))
    _crate(c, Vector3(-12, 0, -10))
    _locker(c, Vector3(-15, 0, -11.45), 0.0)
    _toilet(c, Vector3(2.5, 0, -11.3), 0.0)
    _sink(c, Vector3(4.4, 0, -8.0), -90.0)
    _tub(c, Vector3(7.5, 0, -11.0), 0.0)
    _sink(c, Vector3(9.4, 0, -6.0), -90.0)
    _shelf(c, Vector3(12.2, 0, -11.7), 0.0, 3.0)                # library
    _shelf(c, Vector3(15.5, 0, -11.7), 0.0, 2.4)
    _table(c, Vector3(15, 0, -7))
    _locker(c, Vector3(18.6, 0, -11.45), 0.0)
    _sofa(c, Vector3(-14, 0, 4.6), 180.0)                       # living room
    _table(c, Vector3(-14, 0, 8.0))
    _shelf(c, Vector3(-19.6, 0, 7), 90.0, 3.0)
    _locker(c, Vector3(-11.0, 0, 11.45), 180.0)
    _counter(c, Vector3(17, 0, 3.2), 4.0)                       # kitchen
    _table(c, Vector3(14, 0, 7.0))
    _chair(c, Vector3(14, 0, 8.0), 180.0)
    _chair(c, Vector3(12.8, 0.25, 6.2), 70.0, 80.0)
    _mesh_at(c, _cyl(0.45, 1.0, 12), Vector3(19.2, 0.5, 8), m_metal)
    _locker(c, Vector3(17.0, 0, 11.45), 180.0)
    _rug(c, Vector3(0, 0, 7), Vector2(5, 7), Color(0.25, 0.05, 0.06))   # hall
    # ---- first floor rooms ----
    _bed(c, Vector3(-17, Y1, 6), 0.0)
    _locker(c, Vector3(-11.0, Y1, 11.45), 180.0)
    _bed(c, Vector3(17, Y1, 6), 0.0)
    _locker(c, Vector3(11.5, Y1, 11.45), 180.0)
    _bed(c, Vector3(-17, Y1, -9), 0.0)
    _locker(c, Vector3(-13.0, Y1, -11.45), 0.0)
    _bed(c, Vector3(-7.5, Y1, -10), 0.0)                        # master bedroom
    _table(c, Vector3(-3, Y1, -6.0))
    _locker(c, Vector3(-4.5, Y1, -11.45), 0.0)
    _toilet(c, Vector3(2.5, Y1, -11.3), 0.0)
    _sink(c, Vector3(4.4, Y1, -8.0), -90.0)
    _tub(c, Vector3(7.5, Y1, -11.0), 0.0)
    _shelf(c, Vector3(12.2, Y1, -11.7), 0.0, 3.0)               # study
    _table(c, Vector3(15, Y1, -7))
    _locker(c, Vector3(18.6, Y1, -11.45), 0.0)
    _rug(c, Vector3(0, Y1, 7), Vector2(5, 6), Color(0.05, 0.08, 0.2))
    # ---- items inside the house ----
    _item("torch", Vector3(-17, 0.82, -8))
    _item("key1", Vector3(15, 0.88, -7))
    _item("battery", Vector3(12.5, 0.95, 3.2))
    _item("battery", Vector3(17, Y1 + 0.6, 6))
    _item("can", Vector3(16, 0.95, 3.4))
    _item("can", Vector3(-12, 0.05, 8))
    _item("can", Vector3(-10, Y1 + 0.05, 0))
    _item("can", Vector3(5, Y1 + 0.05, 8))
    _item("medkit", Vector3(2.5, 0.05, -9.5))
    _item("medkit", Vector3(-3, Y1 + 0.82, -6))
    _item("ammo", Vector3(-2, 0.05, -9.5))
    _item("ammo", Vector3(-15, Y1 + 0.05, 8.5))
    _item("gun", Vector3(-3.4, Y1 + 0.84, -6))
    _item("doc", Vector3(-14, 0.88, 8), "Note: \"It only walks when it thinks the house is empty. Do not run in the dark.\"")
    _item("doc", Vector3(5, Y1 + 0.1, 5), "Torn page: \"The gate needs three keys. Gate keys: one in this house, one in the big white house. The car key is in the old hut.\"")

# ---------- waypoint graph (so the creature can walk through the house) ----------
func _np(pos: Vector3) -> int:
    nav.add_point(nav_n, pos)
    nav_n += 1
    return nav_n - 1

func _ln(a: int, b: int):
    nav.connect_points(a, b, true)

func _build_nav():
    var cxs := [-18.0, -15.0, -14.0, -10.0, -5.0, -2.5, 0.0, 2.5, 5.0, 7.5, 10.0, 14.0, 15.0, 18.0]
    for fi in 2:
        var y := 0.0 if fi == 0 else Y1
        var ci := {}
        var prev := -1
        for x in cxs:
            var id := _np(Vector3(x, y, 0))
            ci[x] = id
            if prev >= 0:
                _ln(prev, id)
            prev = id
        var hc := _np(Vector3(0, y, 6))
        _ln(hc, ci[0.0])
        for x in [-14.0, 14.0]:
            var d := _np(Vector3(x, y, 2))
            var rc := _np(Vector3(x, y, 7))
            _ln(ci[x], d)
            _ln(d, rc)
            if x == 14.0:
                var dk := _np(Vector3(8, y, 8))
                _ln(rc, dk)
                _ln(dk, hc)
        for x in [-15.0, -5.0, 2.5, 7.5, 15.0]:
            var d2 := _np(Vector3(x, y, -2))
            var rc2 := _np(Vector3(x, y, -7))
            _ln(ci[x], d2)
            _ln(d2, rc2)
        if fi == 0:
            var hf := _np(Vector3(0, 0, 10))
            _ln(hc, hf)
            var porch := _np(Vector3(0, 0, 14))
            var o1 := _np(Vector3(0, 0, 20))
            var o2 := _np(Vector3(0, 0, 28))
            _ln(hf, porch)
            _ln(porch, o1)
            _ln(o1, o2)
            var s0 := _np(Vector3(-6, 0, 3.5))
            var s1 := _np(Vector3(-6, 2.35, 7.0))
            var s2 := _np(Vector3(-6, Y1, 11.2))
            _ln(ci[-5.0], s0)
            _ln(s0, s1)
            _ln(s1, s2)
            stair_top = s2
        else:
            var fl := _np(Vector3(-4, Y1, 11.5))
            var fh := _np(Vector3(-3, Y1, 10))
            _ln(stair_top, fl)
            _ln(fl, fh)
            _ln(fh, hc)
    Game.nav = nav
    Game.zones.append({"t": Transform3D(Basis(), Vector3.ZERO), "hx": 20.5, "hz": 12.5, "entry": Vector3(0, 0, 24)})

# ---------- vehicles ----------
func _vehicles():
    var car := CarScript.new()
    car.position = Vector3(14, 0.05, 27)
    car.rotation_degrees.y = 190.0
    add_child(car)
    var cm := Assets.load_model("car_good")
    if cm != null:
        car.add_child(cm)
    else:
        _box(car, Vector3(0, 0.6, 0), Vector3(1.8, 1.0, 4.7), _plain(Color(0.1, 0.3, 0.3)), false)
    for sx in [-0.65, 0.65]:
        var sp := SpotLight3D.new()
        sp.position = Vector3(sx, 0.7, -2.3)
        sp.spot_range = 24.0
        sp.spot_angle = 30.0
        sp.light_energy = 3.0
        sp.light_color = Color(1.0, 0.9, 0.7)
        car.add_child(sp)
    # three broken-down wrecks in different places
    _wreck(Vector3(-32, 0, 48), 35.0)
    _wreck(Vector3(48, 0, 12), 200.0)
    _wreck(Vector3(-18, 0, -80), 110.0)

func _wreck(pos: Vector3, yaw: float):
    var b := StaticBody3D.new()
    b.position = pos + Vector3(0, -0.04, 0)
    b.rotation_degrees = Vector3(randf_range(-2.0, 2.0), yaw, randf_range(-4.0, 4.0))
    add_child(b)
    var cs := CollisionShape3D.new()
    var sh := BoxShape3D.new()
    sh.size = Vector3(1.8, 1.2, 4.7)
    cs.shape = sh
    cs.position = Vector3(0, 0.62, 0)
    b.add_child(cs)
    var m := Assets.load_model("car_wreck")
    if m != null:
        b.add_child(m)
    else:
        _box(b, Vector3(0, 0.6, 0), Vector3(1.8, 1.0, 4.7), m_rust, false)

func _model_at(model_name: String, pos: Vector3, yaw: float) -> Node3D:
    var holder := Node3D.new()
    holder.position = pos
    holder.rotation_degrees.y = yaw
    add_child(holder)
    var n := Assets.load_model(model_name)
    if n != null:
        holder.add_child(n)
        for mi in Assets.meshes(n):
            mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    return holder

func _hitem(h: Node3D, type: String, lp: Vector3, note := ""):
    _item(type, h.to_global(lp), note)

# ---------- big white house: enterable, wood interior, 2 floors, stairs, the witch lives here ----------
func _wood_lining(h: Node3D, y0: float, ht: float):
    # wooden panelling just inside the model's walls (local coordinates, origin = house centre)
    var T := 0.06
    _seg(h, "z", 7.0, -5.25, 5.25, y0, ht, m_walls, T)           # east wall
    _seg(h, "x", -5.25, -7.0, 7.0, y0, ht, m_walls, T)           # north wall
    _seg(h, "z", -7.0, -5.25, -0.7, y0, ht, m_walls, T)          # west wall (stairs room)
    _seg(h, "z", 0.32, -0.7, 5.25, y0, ht, m_walls, T)           # west wall of the front block
    _seg(h, "x", -0.7, -7.0, 0.3, y0, ht, m_walls, T)            # south wall of the stairs room
    if y0 < 1.0:
        _seg(h, "x", 5.25, 0.3, 1.17, y0, ht, m_walls, T)        # front wall with the door gap
        _seg(h, "x", 5.25, 2.37, 7.0, y0, ht, m_walls, T)
        _seg(h, "x", 5.25, 1.17, 2.37, y0 + 2.45, ht - 2.45, m_walls, T)
    else:
        _seg(h, "x", 5.25, 0.3, 7.0, y0, ht, m_walls, T)

func _big_house(pos: Vector3, yaw: float) -> Node3D:
    var h := Node3D.new()
    h.name = "BigHouse"
    h.position = pos
    h.rotation_degrees.y = yaw
    add_child(h)
    var model := Assets.load_model("house_big")
    if model != null:
        h.add_child(model)
        for mi in Assets.meshes(model):
            mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    var Y := 3.05
    # wood panelling inside both floors
    _wood_lining(h, 0.0, 3.0)
    _wood_lining(h, Y, 2.9)
    # interior partitions (doors are 1.2 m wide, 2.3 m tall)
    for y0 in [0.0, Y]:
        _wall(h, "x", 0.0, 0.3, 7.0, y0, [Vector2(5.2, 1.2)], 2.95, 2.3, 0.12, m_walls)
        _wall(h, "z", 0.255, -5.25, -0.65, y0, [Vector2(-2.0, 1.2)], 2.95, 2.3, 0.12, m_walls)
    # staircase to the first floor (smooth collision ramp + visible steps), in the west room
    var ang := rad_to_deg(atan2(3.05, 4.6))
    _box(h, Vector3(-3.6, 1.41, -4.135), Vector3(5.52, 0.2, 1.4), m_dark, true, Vector3(0, 0, ang)).visible = false
    for k in 16:
        var hh := 0.19 * (k + 1)
        _box(h, Vector3(-5.9 + 0.2875 * (k + 0.5), hh / 2.0, -4.135), Vector3(0.2875, hh, 1.3), m_wood, false)
    _box(h, Vector3(-3.95, Y + 0.5, -3.38), Vector3(4.6, 1.0, 0.06), m_dark, true)
    # lights
    _lamp(h, Vector3(3.5, 2.5, 2.6), 0.8)
    _lamp(h, Vector3(3.5, 2.5, -2.6), 0.7)
    _lamp(h, Vector3(-3.5, 2.5, -2.0), 0.6)
    _lamp(h, Vector3(3.5, Y + 2.5, 2.6), 0.6)
    _lamp(h, Vector3(3.5, Y + 2.5, -2.6), 0.6)
    # ground floor furniture
    _sofa(h, Vector3(6.3, 0, 3.2), 90.0)
    _table(h, Vector3(4.2, 0, 2.2))
    _locker(h, Vector3(6.6, 0, 0.9), -90.0)
    _counter(h, Vector3(4.2, 0, -4.8), 4.0)
    _table(h, Vector3(3.2, 0, -2.4))
    _chair(h, Vector3(3.2, 0, -1.4), 180.0)
    _chair(h, Vector3(2.0, 0, -2.4), 90.0)
    _mesh_at(h, _cyl(0.45, 1.0, 12), Vector3(6.3, 0.5, -4.5), m_metal)
    _locker(h, Vector3(6.6, 0, -2.2), -90.0)
    _crate(h, Vector3(-6.0, 0, -1.5))
    _crate(h, Vector3(-4.3, 0, -1.3))
    _locker(h, Vector3(-6.6, 0, -2.0), 90.0)
    _rug(h, Vector3(2.0, 0, 2.7), Vector2(3, 3.5), Color(0.25, 0.05, 0.06))
    # first floor furniture
    _bed(h, Vector3(4.6, Y, 3.4), 0.0)
    _locker(h, Vector3(6.6, Y, 0.9), -90.0)
    _bed(h, Vector3(4.2, Y, -4.2), 0.0)
    _table(h, Vector3(2.0, Y, -2.2))
    _locker(h, Vector3(6.6, Y, -2.2), -90.0)
    _crate(h, Vector3(-5.8, Y, -1.5))
    _locker(h, Vector3(-6.6, Y, -2.0), 90.0)
    # items: PETROL here, one gate key upstairs
    _hitem(h, "fuel", Vector3(1.2, 0, -4.3))
    _hitem(h, "ammo", Vector3(-5.0, 0, -1.4))
    _hitem(h, "can", Vector3(2.4, 0.9, -4.8))
    _hitem(h, "battery", Vector3(4.2, 0.85, 2.2))
    _hitem(h, "key3", Vector3(2.0, Y + 0.85, -2.2))
    _hitem(h, "medkit", Vector3(4.2, Y + 0.6, -4.2))
    _hitem(h, "can", Vector3(-5.8, Y + 0.85, -1.5))
    # navigation graph for the creature (ground floor, stairs, first floor)
    var ent := h.to_global(Vector3(1.77, 0, 8.2))
    Game.zones.append({"t": h.global_transform, "hx": 7.4, "hz": 5.65, "entry": ent})
    var o2 := _np(h.to_global(Vector3(1.77, 0, 13.0)))
    var oe := _np(ent)
    var d0 := _np(h.to_global(Vector3(1.77, 0, 4.6)))
    var h1 := _np(h.to_global(Vector3(2.5, 0, 2.4)))
    var g1 := _np(h.to_global(Vector3(5.2, 0, 0.0)))
    var k1 := _np(h.to_global(Vector3(4.5, 0, -2.6)))
    var g2 := _np(h.to_global(Vector3(0.255, 0, -2.0)))
    var w1 := _np(h.to_global(Vector3(-1.5, 0, -2.0)))
    var w2 := _np(h.to_global(Vector3(-5.5, 0, -1.9)))
    var s0 := _np(h.to_global(Vector3(-6.4, 0, -3.0)))
    var s0b := _np(h.to_global(Vector3(-6.4, 0, -4.135)))
    var s1 := _np(h.to_global(Vector3(-3.6, 1.5, -4.135)))
    var s2 := _np(h.to_global(Vector3(-0.9, Y, -4.135)))
    var f1 := _np(h.to_global(Vector3(-0.6, Y, -2.0)))
    var f2 := _np(h.to_global(Vector3(0.255, Y, -2.0)))
    var f3 := _np(h.to_global(Vector3(3.8, Y, -2.6)))
    var f4 := _np(h.to_global(Vector3(5.2, Y, 0.0)))
    var f5 := _np(h.to_global(Vector3(2.5, Y, 2.4)))
    for pr in [[o2, oe], [oe, d0], [d0, h1], [h1, g1], [g1, k1], [k1, g2], [g2, w1], [w1, w2], [w2, s0], [s0, s0b], [s0b, s1], [s1, s2], [s2, f1], [f1, f2], [f2, f3], [f3, f4], [f4, f5]]:
        _ln(pr[0], pr[1])
    return h

# ---------- old hut: enterable, car key inside ----------
func _cabin_house(pos: Vector3, yaw: float) -> Node3D:
    var h := Node3D.new()
    h.name = "Hut"
    h.position = pos
    h.rotation_degrees.y = yaw
    add_child(h)
    var model := Assets.load_model("cabin")
    if model != null:
        h.add_child(model)
        for mi in Assets.meshes(model):
            mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
            if String(mi.name) == "c_Object_4" and mi.mesh != null:
                var body := StaticBody3D.new()
                var cs := CollisionShape3D.new()
                var shape := mi.mesh.create_trimesh_shape()
                if shape is ConcavePolygonShape3D:
                    shape.backface_collision = true
                cs.shape = shape
                body.add_child(cs)
                model.add_child(body)
    var F := 0.85
    # ramp up to the doorway (the model has steps; this makes them walkable)
    _box(h, Vector3(-1.09, 0.31, 3.9), Vector3(2.0, 0.2, 3.02), m_wood, true, Vector3(16.3, 0, 0)).visible = false
    # wooden floor cover + furniture inside
    _lamp(h, Vector3(-1.0, F + 2.0, -0.8), 0.7)
    _table(h, Vector3(-1.0, F, -0.7))
    _bed(h, Vector3(-3.1, F, -2.3), 90.0)
    _crate(h, Vector3(1.9, F, -1.2))
    _locker(h, Vector3(1.6, F, -3.2), 0.0)
    _hitem(h, "key2", Vector3(-1.0, F + 0.9, -0.7))
    _hitem(h, "battery", Vector3(0.6, F + 0.05, -1.9))
    _hitem(h, "medkit", Vector3(-3.4, F + 0.05, -0.4))
    _hitem(h, "can", Vector3(1.9, F + 0.9, -1.2))
    _hitem(h, "doc", Vector3(-1.3, F + 0.85, -0.5), "Note: \"The car key is safe here. Petrol is in the big white house... but SHE lives there.\"")
    return h

func _landmarks():
    big_house = _big_house(Vector3(70, 0, -50), -54.5)
    _cabin_house(Vector3(-65, 0, -55), 49.8)
    var pn := _model_at("pond", Vector3(pond_c.x, -0.05, pond_c.y), 0.0)
    for mi in Assets.meshes(pn):
        if "water" in String(mi.name):
            var wm := StandardMaterial3D.new()
            wm.albedo_color = Color(0.04, 0.09, 0.11, 0.78)
            wm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
            wm.roughness = 0.05
            wm.metallic = 0.3
            wm.cull_mode = BaseMaterial3D.CULL_DISABLED
            mi.material_override = wm
    # safe wading floor just under the water surface (so nobody falls into the pond)
    var plate := StaticBody3D.new()
    plate.position = Vector3(pond_c.x, -1.8, pond_c.y)
    add_child(plate)
    var pcs := CollisionShape3D.new()
    var psh := BoxShape3D.new()
    psh.size = Vector3(46.0, 0.4, 46.0)
    pcs.shape = psh
    plate.add_child(pcs)

func _gate():
    var g := Node3D.new()
    g.position = Vector3(0, 0, gate_pos.z)
    add_child(g)
    _box(g, Vector3(-2.6, 3, 0), Vector3(0.7, 6, 0.7), m_stone)
    _box(g, Vector3(2.6, 3, 0), Vector3(0.7, 6, 0.7), m_stone)
    _box(g, Vector3(-1.2, 2, 0), Vector3(2.2, 4, 0.2), m_metal)
    _box(g, Vector3(1.2, 2, 0), Vector3(2.2, 4, 0.2), m_metal)
    var l := OmniLight3D.new()
    l.position = Vector3(0, 3, -2)
    l.light_color = Color(1.0, 0.1, 0.05)
    l.omni_range = 14.0
    l.light_energy = 2.0
    g.add_child(l)

func _bounds():
    var e := HALF + 2.0
    for d in [Vector3(0, 0, e), Vector3(0, 0, -e), Vector3(e, 0, 0), Vector3(-e, 0, 0)]:
        var sz := Vector3(2, 10, HALF * 2 + 8) if d.x != 0.0 else Vector3(HALF * 2 + 8, 10, 2)
        _box(self, d + Vector3(0, 5, 0), sz, m_ground, true).visible = false

# ---------- atmosphere ----------
func _mist(pl: Node):
    var ps := CPUParticles3D.new()
    var q := QuadMesh.new()
    q.size = Vector2(1, 1)
    ps.mesh = q
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
    mat.vertex_color_use_as_albedo = true
    var gt := GradientTexture2D.new()
    var gr := Gradient.new()
    gr.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0)])
    gr.offsets = PackedFloat32Array([0.0, 1.0])
    gt.gradient = gr
    gt.fill = GradientTexture2D.FILL_RADIAL
    gt.fill_from = Vector2(0.5, 0.5)
    gt.fill_to = Vector2(1.0, 0.5)
    gt.width = 128
    gt.height = 128
    mat.albedo_texture = gt
    ps.material_override = mat
    ps.amount = 36
    ps.lifetime = 12.0
    ps.preprocess = 12.0
    ps.local_coords = false
    ps.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    ps.emission_box_extents = Vector3(26, 1.0, 26)
    ps.gravity = Vector3.ZERO
    ps.direction = Vector3(1, 0, 0)
    ps.spread = 180.0
    ps.initial_velocity_min = 0.1
    ps.initial_velocity_max = 0.35
    ps.scale_amount_min = 7.0
    ps.scale_amount_max = 12.0
    var ramp := Gradient.new()
    ramp.colors = PackedColorArray([Color(0.6, 0.7, 0.85, 0.0), Color(0.6, 0.7, 0.85, 0.16), Color(0.6, 0.7, 0.85, 0.0)])
    ramp.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
    ps.color_ramp = ramp
    ps.position = Vector3(0, 1.2, 0)
    ps.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    pl.add_child(ps)

func _vignette():
    var cl := CanvasLayer.new()
    cl.layer = 1
    add_child(cl)
    var gt := GradientTexture2D.new()
    var gr := Gradient.new()
    gr.colors = PackedColorArray([Color(0, 0, 0, 0), Color(0, 0, 0, 0.8)])
    gr.offsets = PackedFloat32Array([0.5, 1.0])
    gt.gradient = gr
    gt.fill = GradientTexture2D.FILL_RADIAL
    gt.fill_from = Vector2(0.5, 0.5)
    gt.fill_to = Vector2(1.0, 1.0)
    gt.width = 256
    gt.height = 256
    var tr := TextureRect.new()
    tr.texture = gt
    tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    tr.stretch_mode = TextureRect.STRETCH_SCALE
    tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
    cl.add_child(tr)
    tr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

# ---------- items / ambience ----------
func _rand_spot() -> Vector3:
    for i in 80:
        var x := randf_range(-HALF + 8, HALF - 8)
        var z := randf_range(-HALF + 8, HALF - 8)
        if _free(x, z, 3.0):
            return Vector3(x, 0, z)
    return Vector3(-60, 0, -60)

func _scatter():
    for i in 6:
        _item("battery", _rand_spot())
    for i in 3:
        _item("medkit", _rand_spot())
    for i in 4:
        _item("ammo", _rand_spot())
    for i in 12:
        _item("can", _rand_spot())
    for i in 3:
        _item("doc", _rand_spot(), "Torn page: \"The car needs its key AND petrol. The key is in the hut, the petrol in the white house. SHE hears every sound.\"")

func _item(type: String, pos: Vector3, note := ""):
    var pk := PickupScript.new()
    pk.type = type
    pk.note = note
    pk.position = pos
    add_child(pk)

func _ambient_event():
    var p = Game.player
    if p == null or Game.over:
        return
    var a := randf() * TAU
    var d := randf_range(12.0, 30.0)
    var pos: Vector3 = p.global_position + Vector3(cos(a) * d, 1.5, sin(a) * d)
    var r := randf()
    if r < 0.4:
        Game.play3d(Game.s_creak, pos, 0.8, 50.0)
    elif r < 0.75:
        Game.play3d(Game.s_whisper, pos, 0.9, 40.0)
    else:
        Game.play3d(Game.s_roar, pos, 0.25, 90.0)
