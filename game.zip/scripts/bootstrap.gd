extends Node3D
# Builds the whole Dark Forest map, player, creature and HUD at runtime. Attached to main.tscn.
# World layout: spawn at +Z, cabin at origin (door on +Z side), exit gate at -Z.

const HALF := 90.0
const TREES := 320
const FOG := Color(0.045, 0.06, 0.08)

const UIScript = preload("res://scripts/ui.gd")
const PlayerScript = preload("res://scripts/player.gd")
const CreatureScript = preload("res://scripts/creature.gd")
const PickupScript = preload("res://scripts/pickup.gd")
const HideScript = preload("res://scripts/hidespot.gd")

var m_ground: StandardMaterial3D
var m_path: StandardMaterial3D
var m_trunk: StandardMaterial3D
var m_leaf: StandardMaterial3D
var m_wood: StandardMaterial3D
var m_dark: StandardMaterial3D
var m_roof: StandardMaterial3D
var m_metal: StandardMaterial3D
var flick := []
var gate_pos := Vector3(0, 1, -(HALF - 4.0))
var gate_msg_t := 0.0

func _ready():
    randomize()
    Game.reset()
    _env()
    m_ground = _mat(Color(0.04, 0.045, 0.04))
    m_path = _mat(Color(0.09, 0.07, 0.05))
    m_trunk = _mat(Color(0.06, 0.045, 0.035))
    m_leaf = _mat(Color(0.02, 0.05, 0.04))
    m_wood = _mat(Color(0.16, 0.1, 0.06))
    m_dark = _mat(Color(0.08, 0.05, 0.03))
    m_roof = _mat(Color(0.07, 0.07, 0.08))
    m_metal = _mat(Color(0.12, 0.1, 0.1))

    add_child(UIScript.new())
    _ground()
    _trees()
    _cabin()
    _gate()
    _bounds()

    var pl := PlayerScript.new()
    pl.position = Vector3(0, 0.1, HALF - 10.0)
    add_child(pl)

    _scatter()
    var cr := CreatureScript.new()
    cr.position = Vector3(35, 0, -35)
    add_child(cr)

    var wind := AudioStreamPlayer.new()
    wind.stream = Game.s_wind
    wind.volume_db = linear_to_db(0.3)
    add_child(wind)
    wind.play()
    Game.refresh_objective()

func _process(_d):
    var t := Time.get_ticks_msec() * 0.001
    for f in flick:
        var n := 0.5 + 0.25 * sin(t * 7.0 + f[2]) + 0.25 * sin(t * 13.1 + f[2] * 1.7)
        f[0].light_energy = f[1] * (0.15 if n < 0.25 else 0.7 + 0.3 * n)
    var p = Game.player
    if p != null and not Game.over and p.global_position.distance_to(gate_pos) < 4.0:
        if Game.keys >= Game.keys_needed:
            Game.win()
        elif t > gate_msg_t:
            gate_msg_t = t + 3.0
            Game.toast("The gate is locked. Keys: %d/%d" % [Game.keys, Game.keys_needed])

func _mat(c: Color, glow := false, emit := Color.BLACK) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = 1.0
    if glow:
        m.emission_enabled = true
        m.emission = emit
        m.emission_energy_multiplier = 1.5
    return m

func _env():
    var e := Environment.new()
    e.background_mode = Environment.BG_COLOR
    e.background_color = FOG
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color(0.06, 0.07, 0.10)
    e.ambient_light_energy = 0.6
    e.fog_enabled = true
    e.fog_light_color = FOG
    e.fog_density = 0.04
    var we := WorldEnvironment.new()
    we.environment = e
    add_child(we)
    var moon := DirectionalLight3D.new()
    moon.light_color = Color(0.45, 0.55, 0.8)
    moon.light_energy = 0.25
    moon.rotation_degrees = Vector3(-50, -30, 0)
    add_child(moon)

func _box(parent: Node, pos: Vector3, size: Vector3, mat: Material, collide := true) -> Node3D:
    var body: Node3D
    if collide:
        body = StaticBody3D.new()
    else:
        body = Node3D.new()
    body.position = pos
    parent.add_child(body)
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = mat
    body.add_child(mi)
    if collide:
        var cs := CollisionShape3D.new()
        var sh := BoxShape3D.new()
        sh.size = size
        cs.shape = sh
        body.add_child(cs)
    return body

func _ground():
    var g := StaticBody3D.new()
    add_child(g)
    var cs := CollisionShape3D.new()
    cs.shape = WorldBoundaryShape3D.new()
    g.add_child(cs)
    var mi := MeshInstance3D.new()
    var pm := PlaneMesh.new()
    pm.size = Vector2(HALF * 2.0, HALF * 2.0)
    mi.mesh = pm
    mi.material_override = m_ground
    g.add_child(mi)
    _box(self, Vector3(0, 0.02, 0), Vector3(4, 0.02, HALF * 2.0), m_path, false)

func _trees():
    var pts := []
    var tries := 0
    while pts.size() < TREES and tries < 3000:
        tries += 1
        var p := Vector2(randf_range(-HALF, HALF), randf_range(-HALF, HALF))
        if absf(p.x) < 4.0 or p.length() < 16.0:
            continue
        pts.append(p)
    var trunk_mm := MultiMesh.new()
    trunk_mm.transform_format = MultiMesh.TRANSFORM_3D
    var cyl := CylinderMesh.new()
    cyl.top_radius = 0.5
    cyl.bottom_radius = 0.5
    cyl.height = 1.0
    cyl.radial_segments = 8
    cyl.rings = 1
    trunk_mm.mesh = cyl
    trunk_mm.instance_count = pts.size()
    var leaf_mm := MultiMesh.new()
    leaf_mm.transform_format = MultiMesh.TRANSFORM_3D
    var sph := SphereMesh.new()
    sph.radial_segments = 8
    sph.rings = 4
    leaf_mm.mesh = sph
    leaf_mm.instance_count = pts.size()
    var body := StaticBody3D.new()
    add_child(body)
    for i in pts.size():
        var p: Vector2 = pts[i]
        var h := randf_range(11.0, 19.0)
        var w := randf_range(0.6, 1.0)
        trunk_mm.set_instance_transform(i, Transform3D(Basis.from_scale(Vector3(w, h, w)), Vector3(p.x, h / 2.0, p.y)))
        leaf_mm.set_instance_transform(i, Transform3D(Basis.from_scale(Vector3(4.5, h * 0.45, 4.5)), Vector3(p.x, h * 0.78, p.y)))
        var cs := CollisionShape3D.new()
        var sh := CylinderShape3D.new()
        sh.radius = w / 2.0
        sh.height = h
        cs.shape = sh
        cs.position = Vector3(p.x, h / 2.0, p.y)
        body.add_child(cs)
    var a := MultiMeshInstance3D.new()
    a.multimesh = trunk_mm
    a.material_override = m_trunk
    add_child(a)
    var b := MultiMeshInstance3D.new()
    b.multimesh = leaf_mm
    b.material_override = m_leaf
    add_child(b)

func _cabin():
    var c := Node3D.new()
    c.name = "Cabin"
    add_child(c)
    _box(c, Vector3(0, 0.03, 0), Vector3(10.6, 0.04, 8.6), m_dark, false)
    _box(c, Vector3(0, 1.5, -4.15), Vector3(10.6, 3, 0.3), m_wood)
    _box(c, Vector3(-5.15, 1.5, 0), Vector3(0.3, 3, 8.6), m_wood)
    _box(c, Vector3(5.15, 1.5, 0), Vector3(0.3, 3, 8.6), m_wood)
    _box(c, Vector3(-3.1, 1.5, 4.15), Vector3(4.4, 3, 0.3), m_wood)
    _box(c, Vector3(3.1, 1.5, 4.15), Vector3(4.4, 3, 0.3), m_wood)
    _box(c, Vector3(0, 2.7, 4.15), Vector3(1.8, 0.6, 0.3), m_wood)
    _box(c, Vector3(0, 3.1, 0), Vector3(11.6, 0.25, 9.6), m_roof)
    var lg := OmniLight3D.new()
    lg.position = Vector3(0, 2.6, 0)
    lg.light_color = Color(1.0, 0.7, 0.35)
    lg.omni_range = 9.0
    lg.light_energy = 1.2
    c.add_child(lg)
    flick.append([lg, 1.2, randf() * 50.0])

    # table (hide under) + document
    _box(c, Vector3(-2, 0.8, -1.5), Vector3(1.8, 0.1, 1.0), m_wood, false)
    for o in [Vector2(-0.8, -0.4), Vector2(0.8, -0.4), Vector2(-0.8, 0.4), Vector2(0.8, 0.4)]:
        _box(c, Vector3(-2 + o.x, 0.4, -1.5 + o.y), Vector3(0.1, 0.8, 0.1), m_wood, false)
    _hide(c, Vector3(-2, 0.4, -1.5), Vector3(-2, 0.4, -1.5), 0.0, Vector3(-2, 0.0, -0.1), 180.0)
    # bed (hide under)
    _box(c, Vector3(3.6, 0.6, -2.8), Vector3(2, 0.2, 1), m_metal, false)
    for o in [Vector2(-0.95, -0.45), Vector2(0.95, -0.45), Vector2(-0.95, 0.45), Vector2(0.95, 0.45)]:
        _box(c, Vector3(3.6 + o.x, 0.3, -2.8 + o.y), Vector3(0.1, 0.6, 0.1), m_dark, false)
    _hide(c, Vector3(3.6, 0.3, -2.8), Vector3(3.6, 0.3, -2.8), 180.0, Vector3(3.6, 0.0, -1.2), 180.0)
    # wardrobe (hide inside)
    _box(c, Vector3(-4.2, 1.2, -3.5), Vector3(1.3, 2.4, 0.7), m_dark)
    _hide(c, Vector3(-4.2, 1.2, -3.5), Vector3(-4.2, 1.5, -3.5), 180.0, Vector3(-4.2, 0.0, -2.4), 180.0)
    # shelf with key
    _box(c, Vector3(4.7, 1.0, 1.5), Vector3(0.6, 0.1, 1.4), m_wood)
    _item("key", Vector3(4.6, 1.3, 1.5))
    _item("doc", Vector3(-2, 0.95, -1.5), "Note: \"It only walks when it thinks the woods are empty. Do not run in the dark.\"")
    _item("battery", Vector3(-4.5, 0.3, 3.0))
    _item("battery", Vector3(2.0, 0.3, -3.3))
    _item("medkit", Vector3(0.5, 0.3, -3.4))

func _hide(parent: Node, pos: Vector3, cam_pos: Vector3, cam_yaw: float, exit_pos: Vector3, exit_yaw: float):
    var h := HideScript.new()
    h.position = pos
    h.cam_pos = cam_pos
    h.cam_yaw = cam_yaw
    h.exit_pos = exit_pos
    h.exit_yaw = exit_yaw
    parent.add_child(h)

func _gate():
    var g := Node3D.new()
    g.position = Vector3(0, 0, gate_pos.z)
    add_child(g)
    _box(g, Vector3(-2.6, 3, 0), Vector3(0.6, 6, 0.6), m_metal)
    _box(g, Vector3(2.6, 3, 0), Vector3(0.6, 6, 0.6), m_metal)
    _box(g, Vector3(-1.2, 2, 0), Vector3(2.2, 4, 0.2), m_metal)
    _box(g, Vector3(1.2, 2, 0), Vector3(2.2, 4, 0.2), m_metal)
    var l := OmniLight3D.new()
    l.position = Vector3(0, 3, 2)
    l.light_color = Color(1.0, 0.1, 0.05)
    l.omni_range = 14.0
    l.light_energy = 2.0
    g.add_child(l)

func _bounds():
    var e := HALF + 2.0
    for d in [Vector3(0, 0, e), Vector3(0, 0, -e), Vector3(e, 0, 0), Vector3(-e, 0, 0)]:
        var sz := Vector3(2, 10, HALF * 2 + 8) if d.x != 0.0 else Vector3(HALF * 2 + 8, 10, 2)
        _box(self, d + Vector3(0, 5, 0), sz, m_ground, true).visible = false

func _rand_spot() -> Vector3:
    for i in 50:
        var v := Vector3(randf_range(-HALF + 6, HALF - 6), 0.4, randf_range(-HALF + 6, HALF - 6))
        if v.length() > 17.0 and v.distance_to(Vector3(0, 0.4, HALF - 10)) > 12.0:
            return v
    return Vector3(30, 0.4, 30)

func _scatter():
    _item("key", Vector3(-55, 0.4, 40))
    _item("key", Vector3(50, 0.4, -55))
    for i in 4:
        _item("battery", _rand_spot())
    for i in 3:
        _item("medkit", _rand_spot())
    for i in 3:
        _item("ammo", _rand_spot())
    _item("doc", _rand_spot(), "Torn page: \"The gate needs three keys. One is in the cabin. The others... the trees keep them.\"")

func _item(type: String, pos: Vector3, note := ""):
    var pk := PickupScript.new()
    pk.type = type
    pk.note = note
    pk.position = pos
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    match type:
        "key":
            bm.size = Vector3(0.12, 0.04, 0.3)
            mi.material_override = _mat(Color(0.9, 0.7, 0.1), true, Color(1, 0.7, 0.1))
        "battery":
            var cm := CylinderMesh.new()
            cm.top_radius = 0.05
            cm.bottom_radius = 0.05
            cm.height = 0.28
            mi.mesh = cm
            mi.material_override = _mat(Color(0.1, 0.6, 0.2), true, Color(0.1, 0.8, 0.2))
        "medkit":
            bm.size = Vector3(0.35, 0.2, 0.25)
            mi.material_override = _mat(Color(0.85, 0.85, 0.85))
        "ammo":
            bm.size = Vector3(0.25, 0.15, 0.15)
            mi.material_override = _mat(Color(0.25, 0.28, 0.15))
        _:
            bm.size = Vector3(0.25, 0.02, 0.33)
            mi.material_override = _mat(Color(0.8, 0.75, 0.6))
    if type != "battery":
        mi.mesh = bm
    pk.add_child(mi)
    pk.visual = mi
    if type == "key":
        var l := OmniLight3D.new()
        l.position = Vector3(0, 0.4, 0)
        l.omni_range = 3.5
        l.light_energy = 0.8
        l.light_color = Color(1, 0.75, 0.2)
        pk.add_child(l)
    add_child(pk)
