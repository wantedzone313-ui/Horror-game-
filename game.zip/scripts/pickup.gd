extends Node3D
# Interactable item shown as a billboard sprite cut from your reference images.
# type: battery, medkit, key, ammo, fuel, can, torch, gun, doc

const TEX := {
    "battery": preload("res://tex/battery.png"),
    "medkit": preload("res://tex/medkit.png"),
    "key": preload("res://tex/key.png"),
    "ammo": preload("res://tex/ammo.png"),
    "fuel": preload("res://tex/jerrycan.png"),
    "can": preload("res://tex/can.png"),
    "torch": preload("res://tex/torch.png"),
    "gun": preload("res://tex/gun.png"),
}
const WIDTH := {"battery": 0.16, "medkit": 0.4, "key": 0.28, "ammo": 0.38, "fuel": 0.36, "can": 0.2, "torch": 0.45, "gun": 0.62}

var type := "battery"
var note := ""
var visual: Node3D
var y0 := 0.0

func _ready():
    add_to_group("interactable")
    if TEX.has(type):
        var sp := Sprite3D.new()
        sp.texture = TEX[type]
        var w: float = WIDTH[type]
        sp.pixel_size = w / float(sp.texture.get_width())
        sp.billboard = BaseMaterial3D.BILLBOARD_FIXED_Y
        sp.shaded = false
        sp.modulate = Color(0.8, 0.8, 0.85)
        sp.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
        sp.position.y = sp.texture.get_height() * sp.pixel_size * 0.5
        add_child(sp)
        visual = sp
    else:
        var mi := MeshInstance3D.new()
        var bm := BoxMesh.new()
        bm.size = Vector3(0.25, 0.02, 0.33)
        mi.mesh = bm
        var m := StandardMaterial3D.new()
        m.albedo_color = Color(0.8, 0.75, 0.6)
        mi.material_override = m
        mi.position.y = 0.1
        add_child(mi)
        visual = mi
    y0 = visual.position.y

func _process(_delta):
    if visual:
        visual.position.y = y0 + sin(Time.get_ticks_msec() * 0.002 + position.x) * 0.03
        if type == "doc":
            visual.rotate_y(_delta * 0.9)

func prompt() -> String:
    return "pickup"

func interact(_p):
    match type:
        "battery":
            Game.batteries += 1
            Game.toast("Picked up: Flashlight Battery")
        "medkit":
            Game.medkits += 1
            Game.toast("Picked up: Medkit")
        "ammo":
            Game.ammo += 6
            Game.toast("Picked up: Shotgun shells x6")
        "fuel":
            Game.fuel_cans += 1
            Game.toast("Picked up: Petrol can (use on the car)")
        "can":
            Game.throwables += 1
            Game.toast("Picked up: Tin can - throw it to distract the creature")
        "torch":
            Game.has_torch = true
            Game.toast("You found a torch! Tap the torch button.")
            Game.player.get_torch()
            Game.refresh_objective()
        "gun":
            Game.has_gun = true
            Game.ammo += 4
            Game.toast("Picked up: Plasma rifle (stuns the creature)")
            Game.player.get_gun()
        "key":
            Game.keys += 1
            Game.toast("Picked up: Gate Key")
            Game.refresh_objective()
        "doc":
            Game.docs += 1
            Game.toast(note)
    Game.play2d(Game.s_click, 0.8)
    Game.player.refresh_battery()
    Game.ui.refresh_inventory()
    queue_free()
