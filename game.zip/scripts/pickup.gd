extends Node3D
# Interactable item. type: battery, can, medkit, ammo, fuel, torch, gun, key1, key2, key3, doc
# Uses your .glb models where available (sprites for battery / tin can).

const Assets = preload("res://scripts/assets.gd")
const SPRITES := {
    "battery": preload("res://tex/battery.png"),
    "can": preload("res://tex/can.png"),
}
const SPRITE_W := {"battery": 0.16, "can": 0.2}
const MODELS := {"medkit": "medkit", "ammo": "ammobox", "fuel": "jerrycan", "gun": "gun", "key1": "key1", "key2": "key2", "key3": "key3"}
const KEY_NAMES := {"key1": "Brass key", "key2": "Silver key", "key3": "Rusty key"}

var type := "battery"
var note := ""
var visual: Node3D
var y0 := 0.0
var spin := true

func _ready():
    add_to_group("interactable")
    if SPRITES.has(type):
        var sp := Sprite3D.new()
        sp.texture = SPRITES[type]
        sp.pixel_size = float(SPRITE_W[type]) / float(sp.texture.get_width())
        sp.billboard = BaseMaterial3D.BILLBOARD_FIXED_Y
        sp.shaded = false
        sp.modulate = Color(0.8, 0.8, 0.85)
        sp.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
        sp.position.y = sp.texture.get_height() * sp.pixel_size * 0.5
        add_child(sp)
        visual = sp
        spin = false
    elif MODELS.has(type):
        var m := Assets.load_model(MODELS[type])
        if m != null:
            add_child(m)
            visual = m
            if type == "gun":
                m.rotation_degrees.z = 8.0
        if visual == null:
            _fallback()
    elif type == "torch":
        _make_torch()
    else:
        _fallback()
    y0 = visual.position.y
    if type.begins_with("key"):
        # keys lie flat on the ground: lift them a little and give them a soft glow so they can be found
        visual.position.y += 0.05
        y0 = visual.position.y
        var l := OmniLight3D.new()
        l.omni_range = 3.0
        l.light_energy = 0.5
        l.light_color = Color(1.0, 0.8, 0.4)
        l.position = Vector3(0, 0.4, 0)
        add_child(l)

func _fallback():
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = Vector3(0.25, 0.02, 0.33)
    mi.mesh = bm
    var m := StandardMaterial3D.new()
    m.albedo_color = Color(0.8, 0.75, 0.6)
    mi.material_override = m
    mi.position.y = 0.1
    add_child(mi)
    visual = mi

func _make_torch():
    var t := Node3D.new()
    var body := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 0.035
    cm.bottom_radius = 0.03
    cm.height = 0.28
    body.mesh = cm
    var bm := StandardMaterial3D.new()
    bm.albedo_color = Color(0.05, 0.05, 0.06)
    bm.metallic = 0.7
    bm.roughness = 0.4
    body.material_override = bm
    body.rotation_degrees.z = 90.0
    t.add_child(body)
    var head := MeshInstance3D.new()
    var hm := CylinderMesh.new()
    hm.top_radius = 0.06
    hm.bottom_radius = 0.035
    hm.height = 0.09
    head.mesh = hm
    head.material_override = bm
    head.rotation_degrees.z = 90.0
    head.position = Vector3(-0.17, 0, 0)
    t.add_child(head)
    var lens := MeshInstance3D.new()
    var lm := CylinderMesh.new()
    lm.top_radius = 0.052
    lm.bottom_radius = 0.052
    lm.height = 0.01
    lens.mesh = lm
    var em := StandardMaterial3D.new()
    em.albedo_color = Color(1, 0.95, 0.7)
    em.emission_enabled = true
    em.emission = Color(1, 0.95, 0.7)
    em.emission_energy_multiplier = 2.0
    lens.material_override = em
    lens.rotation_degrees.z = 90.0
    lens.position = Vector3(-0.22, 0, 0)
    t.add_child(lens)
    t.position.y = 0.08
    add_child(t)
    visual = t
    var l := OmniLight3D.new()
    l.omni_range = 3.5
    l.light_energy = 0.6
    l.light_color = Color(1.0, 0.95, 0.7)
    l.position = Vector3(0, 0.4, 0)
    add_child(l)

func _process(delta):
    if visual:
        visual.position.y = y0 + sin(Time.get_ticks_msec() * 0.002 + position.x) * 0.03
        if spin or type == "doc":
            visual.rotate_y(delta * 0.9)

func prompt() -> String:
    return "pickup"

func interact(_p):
    match type:
        "battery":
            Game.batteries += 1
            Game.toast("Picked up: Torch battery")
        "medkit":
            Game.medkits += 1
            Game.toast("Picked up: Medkit")
        "ammo":
            Game.ammo += 6
            Game.toast("Picked up: Ammo box (+6)")
        "fuel":
            Game.fuel_cans += 1
            Game.toast("Picked up: Petrol can (use it on the car)")
        "can":
            Game.throwables += 1
            Game.toast("Picked up: Tin can - throw it to distract the creature")
        "torch":
            Game.has_torch = true
            Game.toast("You found a torch! Tap the torch button.")
            Game.player.get_torch()
            Game.refresh_objective()
        "gun":
            Game.has_gun = true
            Game.ammo += 4
            Game.toast("Picked up: Steam rifle (stuns the creature)")
            Game.player.get_gun()
        "key1", "key2", "key3":
            Game.keys += 1
            Game.toast("Picked up: %s (%d/%d)" % [KEY_NAMES[type], Game.keys, Game.keys_needed])
            Game.refresh_objective()
        "doc":
            Game.docs += 1
            Game.toast(note)
    Game.play2d(Game.s_click, 0.8)
    Game.player.refresh_battery()
    Game.ui.refresh_inventory()
    queue_free()
