extends Node3D
# Interactable item. type: battery, medkit, key, ammo, doc

var type := "battery"
var note := ""
var visual: Node3D
var y0 := 0.0

func _ready():
    add_to_group("interactable")
    if visual:
        y0 = visual.position.y

func _process(delta):
    if visual:
        visual.rotate_y(delta * 0.9)
        visual.position.y = y0 + sin(Time.get_ticks_msec() * 0.002) * 0.04

func prompt() -> String:
    return "PICK UP"

func interact(_p):
    match type:
        "battery":
            Game.batteries += 1
            Game.toast("Picked up: Flashlight Battery")
        "medkit":
            Game.medkits += 1
            Game.toast("Picked up: Medkit")
        "ammo":
            Game.ammo += 6
            Game.toast("Picked up: Ammo x6")
        "key":
            Game.keys += 1
            Game.toast("Picked up: Gate Key")
            Game.refresh_objective()
        "doc":
            Game.docs += 1
            Game.toast(note)
    Game.play2d(Game.s_click, 0.8)
    Game.player.refresh_battery()
    Game.ui.refresh_inventory()
    queue_free()
