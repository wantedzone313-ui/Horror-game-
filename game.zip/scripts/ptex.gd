extends RefCounted
# Procedural textures + normal maps (no image files needed).

static func material(img: Image, tint: Color, tile: float, nstr := 6.0, rough := 0.95) -> StandardMaterial3D:
    var n: Image = img.duplicate()
    n.convert(Image.FORMAT_RGB8)
    n.bump_map_to_normal_map(nstr)
    n.generate_mipmaps()
    img.generate_mipmaps()
    var m := StandardMaterial3D.new()
    m.albedo_texture = ImageTexture.create_from_image(img)
    m.albedo_color = tint
    m.normal_enabled = true
    m.normal_scale = 1.3
    m.normal_texture = ImageTexture.create_from_image(n)
    m.roughness = rough
    m.uv1_triplanar = true
    m.uv1_world_triplanar = true
    m.uv1_scale = Vector3(tile, tile, tile)
    return m

static func img_wood() -> Image:
    var w := 128
    var img := Image.create(w, w, false, Image.FORMAT_RGB8)
    var n := FastNoiseLite.new()
    n.seed = 7
    n.frequency = 0.02
    for y in w:
        var row := floori(y / 32.0)
        var seam := (y % 32) < 2
        for x in w:
            var g := n.get_noise_2d(x * 0.12 + row * 41.0, y * 1.6) * 0.5 + 0.5
            var v := 0.45 + g * 0.55
            if seam:
                v *= 0.3
            img.set_pixel(x, y, Color(v, v, v))
    return img

static func img_bark() -> Image:
    var w := 128
    var img := Image.create(w, w, false, Image.FORMAT_RGB8)
    var n := FastNoiseLite.new()
    n.seed = 11
    n.frequency = 0.05
    var n2 := FastNoiseLite.new()
    n2.seed = 5
    n2.frequency = 0.06
    for y in w:
        for x in w:
            var g := n.get_noise_2d(x * 1.8, y * 0.1) * 0.5 + 0.5
            var g2 := n2.get_noise_2d(x * 0.5, y * 0.5) * 0.5 + 0.5
            var v := 0.15 + g * 0.65 + g2 * 0.2
            img.set_pixel(x, y, Color(v, v, v))
    return img

static func img_shingle() -> Image:
    var w := 128
    var img := Image.create(w, w, false, Image.FORMAT_RGB8)
    var n := FastNoiseLite.new()
    n.seed = 21
    n.frequency = 0.08
    for y in w:
        var row := floori(y / 16.0)
        for x in w:
            var sx := (x + row * 11) % 24
            var g := n.get_noise_2d(x, y) * 0.5 + 0.5
            var v := 0.5 + g * 0.5
            if (y % 16) < 2 or sx < 2:
                v *= 0.3
            img.set_pixel(x, y, Color(v, v, v))
    return img

static func img_ground() -> Image:
    var n := FastNoiseLite.new()
    n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    n.fractal_type = FastNoiseLite.FRACTAL_FBM
    n.fractal_octaves = 4
    n.frequency = 0.04
    n.seed = 3
    return n.get_seamless_image(256, 256)

static func img_stone() -> Image:
    var n := FastNoiseLite.new()
    n.noise_type = FastNoiseLite.TYPE_CELLULAR
    n.cellular_return_type = FastNoiseLite.RETURN_DISTANCE2_SUB
    n.frequency = 0.05
    n.seed = 9
    return n.get_seamless_image(128, 128)
