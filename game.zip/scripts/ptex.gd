extends RefCounted
# Procedural textures + normal maps (no image files needed).

static func material(img: Image, tint: Color, tile: float, nstr := 6.0, rough := 0.95) -> StandardMaterial3D:
    var n: Image = img.duplicate()
    n.convert(Image.FORMAT_RGB8)
    n.bump_map_to_normal_map(nstr)
    n.generate_mipmaps()
    img.generate_mipmaps()
    var m := StandardMaterial3D.new()
    m.albedo_texture = ImageTexture.create_from_image(img)
    m.albedo_color = tint
    m.normal_enabled = true
    m.normal_scale = 1.3
    m.normal_texture = ImageTexture.create_from_image(n)
    m.roughness = rough
    m.uv1_triplanar = true
    m.uv1_world_triplanar = true
    m.uv1_scale = Vector3(tile, tile, tile)
    return m

static func img_wood() -> Image:
    var w := 128
    var img := Image.create(w, w, false, Image.FORMAT_RGB8)
    var n := FastNoiseLite.new()
    n.seed = 7
    n.frequency = 0.02
    for y in w:
        var row := floori(y / 32.0)
        var seam := (y % 32) < 2
        for x in w:
            var g := n.get_noise_2d(x * 0.12 + row * 41.0, y * 1.6) * 0.5 + 0.5
            var v := 0.45 + g * 0.55
            if seam:
                v *= 0.3
            img.set_pixel(x, y, Color(v, v, v))
    return img

static func img_bark() -> Image:
    var w := 128
    var img := Image.create(w, w, false, Image.FORMAT_RGB8)
    var n := FastNoiseLite.new()
    n.seed = 11
    n.frequency = 0.05
    var n2 := FastNoiseLite.new()
    n2.seed = 5
    n2.frequency = 0.06
    for y in w:
        for x in w:
            var g := n.get_noise_2d(x * 1.8, y * 0.1) * 0.5 + 0.5
            var g2 := n2.get_noise_2d(x * 0.5, y * 0.5) * 0.5 + 0.5
            var v := 0.15 + g * 0.65 + g2 * 0.2
            img.set_pixel(x, y, Color(v, v, v))
    return img

static func img_shingle() -> Image:
    var w := 128
    var img := Image.create(w, w, false, Image.FORMAT_RGB8)
    var n := FastNoiseLite.new()
    n.seed = 21
    n.frequency = 0.08
    for y in w:
        var row := floori(y / 16.0)
        for x in w:
            var sx := (x + row * 11) % 24
            var g := n.get_noise_2d(x, y) * 0.5 + 0.5
            var v := 0.5 + g * 0.5
            if (y % 16) < 2 or sx < 2:
                v *= 0.3
            img.set_pixel(x, y, Color(v, v, v))
    return img

static func img_ground() -> Image:
    var n := FastNoiseLite.new()
    n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    n.fractal_type = FastNoiseLite.FRACTAL_FBM
    n.fractal_octaves = 4
    n.frequency = 0.04
    n.seed = 3
    return n.get_seamless_image(256, 256)

static func img_stone() -> Image:
    var n := FastNoiseLite.new()
    n.noise_type = FastNoiseLite.TYPE_CELLULAR
    n.cellular_return_type = FastNoiseLite.RETURN_DISTANCE2_SUB
    n.frequency = 0.05
    n.seed = 9
    return n.get_seamless_image(128, 128)

# cream paint with orange rust patches (RGB texture, use tint white)
static func img_rust() -> Image:
    var w := 128
    var img := Image.create(w, w, false, Image.FORMAT_RGB8)
    var n := FastNoiseLite.new()
    n.seed = 31
    n.frequency = 0.04
    n.fractal_type = FastNoiseLite.FRACTAL_FBM
    var n2 := FastNoiseLite.new()
    n2.seed = 77
    n2.frequency = 0.12
    var paint := Color(0.62, 0.6, 0.48)
    var rust := Color(0.42, 0.2, 0.09)
    for y in w:
        for x in w:
            var g := n.get_noise_2d(x, y) * 0.5 + 0.5
            var f := n2.get_noise_2d(x, y) * 0.5 + 0.5
            var k := smoothstep(0.42, 0.58, g)
            var c := paint.lerp(rust, k) * (0.7 + 0.3 * f)
            img.set_pixel(x, y, c)
    return img

# shattered glass: transparent with radial cracks and a hole
static func img_cracks() -> Image:
    var w := 128
    var img := Image.create(w, w, false, Image.FORMAT_RGBA8)
    img.fill(Color(0.05, 0.07, 0.08, 0.6))
    var c := Vector2(70, 48)
    for i in 16:
        var a := randf() * TAU
        var l := randf_range(30.0, 90.0)
        for s in 90:
            var p := c + Vector2.from_angle(a + sin(s * 0.3) * 0.05) * (l * s / 90.0)
            if p.x >= 0 and p.y >= 0 and p.x < w and p.y < w:
                img.set_pixelv(Vector2i(p), Color(0.85, 0.9, 0.95, 0.9))
    for r in [10, 22, 36]:
        for s in 120:
            var a2 := TAU * s / 120.0
            var p2 := c + Vector2.from_angle(a2) * (r + randf() * 2.0)
            if p2.x >= 0 and p2.y >= 0 and p2.x < w and p2.y < w:
                img.set_pixelv(Vector2i(p2), Color(0.85, 0.9, 0.95, 0.7))
    for y in w:
        for x in w:
            if Vector2(x, y).distance_to(c) < 9.0:
                img.set_pixel(x, y, Color(0, 0, 0, 0))
    return img
