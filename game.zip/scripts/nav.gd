extends RefCounted
# Waypoint graph for the mansion (2 floors) so the creature can walk through doors and up the stairs.

const F1 := 4.3
const OUT := Vector3(0, 0, 14.5)
var astar := AStar3D.new()
var ids := {}
var rooms := []   # {floor, rect: Rect2(x,z,w,h), nodes: Array of ids}
var centers := []
var _n := 0

func _p(name: String, pos: Vector3) -> int:
    ids[name] = _n
    astar.add_point(_n, pos)
    _n += 1
    return ids[name]

func _l(a: String, b: String):
    astar.connect_points(ids[a], ids[b], true)

func _k(side: String, f: int, z: float) -> String:
    return "%s%d_%d" % [side, f, int(z * 10.0)]

func _init():
    var hall_nodes := [[], []]
    for f in 2:
        var y := f * F1
        var zs := [10.5, 8.0, 2.0, 0.0, -8.0]
        for z in zs:
            _p(_k("W", f, z), Vector3(-2.7, y, z))
            _p(_k("E", f, z), Vector3(2.7, y, z))
            hall_nodes[f].append(ids[_k("W", f, z)])
            hall_nodes[f].append(ids[_k("E", f, z)])
        for i in zs.size() - 1:
            _l(_k("W", f, zs[i]), _k("W", f, zs[i + 1]))
            _l(_k("E", f, zs[i]), _k("E", f, zs[i + 1]))
        var cross := [10.5, 2.0, 0.0, -8.0] if f == 0 else [2.0, 0.0, -8.0]
        for z in cross:
            _l(_k("W", f, z), _k("E", f, z))
        # rooms off the hall
        var east := [[8.0, "liv"], [0.0, "kit"], [-8.0, "din"]] if f == 0 else [[8.0, "mas"], [0.0, "bd2"], [-8.0, "bth"]]
        var west := [[8.0, "stu"], [2.0, "was"], [-8.0, "gst"]] if f == 0 else [[8.0, "bd3"], [2.0, "sto"], [-8.0, "bd4"]]
        for e in east:
            _room_door(f, y, 4.0, e[0], 9.5, e[1], "E")
        for w in west:
            var cz: float = w[0] if w[0] != 2.0 else 0.0
            _room_door(f, y, -4.0, w[0], -9.5 if w[1] != "was" else -6.75, w[1], "W", cz)
    # ground-floor extras
    _p("hF", Vector3(0, 0, 11.0))
    _p("C0", Vector3(0, 0, 10.5))
    _l("hF", "C0")
    _l("C0", _k("W", 0, 10.5))
    _l("C0", _k("E", 0, 10.5))
    _p("tox", Vector3(-9.5, 0, -1.0))
    _p("toilet", Vector3(-12.25, 0, 0.0))
    _l("tox", "c0was")
    _l("tox", "toilet")
    centers.append(ids["toilet"])
    _p("UTOP", Vector3(0, F1, 2.5))
    _l("UTOP", _k("W", 1, 2.0))
    _l("UTOP", _k("E", 1, 2.0))
    _l("C0", "UTOP")
    # room rectangles for locating a point
    var gf := [[-4, -12, 4, 12, "hall"], [4, 4, 15, 12, "liv"], [4, -4, 15, 4, "kit"], [4, -12, 15, -4, "din"], [-15, 4, -4, 12, "stu"], [-9.5, -4, -4, 4, "was"], [-15, -4, -9.5, 4, "toilet"], [-15, -12, -4, -4, "gst"]]
    var uf := [[-4, -12, 4, 12, "hall"], [4, 4, 15, 12, "mas"], [4, -4, 15, 4, "bd2"], [4, -12, 15, -4, "bth"], [-15, 4, -4, 12, "bd3"], [-15, -4, -4, 4, "sto"], [-15, -12, -4, -4, "bd4"]]
    for f in 2:
        for r in (gf if f == 0 else uf):
            var nodes := []
            if r[4] == "hall":
                nodes = hall_nodes[f].duplicate()
                if f == 0:
                    nodes.append(ids["hF"])
                    nodes.append(ids["C0"])
            else:
                nodes = [ids["c%d%s" % [f, r[4]]]] if ids.has("c%d%s" % [f, r[4]]) else []
                if r[4] == "toilet":
                    nodes = [ids["toilet"], ids["tox"]]
                if r[4] == "was":
                    nodes.append(ids["tox"])
            rooms.append({"floor": f, "rect": Rect2(r[0], r[1], r[2] - r[0], r[3] - r[1]), "nodes": nodes})

func _room_door(f: int, y: float, dx: float, dz: float, cx: float, name: String, side: String, cz: float = 9999.0):
    var zc := dz if cz == 9999.0 else cz
    var door := "d%d%s" % [f, name]
    var cen := "c%d%s" % [f, name]
    _p(door, Vector3(dx, y, dz))
    _p(cen, Vector3(cx if side == "W" else cx, y, zc))
    _l(door, _k(side, f, dz))
    _l(door, cen)
    centers.append(ids[cen])

func inside(p: Vector3) -> bool:
    return absf(p.x) < 15.3 and absf(p.z) < 12.3

func _room_nodes(p: Vector3) -> Array:
    var f := 1 if p.y > 2.6 else 0
    for r in rooms:
        if r["floor"] == f and r["rect"].has_point(Vector2(p.x, p.z)):
            return r["nodes"]
    return []

func _nearest(p: Vector3) -> int:
    var cand: Array = _room_nodes(p)
    if cand.is_empty():
        for i in _n:
            cand.append(i)
    var best := -1
    var bd := 1e9
    for id in cand:
        var q: Vector3 = astar.get_point_position(id)
        if absf(q.y - p.y) > 2.6 and not cand.is_empty() and _room_nodes(p).is_empty() == false:
            continue
        var d := Vector2(q.x - p.x, q.z - p.z).length()
        if d < bd:
            bd = d
            best = id
    return best

func find_path(from: Vector3, to: Vector3) -> Array:
    var ia := inside(from)
    var ib := inside(to)
    if not ia and not ib:
        return [to]
    var pts := []
    var a_id: int
    var b_id: int
    if ia:
        a_id = _nearest(from)
    else:
        pts.append(OUT)
        a_id = ids["hF"]
    if ib:
        b_id = _nearest(to)
    else:
        b_id = ids["hF"]
    for id in astar.get_id_path(a_id, b_id):
        pts.append(astar.get_point_position(id))
    if not ib:
        pts.append(OUT)
    pts.append(to)
    return pts

func random_point() -> Vector3:
    var id: int = centers[randi() % centers.size()]
    var p: Vector3 = astar.get_point_position(id)
    return p + Vector3(randf_range(-1.5, 1.5), 0, randf_range(-1.0, 1.0))
