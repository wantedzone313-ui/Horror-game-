extends Node
# Autoload "Game": shared state, inventory, procedural sounds, win/lose flow.

const SR := 16000

var keys := 0
var batteries := 0
var medkits := 0
var ammo := 0
var fuel_cans := 0
var throwables := 0
var docs := 0
var keys_needed := 3
var has_torch := false
var has_gun := false
var over := false
var player = null
var ui = null
var creature = null
var nav: AStar3D = null
var heart_player: AudioStreamPlayer

var s_step: AudioStreamWAV
var s_click: AudioStreamWAV
var s_scare: AudioStreamWAV
var s_drone: AudioStreamWAV
var s_breath: AudioStreamWAV
var s_growl: AudioStreamWAV
var s_roar: AudioStreamWAV
var s_heart: AudioStreamWAV
var s_shot: AudioStreamWAV
var s_clang: AudioStreamWAV
var s_creak: AudioStreamWAV
var s_whisper: AudioStreamWAV
var s_engine: AudioStreamWAV

func _ready():
    process_mode = Node.PROCESS_MODE_ALWAYS
    s_step = _make(_noise(0.18, 0.15, 3.0, 2.5, 0.0))
    s_breath = _make(_noise(3.0, 0.05, 0.0, 5.0, 2.0 / 3.0 * 3.0), true)
    s_click = _gen_click()
    s_drone = _gen_drone()
    s_growl = _gen_growl()
    s_roar = _gen_roar(2.4, 1.0)
    s_scare = _gen_scare()
    s_heart = _gen_heart()
    s_shot = _gen_shot()
    s_clang = _gen_clang()
    s_creak = _gen_creak()
    s_whisper = _gen_whisper()
    s_engine = _gen_engine()
    heart_player = AudioStreamPlayer.new()
    heart_player.stream = s_heart
    heart_player.volume_db = linear_to_db(0.8)
    add_child(heart_player)

# ---------- sound synthesis ----------
func _make(samples: PackedFloat32Array, loop := false) -> AudioStreamWAV:
    var w := AudioStreamWAV.new()
    w.format = AudioStreamWAV.FORMAT_16_BITS
    w.mix_rate = SR
    w.stereo = false
    var b := PackedByteArray()
    b.resize(samples.size() * 2)
    for i in samples.size():
        b.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32000.0))
    w.data = b
    if loop:
        w.loop_mode = AudioStreamWAV.LOOP_FORWARD
        w.loop_begin = 0
        w.loop_end = samples.size()
    return w

func _buf(sec: float) -> PackedFloat32Array:
    var o := PackedFloat32Array()
    o.resize(int(SR * sec))
    return o

func _noise(sec: float, lp_k: float, env_pow: float, gain: float, mod_hz: float) -> PackedFloat32Array:
    var o := _buf(sec)
    var n := o.size()
    var lp := 0.0
    for i in n:
        var t := float(i) / n
        lp += (randf() * 2.0 - 1.0 - lp) * lp_k
        var a := 1.0
        if env_pow > 0.0:
            a = pow(1.0 - t, env_pow)
        if mod_hz > 0.0:
            var m := 0.5 + 0.5 * sin(t * TAU * mod_hz)
            a *= m * m
        o[i] = lp * a * gain
    return o

func _gen_click() -> AudioStreamWAV:
    var o := _buf(0.06)
    for i in o.size():
        var t := float(i) / o.size()
        o[i] = sin(i * 0.6) * pow(1.0 - t, 4.0) * 0.7
    return _make(o)

# dark mysterious drone: detuned low tones + thin high whine (4 s seamless loop)
func _gen_drone() -> AudioStreamWAV:
    var o := _buf(4.0)
    var lp := 0.0
    for i in o.size():
        var t := float(i) / SR
        var am := 0.6 + 0.4 * sin(t * TAU * 0.25)
        var s := sin(t * TAU * 55.0) * 0.5 + sin(t * TAU * 58.25) * 0.4 + sin(t * TAU * 82.5) * 0.25
        var hi := sin(t * TAU * 1760.0 + 3.0 * sin(t * TAU * 0.5)) * 0.03 * (0.5 + 0.5 * sin(t * TAU * 0.25 + 1.0))
        lp += (randf() * 2.0 - 1.0 - lp) * 0.01
        o[i] = (s * am + hi + lp * 2.0) * 0.5
    return _make(o, true)

func _gen_growl() -> AudioStreamWAV:
    var o := _buf(1.0)
    var lp := 0.0
    for i in o.size():
        var t := float(i) / SR
        var saw := fposmod(t * 62.0, 1.0) * 2.0 - 1.0
        var am := 0.5 + 0.5 * sin(t * TAU * 9.0)
        lp += (randf() * 2.0 - 1.0 - lp) * 0.2
        o[i] = (saw * 0.5 + lp * 0.6) * (0.4 + 0.6 * am) * 0.9
    return _make(o, true)

# terrifying shriek: sweeping screech + vibrato + noise + low growl
func _gen_roar(sec: float, vol: float) -> AudioStreamWAV:
    var o := _buf(sec)
    var n := o.size()
    var ph := 0.0
    var ph2 := 0.0
    var lp := 0.0
    for i in n:
        var t := float(i) / n
        var f := 320.0 + 900.0 * sin(PI * t) + 60.0 * sin(t * sec * TAU * 28.0)
        ph += TAU * f / SR
        ph2 += TAU * (f * 1.51) / SR
        lp += (randf() * 2.0 - 1.0 - lp) * 0.4
        var saw := fposmod(ph / TAU, 1.0) * 2.0 - 1.0
        var env := minf(1.0, t * 40.0) * (1.0 - pow(t, 3.0))
        var low := sin(t * sec * TAU * 70.0) * 0.5
        o[i] = (saw * 0.45 + sin(ph2) * 0.2 + lp * 0.35 + low * 0.3) * env * vol
    return _make(o)

func _gen_scare() -> AudioStreamWAV:
    var o := _buf(2.2)
    var n := o.size()
    var ph := 0.0
    for i in n:
        var t := float(i) / n
        var tt := float(i) / SR
        var f := 500.0 + 1700.0 * t + 80.0 * sin(tt * TAU * 33.0)
        ph += TAU * f / SR
        var saw := fposmod(ph / TAU, 1.0) * 2.0 - 1.0
        var env := pow(1.0 - t, 1.2)
        var boom := sin(tt * TAU * 42.0) * exp(-tt * 5.0) * 1.2
        var burst := (randf() * 2.0 - 1.0) * exp(-tt * 9.0) * 1.0
        o[i] = saw * 0.55 * env + sin(ph * 0.5) * 0.3 * env + boom + burst
    return _make(o)

func _gen_heart() -> AudioStreamWAV:
    var o := _buf(1.0)
    for i in o.size():
        var t := float(i) / SR
        var a := sin(TAU * 52.0 * t) * exp(-t * 16.0)
        var b := 0.0
        if t > 0.22:
            b = sin(TAU * 48.0 * (t - 0.22)) * exp(-(t - 0.22) * 18.0) * 0.8
        o[i] = (a + b) * 1.4
    return _make(o, true)

func _gen_shot() -> AudioStreamWAV:
    var o := _buf(0.5)
    for i in o.size():
        var t := float(i) / SR
        o[i] = (randf() * 2.0 - 1.0) * exp(-t * 16.0) + sin(TAU * 90.0 * t) * exp(-t * 10.0) * 1.2
    return _make(o)

func _gen_clang() -> AudioStreamWAV:
    var o := _buf(0.7)
    for i in o.size():
        var t := float(i) / SR
        o[i] = (sin(TAU * 820.0 * t) * 0.5 + sin(TAU * 1370.0 * t) * 0.35 + sin(TAU * 2140.0 * t) * 0.25) * exp(-t * 7.0)
    return _make(o)

func _gen_creak() -> AudioStreamWAV:
    var o := _buf(1.4)
    var ph := 0.0
    for i in o.size():
        var t := float(i) / o.size()
        var f := 140.0 + 130.0 * sin(t * 9.0) + 60.0 * t
        ph += TAU * f / SR
        var saw := fposmod(ph / TAU, 1.0) * 2.0 - 1.0
        var env := pow(sin(PI * t), 2.0)
        var crackle := (randf() * 2.0 - 1.0) * (0.35 if randf() < 0.03 else 0.0)
        o[i] = (saw * 0.35 + crackle) * env
    return _make(o)

func _gen_whisper() -> AudioStreamWAV:
    var o := _buf(3.0)
    var n := o.size()
    var l1 := 0.0
    var l2 := 0.0
    for i in n:
        var t := float(i) / n
        var r := randf() * 2.0 - 1.0
        l1 += (r - l1) * 0.5
        l2 += (r - l2) * 0.12
        var band := l1 - l2
        var am := (0.5 + 0.5 * sin(t * 3.0 * TAU * 2.3)) * pow(sin(PI * t), 2.0)
        o[i] = band * am * 2.2
    return _make(o)

func _gen_engine() -> AudioStreamWAV:
    var o := _buf(1.0)
    var lp := 0.0
    for i in o.size():
        var t := float(i) / SR
        lp += (randf() * 2.0 - 1.0 - lp) * 0.1
        o[i] = sin(t * TAU * 48.0) * 0.4 + (fposmod(t * 96.0, 1.0) * 2.0 - 1.0) * 0.2 + lp * 0.15
    return _make(o, true)

# ---------- audio helpers ----------
func play2d(s, vol := 1.0):
    var p := AudioStreamPlayer.new()
    p.stream = s
    p.volume_db = linear_to_db(vol)
    add_child(p)
    p.finished.connect(p.queue_free)
    p.play()

func play3d(s, pos: Vector3, vol := 1.0, maxd := 40.0):
    var p := AudioStreamPlayer3D.new()
    p.stream = s
    p.volume_db = linear_to_db(vol)
    p.max_distance = maxd
    p.unit_size = 6.0
    get_tree().current_scene.add_child(p)
    p.global_position = pos
    p.finished.connect(p.queue_free)
    p.play()

func heart(on: bool):
    if heart_player == null:
        return
    if on and not heart_player.playing:
        heart_player.play()
    elif not on:
        heart_player.stop()

# a loud noise at pos: the creature investigates if within radius
func alert_noise(pos: Vector3, radius: float):
    if creature != null and is_instance_valid(creature):
        if creature.global_position.distance_to(pos) < radius:
            creature.hear(pos)

# ---------- state ----------
func reset():
    keys = 0
    batteries = 0
    medkits = 0
    ammo = 0
    fuel_cans = 0
    throwables = 0
    docs = 0
    has_torch = false
    has_gun = false
    over = false
    get_tree().paused = false
    heart(false)

func toast(t: String):
    if ui:
        ui.toast(t)

func refresh_objective():
    if not has_torch:
        ui.set_objective("It's pitch dark... find a torch in the house.")
    elif keys < keys_needed:
        ui.set_objective("Find the gate keys  (%d/%d)" % [keys, keys_needed])
    else:
        ui.set_objective("All keys found. Reach the exit gate at the end of the path.")

func caught(c):
    if over:
        return
    over = true
    heart(false)
    player.dead = true
    c.stop_for_attack()
    play2d(s_roar, 1.0)
    var cam: Camera3D = player.cam
    var fwd: Vector3 = -cam.global_transform.basis.z
    fwd.y = 0.0
    fwd = fwd.normalized()
    var from: Vector3 = c.global_position
    var to: Vector3 = cam.global_position + fwd * 1.1
    to.y = from.y
    var t := 0.0
    var scared := false
    while t < 1.0:
        await get_tree().process_frame
        t += get_process_delta_time() / 0.9
        var k := t * t
        c.global_position = from.lerp(to, minf(k, 1.0))
        c.look_at(Vector3(cam.global_position.x, c.global_position.y, cam.global_position.z))
        var head: Vector3 = c.global_position + Vector3.UP * 3.3
        var tb := Basis.looking_at(head - cam.global_position, Vector3.UP)
        cam.global_transform = Transform3D(cam.global_transform.basis.orthonormalized().slerp(tb, 0.15), cam.global_position)
        if t > 0.6 and not scared:
            scared = true
            play2d(s_scare, 1.0)
            ui.flash()
            ui.play_jumpscare()
    await get_tree().create_timer(1.7).timeout
    ui.show_end("GAME OVER", Color(0.8, 0.05, 0.05))

func win():
    if over:
        return
    over = true
    heart(false)
    get_tree().paused = true
    ui.show_end("YOU ESCAPED", Color(0.3, 0.8, 0.4))

func restart():
    get_tree().paused = false
    get_tree().reload_current_scene()
