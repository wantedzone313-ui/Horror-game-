extends Node
# Autoload "Game": shared state, inventory counts, sounds, win/lose flow.

var keys := 0
var batteries := 0
var medkits := 0
var ammo := 0
var docs := 0
var keys_needed := 3
var over := false
var player = null
var ui = null
var s_step: AudioStreamWAV
var s_click: AudioStreamWAV
var s_scare: AudioStreamWAV
var s_wind: AudioStreamWAV
var s_breath: AudioStreamWAV

func _ready():
    process_mode = Node.PROCESS_MODE_ALWAYS
    s_step = _make(_noise(0.18, 0.15, 3.0, 2.5, 0.0))
    s_wind = _make(_noise(6.0, 0.02, 0.0, 8.0, 3.0), true)
    s_breath = _make(_noise(4.0, 0.05, 0.0, 5.0, 2.0), true)
    var c := PackedFloat32Array()
    c.resize(1300)
    for i in 1300:
        var t := float(i) / 1300.0
        c[i] = sin(i * 0.45) * pow(1.0 - t, 4.0) * 0.7
    s_click = _make(c)
    var n := int(22050 * 1.6)
    var sc := PackedFloat32Array()
    sc.resize(n)
    var ph := 0.0
    for i in n:
        var t2 := float(i) / n
        ph += TAU * (900.0 + 1800.0 * t2) / 22050.0
        sc[i] = (sin(ph) * 0.45 + (randf() * 2.0 - 1.0) * 0.5 + sin(i * 0.02) * 0.6) * pow(1.0 - t2, 1.4)
    s_scare = _make(sc)

func _noise(sec: float, lp_k: float, env_pow: float, gain: float, mod_hz: float) -> PackedFloat32Array:
    var n := int(22050 * sec)
    var out := PackedFloat32Array()
    out.resize(n)
    var lp := 0.0
    for i in n:
        var t := float(i) / n
        lp += (randf() * 2.0 - 1.0 - lp) * lp_k
        var a := 1.0
        if env_pow > 0.0:
            a = pow(1.0 - t, env_pow)
        if mod_hz > 0.0:
            var m := 0.5 + 0.5 * sin(t * TAU * mod_hz)
            a *= m * m
        out[i] = lp * a * gain
    return out

func _make(samples: PackedFloat32Array, loop := false) -> AudioStreamWAV:
    var w := AudioStreamWAV.new()
    w.format = AudioStreamWAV.FORMAT_16_BITS
    w.mix_rate = 22050
    w.stereo = false
    var b := PackedByteArray()
    b.resize(samples.size() * 2)
    for i in samples.size():
        b.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32000.0))
    w.data = b
    if loop:
        w.loop_mode = AudioStreamWAV.LOOP_FORWARD
        w.loop_begin = 0
        w.loop_end = samples.size()
    return w

func play2d(s, vol := 1.0):
    var p := AudioStreamPlayer.new()
    p.stream = s
    p.volume_db = linear_to_db(vol)
    add_child(p)
    p.finished.connect(p.queue_free)
    p.play()

func reset():
    keys = 0
    batteries = 0
    medkits = 0
    ammo = 0
    docs = 0
    over = false
    get_tree().paused = false

func toast(t: String):
    if ui:
        ui.toast(t)

func refresh_objective():
    if keys < keys_needed:
        ui.set_objective("Find the gate keys  (%d/%d)" % [keys, keys_needed])
    else:
        ui.set_objective("All keys found. Reach the exit gate at the end of the path.")

func caught(c):
    if over:
        return
    over = true
    player.dead = true
    c.stop_for_attack()
    play2d(s_scare, 1.0)
    var cam: Camera3D = player.cam
    var fwd: Vector3 = -cam.global_transform.basis.z
    fwd.y = 0.0
    fwd = fwd.normalized()
    var from: Vector3 = c.global_position
    var to: Vector3 = cam.global_position + fwd * 1.1
    to.y = from.y
    var t := 0.0
    var flashed := false
    while t < 1.0:
        await get_tree().process_frame
        t += get_process_delta_time() / 0.9
        var k := t * t
        c.global_position = from.lerp(to, minf(k, 1.0))
        c.look_at(Vector3(cam.global_position.x, c.global_position.y, cam.global_position.z))
        var head: Vector3 = c.global_position + Vector3.UP * 3.3
        var tb := Basis.looking_at(head - cam.global_position, Vector3.UP)
        cam.global_transform = Transform3D(cam.global_transform.basis.orthonormalized().slerp(tb, 0.15), cam.global_position)
        if t > 0.6 and not flashed:
            flashed = true
            ui.flash()
    await get_tree().create_timer(1.3).timeout
    ui.show_end("GAME OVER", Color(0.8, 0.05, 0.05))

func win():
    if over:
        return
    over = true
    get_tree().paused = true
    ui.show_end("YOU ESCAPED", Color(0.3, 0.8, 0.4))

func restart():
    get_tree().paused = false
    get_tree().reload_current_scene()
