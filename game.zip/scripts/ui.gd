extends CanvasLayer
# HUD + multi-touch mobile controls. Buttons are pure icons (no text). Raw touch events let joystick + look + buttons work together.

class IconBtn extends Control:
    var icon := ""
    var col := Color(0.06, 0.06, 0.07, 0.6)
    func _init():
        mouse_filter = Control.MOUSE_FILTER_IGNORE
    func _p(x: float, y: float) -> Vector2:
        return size / 2.0 + Vector2(x, y) * (size.x / 100.0)
    func _draw():
        if icon == "":
            draw_rect(Rect2(Vector2.ZERO, size), Color(0.12, 0.12, 0.14, 0.9))
            return
        var u := size.x / 100.0
        draw_circle(size / 2.0, size.x / 2.0, col)
        draw_arc(size / 2.0, size.x / 2.0 - 2.0 * u, 0.0, TAU, 40, Color(1, 1, 1, 0.28), 2.0 * u)
        var w := Color(0.94, 0.94, 0.94)
        var lw := 5.0 * u
        match icon:
            "flash":
                draw_rect(Rect2(_p(0, -8), Vector2(34, 16) * u), w)
                draw_colored_polygon(PackedVector2Array([_p(-30, -20), _p(0, -10), _p(0, 10), _p(-30, 20)]), w)
                draw_line(_p(-34, -12), _p(-48, -22), w, lw * 0.6)
                draw_line(_p(-34, 0), _p(-50, 0), w, lw * 0.6)
                draw_line(_p(-34, 12), _p(-48, 22), w, lw * 0.6)
            "crouch":
                draw_circle(_p(-4, -28), 8.0 * u, w)
                draw_line(_p(-4, -18), _p(0, 4), w, lw)
                draw_line(_p(0, 4), _p(20, 4), w, lw)
                draw_line(_p(20, 4), _p(20, 28), w, lw)
                draw_line(_p(-3, -10), _p(16, -2), w, lw * 0.8)
            "sprint":
                for k in 3:
                    var x0 := -28.0 + k * 20.0
                    draw_polyline(PackedVector2Array([_p(x0, -24), _p(x0 + 18, 0), _p(x0, 24)]), w, lw)
            "bag":
                draw_rect(Rect2(_p(-24, -12), Vector2(48, 44) * u), w)
                draw_arc(_p(0, -12), 14.0 * u, PI, TAU, 16, w, lw)
                draw_rect(Rect2(_p(-14, 8), Vector2(28, 16) * u), Color(0, 0, 0, 0.5))
            "pickup":
                draw_line(_p(0, -32), _p(0, 8), w, lw)
                draw_polyline(PackedVector2Array([_p(-15, -8), _p(0, 8), _p(15, -8)]), w, lw)
                draw_polyline(PackedVector2Array([_p(-30, 14), _p(-30, 30), _p(30, 30), _p(30, 14)]), w, lw)
            "hide":
                draw_rect(Rect2(_p(-14, -32), Vector2(40, 64) * u), w, false, lw * 0.8)
                draw_circle(_p(16, 2), 3.5 * u, w)
                draw_line(_p(-44, 0), _p(-22, 0), w, lw * 0.8)
                draw_polyline(PackedVector2Array([_p(-32, -9), _p(-22, 0), _p(-32, 9)]), w, lw * 0.8)
            "exit":
                draw_rect(Rect2(_p(-36, -30), Vector2(36, 60) * u), w, false, lw * 0.8)
                draw_line(_p(-8, 0), _p(38, 0), w, lw)
                draw_polyline(PackedVector2Array([_p(26, -12), _p(40, 0), _p(26, 12)]), w, lw)
            "drive":
                draw_arc(size / 2.0, 30.0 * u, 0.0, TAU, 32, w, lw)
                draw_circle(size / 2.0, 7.0 * u, w)
                draw_line(size / 2.0, _p(-30, 0), w, lw * 0.8)
                draw_line(size / 2.0, _p(30, 0), w, lw * 0.8)
                draw_line(size / 2.0, _p(0, 30), w, lw * 0.8)
            "refuel":
                draw_rect(Rect2(_p(-22, -16), Vector2(38, 46) * u), w)
                draw_line(_p(6, -16), _p(22, -34), w, lw * 0.8)
                draw_rect(Rect2(_p(-14, -26), Vector2(14, 10) * u), w, false, lw * 0.6)
                draw_circle(_p(-3, 8), 7.0 * u, Color(0.1, 0.1, 0.1, 0.8))
            "fire":
                draw_arc(size / 2.0, 22.0 * u, 0.0, TAU, 32, w, lw * 0.8)
                draw_line(_p(0, -42), _p(0, -14), w, lw * 0.8)
                draw_line(_p(0, 14), _p(0, 42), w, lw * 0.8)
                draw_line(_p(-42, 0), _p(-14, 0), w, lw * 0.8)
                draw_line(_p(14, 0), _p(42, 0), w, lw * 0.8)
                draw_circle(size / 2.0, 3.5 * u, w)
            "throw":
                draw_rect(Rect2(_p(-32, -2), Vector2(26, 34) * u), w)
                draw_rect(Rect2(_p(-32, -6), Vector2(26, 6) * u), Color(0.6, 0.6, 0.6))
                draw_arc(_p(-8, 14), 38.0 * u, deg_to_rad(-85), deg_to_rad(-15), 12, w, lw * 0.7)
                draw_colored_polygon(PackedVector2Array([_p(26, -12), _p(40, -4), _p(24, 0)]), w)

class Joy extends Control:
    var knob := Vector2.ZERO
    func _init():
        mouse_filter = Control.MOUSE_FILTER_IGNORE
    func _draw():
        draw_circle(size / 2.0, size.x / 2.0, Color(1, 1, 1, 0.12))
        draw_circle(size / 2.0 + knob, 65.0, Color(1, 1, 1, 0.35))

var move := Vector2.ZERO
var look_acc := Vector2.ZERO
var sprint := false
var pressed := {}
var roles := {}
var joy: Joy
var joy_center := Vector2.ZERO
var joy_r := 160.0
var hud_btns := {}
var inv_btns := {}
var end_btns := {}
var hp_bg: ColorRect
var hp_fill: ColorRect
var bat_bg: ColorRect
var bat_fill: ColorRect
var bat_label: Label
var obj_label: Label
var toast_label: Label
var flash_rect: ColorRect
var scare_tex: TextureRect
var inv_panel: ColorRect
var inv_label: Label
var end_panel: ColorRect
var end_title: Label
var toast_t := 0.0
var flash_a := 0.0
var scare_t := 0.0

func _ready():
    process_mode = Node.PROCESS_MODE_ALWAYS
    layer = 10
    Game.ui = self
    _build()
    _layout()
    get_viewport().size_changed.connect(_layout)

func _rect(parent: Node, col: Color) -> ColorRect:
    var r := ColorRect.new()
    r.color = col
    r.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(r)
    return r

func _label(parent: Node, fs: int, align = HORIZONTAL_ALIGNMENT_CENTER) -> Label:
    var l := Label.new()
    l.add_theme_font_size_override("font_size", fs)
    l.add_theme_color_override("font_color", Color(0.9, 0.9, 0.9))
    l.add_theme_color_override("font_outline_color", Color(0, 0, 0))
    l.add_theme_constant_override("outline_size", 6)
    l.horizontal_alignment = align
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(l)
    return l

func _icon(parent: Node, icon: String, sz: float) -> IconBtn:
    var b := IconBtn.new()
    b.icon = icon
    b.size = Vector2(sz, sz)
    parent.add_child(b)
    return b

func _tbtn(parent: Node, text: String, sz: Vector2) -> IconBtn:
    # plain rectangular text button (only used in the inventory / game over panels)
    var b := IconBtn.new()
    b.size = sz
    parent.add_child(b)
    var l := _label(b, 28)
    l.text = text
    l.size = sz
    return b

func _build():
    joy = Joy.new()
    joy.size = Vector2(joy_r * 2.0, joy_r * 2.0)
    add_child(joy)
    hp_bg = _rect(self, Color(0.15, 0, 0, 0.8))
    hp_fill = _rect(self, Color(0.75, 0.05, 0.05))
    bat_bg = _rect(self, Color(0.1, 0.1, 0.1, 0.8))
    bat_fill = _rect(self, Color(0.9, 0.85, 0.4))
    bat_label = _label(self, 24, HORIZONTAL_ALIGNMENT_LEFT)
    obj_label = _label(self, 30)
    toast_label = _label(self, 34)
    hud_btns["flash"] = _icon(self, "flash", 130)
    hud_btns["crouch"] = _icon(self, "crouch", 130)
    hud_btns["sprint"] = _icon(self, "sprint", 140)
    hud_btns["bag"] = _icon(self, "bag", 110)
    hud_btns["fire"] = _icon(self, "fire", 130)
    hud_btns["throw"] = _icon(self, "throw", 120)
    hud_btns["action"] = _icon(self, "pickup", 210)
    hud_btns["action"].visible = false
    hud_btns["fire"].visible = false
    hud_btns["throw"].visible = false
    scare_tex = TextureRect.new()
    scare_tex.texture = load("res://tex/creature.jpg")
    scare_tex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    scare_tex.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    scare_tex.mouse_filter = Control.MOUSE_FILTER_IGNORE
    scare_tex.visible = false
    add_child(scare_tex)
    flash_rect = _rect(self, Color(0.75, 0, 0, 0))

    inv_panel = _rect(self, Color(0.03, 0.03, 0.03, 0.93))
    inv_panel.size = Vector2(760, 560)
    inv_panel.visible = false
    var t := _label(inv_panel, 44)
    t.text = "INVENTORY"
    t.position = Vector2(30, 20)
    t.size = Vector2(700, 70)
    inv_label = _label(inv_panel, 30)
    inv_label.position = Vector2(30, 90)
    inv_label.size = Vector2(700, 290)
    inv_btns["use_battery"] = _tbtn(inv_panel, "USE BATTERY", Vector2(330, 80))
    inv_btns["use_battery"].position = Vector2(30, 390)
    inv_btns["use_medkit"] = _tbtn(inv_panel, "USE MEDKIT", Vector2(330, 80))
    inv_btns["use_medkit"].position = Vector2(400, 390)
    inv_btns["close"] = _tbtn(inv_panel, "CLOSE", Vector2(330, 60))
    inv_btns["close"].position = Vector2(215, 485)

    end_panel = _rect(self, Color(0.02, 0, 0, 0.9))
    end_panel.visible = false
    end_title = _label(end_panel, 90)
    end_title.size = Vector2(1200, 140)
    end_btns["restart"] = _tbtn(end_panel, "RESTART", Vector2(460, 110))
    end_btns["menu"] = _tbtn(end_panel, "MAIN MENU", Vector2(460, 110))
    set_health(1.0)

func _place(b: Control, center: Vector2):
    b.position = center - b.size / 2.0

func _layout():
    var vs := get_viewport().get_visible_rect().size
    joy_center = Vector2(260, vs.y - 260)
    joy.position = joy_center - joy.size / 2.0
    hp_bg.position = Vector2(60, 24)
    hp_bg.size = Vector2(420, 26)
    hp_fill.position = hp_bg.position
    hp_fill.size.y = 26
    bat_bg.position = Vector2(60, 70)
    bat_bg.size = Vector2(420, 16)
    bat_fill.position = bat_bg.position
    bat_fill.size.y = 16
    bat_label.position = Vector2(60, 90)
    bat_label.size = Vector2(900, 34)
    obj_label.size = Vector2(1100, 60)
    obj_label.position = Vector2((vs.x - 1100.0) / 2.0, 140)
    toast_label.size = Vector2(1400, 70)
    toast_label.position = Vector2((vs.x - 1400.0) / 2.0, vs.y - 330.0)
    _place(hud_btns["flash"], Vector2(vs.x - 380, vs.y - 330))
    _place(hud_btns["crouch"], Vector2(vs.x - 150, vs.y - 430))
    _place(hud_btns["sprint"], Vector2(vs.x - 440, vs.y - 130))
    _place(hud_btns["bag"], Vector2(vs.x - 110, 110))
    _place(hud_btns["action"], Vector2(vs.x - 190, vs.y - 190))
    _place(hud_btns["fire"], Vector2(vs.x - 620, vs.y - 400))
    _place(hud_btns["throw"], Vector2(vs.x - 650, vs.y - 230))
    scare_tex.position = Vector2.ZERO
    scare_tex.size = vs
    scare_tex.pivot_offset = vs / 2.0
    flash_rect.position = Vector2.ZERO
    flash_rect.size = vs
    inv_panel.position = (vs - inv_panel.size) / 2.0
    end_panel.position = Vector2.ZERO
    end_panel.size = vs
    end_title.position = vs / 2.0 + Vector2(-600, -250)
    end_btns["restart"].position = vs / 2.0 + Vector2(-230, -75)
    end_btns["menu"].position = vs / 2.0 + Vector2(-230, 65)

# ---------- input ----------
func take(n: String) -> bool:
    var v: bool = pressed.get(n, false)
    pressed[n] = false
    return v

func take_look() -> Vector2:
    var l := look_acc
    look_acc = Vector2.ZERO
    return l

func _hit(pos: Vector2) -> String:
    var lists := []
    if end_panel.visible:
        lists = [end_btns]
    elif inv_panel.visible:
        lists = [inv_btns, hud_btns]
    else:
        lists = [hud_btns]
    for lst in lists:
        for nm in lst:
            var b: Control = lst[nm]
            if b.is_visible_in_tree() and Rect2(b.global_position, b.size).has_point(pos):
                return nm
    return ""

func _joy_update(pos: Vector2):
    var v := ((pos - joy_center) / joy_r).limit_length(1.0)
    if v.length() < 0.1:
        v = Vector2.ZERO
    move = Vector2(v.x, -v.y)
    joy.knob = v * joy_r * 0.6
    joy.queue_redraw()

func _btn_down(n: String):
    match n:
        "sprint":
            sprint = true
        "use_battery":
            Game.player.replace_battery()
        "use_medkit":
            Game.player.use_medkit()
        "close":
            toggle_inventory()
        "restart", "menu":
            Game.restart()
        _:
            pressed[n] = true

func _btn_up(n: String):
    if n == "sprint":
        sprint = false

func _input(event):
    if event is InputEventScreenTouch:
        var idx: int = event.index
        if event.pressed:
            var pos: Vector2 = event.position
            var b := _hit(pos)
            if b != "":
                roles[idx] = "btn:" + b
                _btn_down(b)
            elif pos.distance_to(joy_center) < joy_r * 1.3:
                roles[idx] = "joy"
                _joy_update(pos)
            elif pos.x > get_viewport().get_visible_rect().size.x * 0.4:
                roles[idx] = "look"
            else:
                roles[idx] = "none"
        else:
            var r: String = roles.get(idx, "")
            if r == "joy":
                move = Vector2.ZERO
                joy.knob = Vector2.ZERO
                joy.queue_redraw()
            elif r.begins_with("btn:"):
                _btn_up(r.substr(4))
            roles.erase(idx)
    elif event is InputEventScreenDrag:
        var r2: String = roles.get(event.index, "")
        if r2 == "joy":
            _joy_update(event.position)
        elif r2 == "look":
            look_acc += event.relative

# ---------- HUD API ----------
func _process(delta):
    if toast_t > 0.0:
        toast_t -= delta
        toast_label.modulate.a = clampf(toast_t, 0.0, 1.0)
    if flash_a > 0.0:
        flash_a -= delta * 0.5
        flash_rect.color = Color(0.75, 0, 0, maxf(0.0, flash_a))
    if scare_t > 0.0:
        scare_t -= delta
        var k := 1.0 - scare_t / 1.6
        scare_tex.scale = Vector2.ONE * (1.05 + k * 0.35)
        scare_tex.position = Vector2(randf_range(-30, 30), randf_range(-30, 30))
        scare_tex.modulate = Color(1.0, 0.75, 0.75, 1.0) if randf() > 0.15 else Color(1.6, 1.0, 1.0, 1.0)
        if scare_t <= 0.0:
            scare_tex.visible = false

func play_jumpscare():
    scare_t = 1.6
    scare_tex.visible = true

func set_health(f: float):
    hp_fill.size.x = 420.0 * clampf(f, 0.0, 1.0)

func set_battery(pct: float, on: bool):
    bat_fill.size.x = 420.0 * pct / 100.0
    bat_fill.color = Color(0.85, 0.15, 0.1) if pct < 20.0 else Color(0.9, 0.85, 0.4)
    if Game.has_torch:
        bat_label.text = "TORCH %d%%  [%s]   SPARE x%d" % [ceili(pct), "ON" if on else "OFF", Game.batteries]
    else:
        bat_label.text = "NO TORCH"

func set_objective(s: String):
    obj_label.text = s

func toast(s: String):
    toast_label.text = s
    toast_t = 3.5

func set_action(icon: String):
    var b = hud_btns["action"]
    if icon == "":
        b.visible = false
        return
    b.icon = icon
    b.queue_redraw()
    b.visible = true

func flash():
    flash_a = 0.7
    flash_rect.color = Color(0.75, 0, 0, flash_a)

func toggle_inventory():
    inv_panel.visible = not inv_panel.visible
    refresh_inventory()

func refresh_inventory():
    hud_btns["fire"].visible = Game.has_gun
    hud_btns["throw"].visible = Game.throwables > 0
    inv_label.text = "Torch: %s     Rifle: %s\nBatteries: %d     Medkits: %d\nKeys: %d/%d     Documents: %d\nShells: %d     Petrol cans: %d\nTin cans (throw): %d" % [
        "yes" if Game.has_torch else "no", "yes" if Game.has_gun else "no", Game.batteries, Game.medkits, Game.keys, Game.keys_needed, Game.docs, Game.ammo, Game.fuel_cans, Game.throwables]

func show_end(title: String, c: Color):
    end_title.text = title
    end_title.add_theme_color_override("font_color", c)
    end_panel.visible = true
