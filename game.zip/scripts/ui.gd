extends CanvasLayer
# Full HUD + multi-touch mobile controls, built in code. Raw touch events are used so joystick + look + buttons work at the same time.

class CircleBtn extends Control:
    var label := ""
    var fs := 26
    var col := Color(0.08, 0.08, 0.08, 0.65)
    var is_round := true
    func _init():
        mouse_filter = Control.MOUSE_FILTER_IGNORE
    func _draw():
        if is_round:
            draw_circle(size / 2.0, size.x / 2.0, col)
        else:
            draw_rect(Rect2(Vector2.ZERO, size), col)
        draw_string(ThemeDB.fallback_font, Vector2(0, size.y / 2.0 + fs * 0.35), label, HORIZONTAL_ALIGNMENT_CENTER, size.x, fs, Color(0.9, 0.9, 0.9))

class Joy extends Control:
    var knob := Vector2.ZERO
    func _init():
        mouse_filter = Control.MOUSE_FILTER_IGNORE
    func _draw():
        draw_circle(size / 2.0, size.x / 2.0, Color(1, 1, 1, 0.12))
        draw_circle(size / 2.0 + knob, 65.0, Color(1, 1, 1, 0.35))

var move := Vector2.ZERO
var look_acc := Vector2.ZERO
var sprint := false
var pressed := {}
var roles := {}
var joy: Joy
var joy_center := Vector2.ZERO
var joy_r := 160.0
var hud_btns := {}
var inv_btns := {}
var end_btns := {}
var hp_bg: ColorRect
var hp_fill: ColorRect
var bat_bg: ColorRect
var bat_fill: ColorRect
var bat_label: Label
var obj_label: Label
var toast_label: Label
var flash_rect: ColorRect
var inv_panel: ColorRect
var inv_label: Label
var end_panel: ColorRect
var end_title: Label
var toast_t := 0.0
var flash_a := 0.0

func _ready():
    process_mode = Node.PROCESS_MODE_ALWAYS
    layer = 10
    Game.ui = self
    _build()
    _layout()
    get_viewport().size_changed.connect(_layout)

func _rect(parent: Node, col: Color) -> ColorRect:
    var r := ColorRect.new()
    r.color = col
    r.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(r)
    return r

func _label(parent: Node, fs: int, align = HORIZONTAL_ALIGNMENT_CENTER) -> Label:
    var l := Label.new()
    l.add_theme_font_size_override("font_size", fs)
    l.add_theme_color_override("font_color", Color(0.9, 0.9, 0.9))
    l.add_theme_color_override("font_outline_color", Color(0, 0, 0))
    l.add_theme_constant_override("outline_size", 6)
    l.horizontal_alignment = align
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(l)
    return l

func _btn(parent: Node, text: String, fs: int, sz: Vector2, round_btn := true) -> CircleBtn:
    var b := CircleBtn.new()
    b.label = text
    b.fs = fs
    b.size = sz
    b.is_round = round_btn
    parent.add_child(b)
    return b

func _build():
    joy = Joy.new()
    joy.size = Vector2(joy_r * 2.0, joy_r * 2.0)
    add_child(joy)
    hp_bg = _rect(self, Color(0.15, 0, 0, 0.8))
    hp_fill = _rect(self, Color(0.75, 0.05, 0.05))
    bat_bg = _rect(self, Color(0.1, 0.1, 0.1, 0.8))
    bat_fill = _rect(self, Color(0.9, 0.85, 0.4))
    bat_label = _label(self, 24, HORIZONTAL_ALIGNMENT_LEFT)
    obj_label = _label(self, 30)
    toast_label = _label(self, 34)
    hud_btns["flash"] = _btn(self, "FLASH", 26, Vector2(130, 130))
    hud_btns["crouch"] = _btn(self, "CROUCH", 22, Vector2(130, 130))
    hud_btns["sprint"] = _btn(self, "SPRINT", 22, Vector2(140, 140))
    hud_btns["bag"] = _btn(self, "BAG", 24, Vector2(110, 110))
    hud_btns["action"] = _btn(self, "PICK UP", 30, Vector2(210, 210))
    hud_btns["action"].visible = false
    flash_rect = _rect(self, Color(0.75, 0, 0, 0))

    inv_panel = _rect(self, Color(0.03, 0.03, 0.03, 0.93))
    inv_panel.size = Vector2(760, 560)
    inv_panel.visible = false
    var t := _label(inv_panel, 44)
    t.text = "INVENTORY"
    t.position = Vector2(30, 20)
    t.size = Vector2(700, 70)
    inv_label = _label(inv_panel, 32)
    inv_label.position = Vector2(30, 100)
    inv_label.size = Vector2(700, 260)
    inv_btns["use_battery"] = _btn(inv_panel, "USE BATTERY", 26, Vector2(330, 80), false)
    inv_btns["use_battery"].position = Vector2(30, 380)
    inv_btns["use_medkit"] = _btn(inv_panel, "USE MEDKIT", 26, Vector2(330, 80), false)
    inv_btns["use_medkit"].position = Vector2(400, 380)
    inv_btns["close"] = _btn(inv_panel, "CLOSE", 26, Vector2(330, 70), false)
    inv_btns["close"].position = Vector2(215, 470)

    end_panel = _rect(self, Color(0.02, 0, 0, 0.9))
    end_panel.visible = false
    end_title = _label(end_panel, 90)
    end_title.size = Vector2(1200, 140)
    end_btns["restart"] = _btn(end_panel, "RESTART", 40, Vector2(460, 110), false)
    end_btns["menu"] = _btn(end_panel, "MAIN MENU", 40, Vector2(460, 110), false)
    set_health(1.0)

func _place(b: Control, center: Vector2):
    b.position = center - b.size / 2.0

func _layout():
    var vs := get_viewport().get_visible_rect().size
    joy_center = Vector2(260, vs.y - 260)
    joy.position = joy_center - joy.size / 2.0
    hp_bg.position = Vector2(60, 37)
    hp_bg.size = Vector2(420, 26)
    hp_fill.position = hp_bg.position
    hp_fill.size.y = 26
    bat_bg.position = Vector2(60, 84)
    bat_bg.size = Vector2(420, 16)
    bat_fill.position = bat_bg.position
    bat_fill.size.y = 16
    bat_label.position = Vector2(60, 104)
    bat_label.size = Vector2(900, 34)
    obj_label.size = Vector2(1100, 60)
    obj_label.position = Vector2((vs.x - 1100.0) / 2.0, 30)
    toast_label.size = Vector2(1400, 70)
    toast_label.position = Vector2((vs.x - 1400.0) / 2.0, vs.y - 330.0)
    _place(hud_btns["flash"], Vector2(vs.x - 380, vs.y - 330))
    _place(hud_btns["crouch"], Vector2(vs.x - 150, vs.y - 430))
    _place(hud_btns["sprint"], Vector2(vs.x - 440, vs.y - 130))
    _place(hud_btns["bag"], Vector2(vs.x - 110, 110))
    _place(hud_btns["action"], Vector2(vs.x - 190, vs.y - 190))
    flash_rect.position = Vector2.ZERO
    flash_rect.size = vs
    inv_panel.position = (vs - inv_panel.size) / 2.0
    end_panel.position = Vector2.ZERO
    end_panel.size = vs
    end_title.position = vs / 2.0 + Vector2(-600, -250)
    end_btns["restart"].position = vs / 2.0 + Vector2(-230, -75)
    end_btns["menu"].position = vs / 2.0 + Vector2(-230, 65)

# ---------- input ----------
func take(n: String) -> bool:
    var v: bool = pressed.get(n, false)
    pressed[n] = false
    return v

func take_look() -> Vector2:
    var l := look_acc
    look_acc = Vector2.ZERO
    return l

func _hit(pos: Vector2) -> String:
    var lists := []
    if end_panel.visible:
        lists = [end_btns]
    elif inv_panel.visible:
        lists = [inv_btns, hud_btns]
    else:
        lists = [hud_btns]
    for lst in lists:
        for nm in lst:
            var b: Control = lst[nm]
            if b.is_visible_in_tree() and Rect2(b.global_position, b.size).has_point(pos):
                return nm
    return ""

func _joy_update(pos: Vector2):
    var v := ((pos - joy_center) / joy_r).limit_length(1.0)
    if v.length() < 0.1:
        v = Vector2.ZERO
    move = Vector2(v.x, -v.y)
    joy.knob = v * joy_r * 0.6
    joy.queue_redraw()

func _btn_down(n: String):
    match n:
        "sprint":
            sprint = true
        "use_battery":
            Game.player.replace_battery()
        "use_medkit":
            Game.player.use_medkit()
        "close":
            toggle_inventory()
        "restart", "menu":
            Game.restart()
        _:
            pressed[n] = true

func _btn_up(n: String):
    if n == "sprint":
        sprint = false

func _input(event):
    if event is InputEventScreenTouch:
        var idx: int = event.index
        if event.pressed:
            var pos: Vector2 = event.position
            var b := _hit(pos)
            if b != "":
                roles[idx] = "btn:" + b
                _btn_down(b)
            elif pos.distance_to(joy_center) < joy_r * 1.3:
                roles[idx] = "joy"
                _joy_update(pos)
            elif pos.x > get_viewport().get_visible_rect().size.x * 0.4:
                roles[idx] = "look"
            else:
                roles[idx] = "none"
        else:
            var r: String = roles.get(idx, "")
            if r == "joy":
                move = Vector2.ZERO
                joy.knob = Vector2.ZERO
                joy.queue_redraw()
            elif r.begins_with("btn:"):
                _btn_up(r.substr(4))
            roles.erase(idx)
    elif event is InputEventScreenDrag:
        var r2: String = roles.get(event.index, "")
        if r2 == "joy":
            _joy_update(event.position)
        elif r2 == "look":
            look_acc += event.relative

# ---------- HUD API ----------
func _process(delta):
    if toast_t > 0.0:
        toast_t -= delta
        toast_label.modulate.a = clampf(toast_t, 0.0, 1.0)
    if flash_a > 0.0:
        flash_a -= delta * 0.7
        flash_rect.color = Color(0.75, 0, 0, maxf(0.0, flash_a))

func set_health(f: float):
    hp_fill.size.x = 420.0 * clampf(f, 0.0, 1.0)

func set_battery(pct: float, on: bool):
    bat_fill.size.x = 420.0 * pct / 100.0
    bat_fill.color = Color(0.85, 0.15, 0.1) if pct < 20.0 else Color(0.9, 0.85, 0.4)
    bat_label.text = "FLASHLIGHT %d%%  [%s]   SPARE x%d" % [ceili(pct), "ON" if on else "OFF", Game.batteries]

func set_objective(s: String):
    obj_label.text = s

func toast(s: String):
    toast_label.text = s
    toast_t = 3.5

func set_action(label: String):
    var b = hud_btns["action"]
    if label == "":
        b.visible = false
        return
    b.label = label
    b.queue_redraw()
    b.visible = true

func flash():
    flash_a = 0.6
    flash_rect.color = Color(0.75, 0, 0, flash_a)

func toggle_inventory():
    inv_panel.visible = not inv_panel.visible
    refresh_inventory()

func refresh_inventory():
    inv_label.text = "Batteries: %d\nMedkits: %d\nKeys: %d/%d\nAmmo: %d\nDocuments: %d" % [Game.batteries, Game.medkits, Game.keys, Game.keys_needed, Game.ammo, Game.docs]

func show_end(title: String, c: Color):
    end_title.text = title
    end_title.add_theme_color_override("font_color", c)
    end_panel.visible = true
