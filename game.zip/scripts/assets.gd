extends RefCounted
# Loads your optimized models (res://models/*.bin = glTF binary) at runtime with GLTFDocument.
# No editor import step is needed, so it also works in headless CI builds.

static var _cache := {}
static var loaded := 0
static var failed := []

static func load_model(model_name: String) -> Node3D:
    if _cache.has(model_name):
        var t = _cache[model_name]
        if t == null:
            return null
        return t.duplicate() as Node3D
    var path := "res://models/%s.bin" % model_name
    var root: Node3D = null
    if FileAccess.file_exists(path):
        var bytes := FileAccess.get_file_as_bytes(path)
        if bytes.size() > 0:
            var doc := GLTFDocument.new()
            var st := GLTFState.new()
            var err := doc.append_from_buffer(bytes, "", st)
            if err == OK:
                var n = doc.generate_scene(st)
                if n is Node3D:
                    root = n
    if root == null:
        failed.append(model_name)
        push_warning("model failed: " + model_name)
    else:
        loaded += 1
        _collision_nodes(root)
    _cache[model_name] = root
    if root == null:
        return null
    return root.duplicate() as Node3D

# nodes named "...-colonly" or "collision" become static colliders (and disappear visually)
static func _collision_nodes(root: Node):
    var todo := []
    for mi in meshes(root):
        var nm := String(mi.name)
        if nm.ends_with("-colonly") or nm == "collision":
            todo.append(mi)
    for mi in todo:
        var parent: Node = mi.get_parent()
        if mi.mesh != null:
            var body := StaticBody3D.new()
            body.name = String(mi.name) + "_body"
            body.transform = mi.transform
            var cs := CollisionShape3D.new()
            var shape := mi.mesh.create_trimesh_shape()
            if shape is ConcavePolygonShape3D:
                shape.backface_collision = true
            cs.shape = shape
            body.add_child(cs)
            parent.add_child(body)
        parent.remove_child(mi)
        mi.free()

static func meshes(n: Node, out := []) -> Array:
    if n is MeshInstance3D:
        out.append(n)
    for c in n.get_children():
        meshes(c, out)
    return out

# make every surface draw on top (first-person hand models)
static func on_top(n: Node):
    for mi in meshes(n):
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        var m: Mesh = mi.mesh
        if m == null:
            continue
        for i in m.get_surface_count():
            var mat = m.surface_get_material(i)
            if mat is BaseMaterial3D:
                var d: BaseMaterial3D = mat.duplicate()
                d.no_depth_test = true
                d.render_priority = 50
                mi.set_surface_override_material(i, d)

static func aabb_of(n: Node3D) -> AABB:
    var box := AABB()
    var first := true
    for mi in meshes(n):
        var a: AABB = mi.global_transform * mi.get_aabb()
        if first:
            box = a
            first = false
        else:
            box = box.merge(a)
    return box

static func status() -> String:
    return "models %d ok, %d failed" % [loaded, failed.size()]
