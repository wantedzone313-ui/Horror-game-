extends RefCounted
# Helpers for the optimized .glb models in res://models

static func load_model(model_name: String) -> Node3D:
    var path := "res://models/%s.glb" % model_name
    if not ResourceLoader.exists(path):
        push_warning("missing model " + path)
        return null
    var ps = load(path)
    if ps == null or not (ps is PackedScene):
        return null
    var n = ps.instantiate()
    return n as Node3D

# all MeshInstance3D below a node
static func meshes(n: Node, out := []) -> Array:
    if n is MeshInstance3D:
        out.append(n)
    for c in n.get_children():
        meshes(c, out)
    return out

# make every surface draw on top (used for first-person hand models)
static func on_top(n: Node):
    for mi in meshes(n):
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        var m: Mesh = mi.mesh
        if m == null:
            continue
        for i in m.get_surface_count():
            var mat = m.surface_get_material(i)
            if mat is BaseMaterial3D:
                var d: BaseMaterial3D = mat.duplicate()
                d.no_depth_test = true
                d.render_priority = 50
                mi.set_surface_override_material(i, d)

static func aabb_of(n: Node3D) -> AABB:
    var box := AABB()
    var first := true
    for mi in meshes(n):
        var a: AABB = mi.global_transform * mi.get_aabb()
        if first:
            box = a
            first = false
        else:
            box = box.merge(a)
    return box

# if an imported model came without collision bodies, wrap its bounds in a box
static func ensure_collision(n: Node3D, shrink := 0.8):
    var has := false
    var stack := [n]
    while not stack.is_empty():
        var c = stack.pop_back()
        if c is StaticBody3D:
            has = true
            break
        for k in c.get_children():
            stack.append(k)
    if has:
        return
    var b := aabb_of(n)
    var body := StaticBody3D.new()
    var cs := CollisionShape3D.new()
    var sh := BoxShape3D.new()
    sh.size = Vector3(b.size.x * shrink, b.size.y, b.size.z * shrink)
    cs.shape = sh
    cs.position = b.position + b.size / 2.0 - n.global_position
    body.add_child(cs)
    n.add_child(body)
