extends CharacterBody3D
# Stalker creature built from your .glb models: kind "ghost" (ghostly woman) or "raven" (xeno raven).
# States: Idle, Patrol, Investigate, Chase, Search, Attack. Faces -Z.

const Assets = preload("res://scripts/assets.gd")

enum S { IDLE, PATROL, INVESTIGATE, CHASE, SEARCH, ATTACK }

var kind := "ghost"
var state = S.PATROL
var walk_speed := 1.5
var chase_speed := 4.3
var detect_range := 18.0
var lose_sight := 5.0
var attack_dist := 1.8
var turn_speed := 3.0
var bounds := 85.0
var head_h := 2.0
var outdoor_only := false

var model: Node3D
var col: CollisionShape3D
var breath: AudioStreamPlayer3D
var target := Vector3.ZERO
var last_known := Vector3.ZERO
var search_center := Vector3.ZERO
var timer := 0.0
var lose_timer := 0.0
var discover_t := 0.0
var stuck_t := 0.0
var evade_t := 0.0
var evade_side := 1.0
var anim_t := 0.0
var blocked := false
var path := []
var path_i := 0
var path_goal := Vector3(1e6, 0, 1e6)
var repath_t := 0.0
var stun_t := 0.0
var leg_t := 0.0
var chase_audio := false

func _ready():
    if kind == "raven":
        walk_speed = 2.2
        chase_speed = 5.0
        detect_range = 26.0
        attack_dist = 2.5
        head_h = 2.6
        outdoor_only = true
        turn_speed = 3.5
    else:
        head_h = 2.0
    _build()
    _pick_patrol()
    Game.creatures.append(self)
    floor_snap_length = 0.6
    breath = AudioStreamPlayer3D.new()
    breath.stream = Game.s_breath
    breath.max_distance = 30.0
    breath.unit_size = 5.0
    add_child(breath)
    breath.play()

func _build():
    var h := 2.15 if kind == "ghost" else 3.0
    var r := 0.35 if kind == "ghost" else 0.6
    col = CollisionShape3D.new()
    var cs := CapsuleShape3D.new()
    cs.radius = r
    cs.height = h
    col.shape = cs
    col.position = Vector3(0, h / 2.0, 0)
    add_child(col)
    model = Assets.load_model(kind)
    if model != null:
        add_child(model)
        for mi in Assets.meshes(model):
            mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    else:
        # fallback if the model is missing: a dark capsule
        var mi := MeshInstance3D.new()
        var cm := CapsuleMesh.new()
        cm.radius = r
        cm.height = h
        mi.mesh = cm
        mi.position = Vector3(0, h / 2.0, 0)
        var m := StandardMaterial3D.new()
        m.albedo_color = Color(0.02, 0.02, 0.03)
        mi.material_override = m
        add_child(mi)
        model = mi
    # eerie glow so it can be spotted in the fog
    var gl := OmniLight3D.new()
    gl.omni_range = 5.0
    gl.light_energy = 0.5
    gl.light_color = Color(0.8, 0.9, 1.0) if kind == "ghost" else Color(0.4, 1.0, 0.5)
    gl.position = Vector3(0, head_h, 0)
    add_child(gl)

# ---------- AI ----------
func stop_for_attack():
    state = S.ATTACK
    set_physics_process(false)
    col.set_deferred("disabled", true)
    breath.stop()
    _chase_audio(false)

func stun(t: float):
    if state == S.ATTACK:
        return
    stun_t = t
    _chase_audio(false)
    Game.play3d(Game.s_roar, global_position, 0.8, 55.0)

# a noise somewhere: investigate it (unless it can already see the player)
func hear(pos: Vector3):
    if stun_t > 0.0 or state == S.ATTACK:
        return
    if state == S.CHASE and lose_timer <= 0.0:
        return
    _chase_audio(false)
    state = S.INVESTIGATE
    target = _clamp(pos)
    leg_t = 14.0

func _chase_audio(on: bool):
    if on == chase_audio:
        return
    chase_audio = on
    breath.stream = Game.s_growl if on else Game.s_breath
    breath.play()
    Game.chase_change(on)

func _physics_process(delta):
    var p = Game.player
    if p == null or p.dead or Game.over or state == S.ATTACK:
        _animate(0.0, delta)
        return
    if stun_t > 0.0:
        stun_t -= delta
        velocity = Vector3(0, -2.0, 0)
        move_and_slide()
        anim_t += delta * 6.0
        model.rotation_degrees = Vector3(sin(anim_t) * 8.0, sin(anim_t * 1.7) * 12.0, sin(anim_t * 1.3) * 10.0)
        if stun_t <= 0.0:
            _begin_search(p.global_position, 10.0)
        return
    var pp: Vector3 = p.global_position
    var dist := _flat(pp)
    var sees := _can_see(dist, p)
    var spd := 0.0
    match state:
        S.IDLE:
            timer -= delta
            if sees:
                _begin_chase(pp)
            elif _hears(dist, p):
                _begin_investigate(pp)
            elif timer <= 0.0:
                _pick_patrol()
                state = S.PATROL
        S.PATROL:
            leg_t -= delta
            spd = _go(target, walk_speed, delta)
            if sees:
                _begin_chase(pp)
            elif _hears(dist, p):
                _begin_investigate(pp)
            elif _flat(target) < 1.5 or blocked or leg_t <= 0.0:
                blocked = false
                state = S.IDLE
                timer = randf_range(2.0, 4.5)
        S.INVESTIGATE:
            leg_t -= delta
            spd = _go(target, walk_speed * 1.5, delta)
            if sees:
                _begin_chase(pp)
            elif _flat(target) < 1.5 or blocked or leg_t <= 0.0:
                blocked = false
                _begin_search(target, 6.0)
        S.CHASE:
            if sees:
                last_known = pp
                lose_timer = 0.0
            else:
                lose_timer += delta
            spd = _go(last_known, chase_speed, delta)
            var ad := 3.4 if p.driving else attack_dist
            if not p.hidden and dist < ad and absf(pp.y - global_position.y) < 2.0:
                _begin_attack()
            elif lose_timer > lose_sight or (p.hidden and lose_timer > 1.0) or (not sees and _flat(last_known) < 1.5):
                _begin_search(last_known, 10.0)
        S.SEARCH:
            timer -= delta
            if sees:
                _begin_chase(pp)
            elif _hears(dist, p):
                _begin_investigate(pp)
            else:
                spd = _go(target, walk_speed, delta)
                if _flat(target) < 1.5 or blocked:
                    blocked = false
                    var r := Vector2.from_angle(randf() * TAU) * randf_range(0.0, 7.0)
                    target = _clamp(search_center + Vector3(r.x, 0, r.y))
                if p.hidden and dist < 3.5:
                    discover_t += delta
                    if discover_t >= 1.5:
                        discover_t = 0.0
                        if randf() < 0.3:
                            _begin_attack()
                if state == S.SEARCH and timer <= 0.0:
                    _pick_patrol()
                    state = S.PATROL
    _animate(spd, delta)

func _flat(p: Vector3) -> float:
    return Vector2(p.x - global_position.x, p.z - global_position.z).length()

func _clamp(v: Vector3) -> Vector3:
    return Vector3(clampf(v.x, -bounds, bounds), v.y, clampf(v.z, -bounds, bounds))

func _inside(p: Vector3, margin: float) -> bool:
    return absf(p.x) < 20.5 + margin and p.z > -12.5 - margin and p.z < 12.5 + margin

func _pick_patrol():
    leg_t = 30.0
    if not outdoor_only and randf() < 0.45 and Game.nav != null:
        var ids := Game.nav.get_point_ids()
        var tries := 0
        while tries < 12:
            tries += 1
            var pos := Game.nav.get_point_position(ids[randi() % ids.size()])
            if _inside(pos, -0.5):
                target = pos
                return
    for i in 20:
        var v := Vector3(randf_range(-bounds, bounds), 0.0, randf_range(-bounds, bounds))
        if not _inside(v, 3.0):
            target = v
            return
    target = Vector3(40, 0, 40)

func _hears(dist: float, p) -> bool:
    return not p.hidden and dist < p.noise_radius

func _can_see(dist: float, p) -> bool:
    if p.hidden:
        return false
    var rng := detect_range * (1.3 if (Game.has_torch and p.light_on) else 1.0)
    if p.crouching:
        rng *= 0.6
    if p.driving:
        rng *= 1.6
    if dist > rng:
        return false
    var fwd: Vector3 = -global_transform.basis.z
    var eye := global_position + Vector3.UP * head_h + fwd * 0.5
    var tgt: Vector3 = p.global_position + Vector3.UP * 1.2
    var to := tgt - eye
    if dist > 4.0 and absf(rad_to_deg(Vector2(fwd.x, fwd.z).angle_to(Vector2(to.x, to.z)))) > 70.0:
        return false
    var q := PhysicsRayQueryParameters3D.create(eye, tgt)
    q.exclude = [get_rid()]
    var hit := get_world_3d().direct_space_state.intersect_ray(q)
    if hit.is_empty():
        return true
    return hit["collider"] == p or hit["collider"] == p.car

func _begin_chase(pp: Vector3):
    if state != S.CHASE:
        Game.play3d(Game.s_roar, global_position, 1.0, 70.0)
    _chase_audio(true)
    state = S.CHASE
    lose_timer = 0.0
    last_known = pp

func _begin_investigate(pp: Vector3):
    _chase_audio(false)
    state = S.INVESTIGATE
    target = _clamp(pp)
    leg_t = 14.0

func _begin_search(c: Vector3, t: float):
    _chase_audio(false)
    state = S.SEARCH
    search_center = _clamp(c)
    target = search_center
    timer = t
    discover_t = 0.0

func _begin_attack():
    state = S.ATTACK
    Game.caught(self)

# next point to steer to: straight line outdoors, A* waypoint graph through the mansion
func _next_point(t: Vector3, delta: float) -> Vector3:
    var nav: AStar3D = Game.nav
    if nav == null:
        return t
    var me := global_position
    var me_in := _inside(me, 0.5)
    var t_in := _inside(t, 0.5)
    var entry := Vector3(0, 0, 24)
    if outdoor_only:
        path.clear()
        return entry if t_in else t
    if not me_in and not t_in and Vector2(me.x - entry.x, me.z - entry.z).length() > 6.0:
        path.clear()
        return t
    if t_in and not me_in and Vector2(me.x - entry.x, me.z - entry.z).length() > 8.0:
        path.clear()
        return entry
    repath_t -= delta
    if path.is_empty() or repath_t <= 0.0 or t.distance_to(path_goal) > 1.5:
        repath_t = 0.6
        path_goal = t
        var a := nav.get_closest_point(me)
        var b := nav.get_closest_point(t)
        path = Array(nav.get_point_path(a, b))
        path.append(t)
        path_i = 0
    while path_i < path.size() - 1 and Vector2(me.x - path[path_i].x, me.z - path[path_i].z).length() < 1.2 and absf(me.y - path[path_i].y) < 2.5:
        path_i += 1
    if not me_in and not t_in and path_i >= path.size() - 1:
        path.clear()
        return t
    return path[path_i]

func _go(tt: Vector3, speed: float, delta: float) -> float:
    var t := _next_point(tt, delta)
    var d := t - global_position
    d.y = 0.0
    if d.length() < 0.05:
        return 0.0
    var dir := d.normalized()
    if evade_t > 0.0:
        dir = dir.rotated(Vector3.UP, deg_to_rad(90.0 * evade_side))
        evade_t -= delta
    var tb := Basis.looking_at(dir, Vector3.UP)
    global_transform.basis = global_transform.basis.orthonormalized().slerp(tb, clampf(turn_speed * delta, 0.0, 1.0))
    var fwd: Vector3 = -global_transform.basis.z
    var align := clampf(fwd.dot(dir) * 1.5, 0.0, 1.0)
    var before := global_position
    velocity = Vector3(fwd.x * speed * align, -3.0, fwd.z * speed * align)
    move_and_slide()
    for i in get_slide_collision_count():
        var c := get_slide_collision(i)
        if absf(c.get_normal().y) < 0.5 and c.get_collider() != Game.player and evade_t <= 0.0:
            evade_t = 0.7
            evade_side = 1.0 if randf() < 0.5 else -1.0
    var moved := Vector2(global_position.x - before.x, global_position.z - before.z).length()
    if moved < speed * align * delta * 0.2:
        stuck_t += delta
    else:
        stuck_t = 0.0
    if stuck_t > 1.2:
        stuck_t = 0.0
        blocked = true
    return speed * align

func _animate(spd: float, delta: float):
    anim_t += delta * (1.0 + spd * 1.2)
    if model == null:
        return
    var moving := clampf(spd / 2.0, 0.0, 1.0)
    var lean := deg_to_rad(-3.0 - spd * 2.5) if kind == "ghost" else deg_to_rad(-6.0 - spd * 3.0)
    model.rotation.x = lerpf(model.rotation.x, lean, delta * 4.0)
    model.rotation.z = sin(anim_t * 2.0) * 0.05 * (0.3 + moving)
    model.rotation.y = 0.0
    var bob := 0.04 if kind == "ghost" else 0.07
    model.position.y = absf(sin(anim_t * 3.0)) * bob * moving
