extends CharacterBody3D
# "The Smiler": tall thin creature in a long dark dress, long wet hair, glowing eyes, wide toothy grin, very long arms.
# Placeholder model built from primitives. Faces -Z.

enum S { IDLE, PATROL, INVESTIGATE, CHASE, SEARCH, ATTACK }

var state = S.PATROL
var walk_speed := 1.5
var chase_speed := 4.3
var detect_range := 18.0
var lose_sight := 5.0
var attack_dist := 1.8
var turn_speed := 3.0
var bounds := 85.0

var arm_l: Node3D
var arm_r: Node3D
var elbow_l: Node3D
var elbow_r: Node3D
var head: Node3D
var skirt: Node3D
var strands := []
var col: CollisionShape3D
var breath: AudioStreamPlayer3D
var target := Vector3.ZERO
var last_known := Vector3.ZERO
var search_center := Vector3.ZERO
var timer := 0.0
var lose_timer := 0.0
var discover_t := 0.0
var stuck_t := 0.0
var evade_t := 0.0
var evade_side := 1.0
var anim_t := 0.0
var arm_base := 0.0
var blocked := false
var path := []
var path_i := 0
var path_goal := Vector3(1e6, 0, 1e6)
var repath_t := 0.0
var stun_t := 0.0
var leg_t := 0.0
var chase_audio := false

func _ready():
    _build()
    _pick_patrol()
    Game.creature = self
    floor_snap_length = 0.6
    breath = AudioStreamPlayer3D.new()
    breath.stream = Game.s_breath
    breath.max_distance = 30.0
    breath.unit_size = 5.0
    add_child(breath)
    breath.play()

# ---------- model ----------
func _mat(c: Color, glow := false, rough := 0.8) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    if glow:
        m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    else:
        m.roughness = rough
    return m

func _mk(parent: Node3D, mesh: Mesh, pos: Vector3, scl: Vector3, mat: Material) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    mi.position = pos
    mi.scale = scl
    mi.material_override = mat
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(mi)
    return mi

func _node(parent: Node3D, pos: Vector3) -> Node3D:
    var n := Node3D.new()
    n.position = pos
    parent.add_child(n)
    return n

func _build():
    var skin := _mat(Color(0.07, 0.07, 0.075), false, 0.55)
    var cloth := _mat(Color(0.015, 0.015, 0.02), false, 0.95)
    var hair := _mat(Color(0.006, 0.006, 0.008), false, 0.6)
    var white := _mat(Color.WHITE, true)
    col = CollisionShape3D.new()
    var cs := CapsuleShape3D.new()
    cs.radius = 0.35
    cs.height = 3.6
    col.shape = cs
    col.position = Vector3(0, 1.8, 0)
    add_child(col)

    # long flowing dress
    var sk := CylinderMesh.new()
    sk.top_radius = 0.2
    sk.bottom_radius = 0.85
    sk.height = 1.9
    sk.radial_segments = 14
    sk.rings = 2
    skirt = _node(self, Vector3(0, 0.95, 0))
    _mk(skirt, sk, Vector3.ZERO, Vector3.ONE, cloth)
    # thin torso + ribs
    _mk(self, CapsuleMesh.new(), Vector3(0, 2.25, 0), Vector3(0.28, 0.7, 0.17), skin)
    for i in 7:
        _mk(self, BoxMesh.new(), Vector3(0, 2.05 + i * 0.1, -0.02), Vector3(0.3 - i * 0.012, 0.012, 0.2), cloth)
    _mk(self, CapsuleMesh.new(), Vector3(0, 3.0, 0), Vector3(0.07, 0.3, 0.07), skin)

    # head
    head = _node(self, Vector3(0, 3.4, 0))
    _mk(head, SphereMesh.new(), Vector3.ZERO, Vector3(0.36, 0.48, 0.34), skin)
    _mk(head, CapsuleMesh.new(), Vector3(0, -0.5, 0.12), Vector3(0.52, 1.1, 0.3), hair)
    _mk(head, SphereMesh.new(), Vector3(0, 0.1, 0.03), Vector3(0.42, 0.4, 0.4), hair)
    for i in 40:
        var a := randf() * TAU
        var r := randf_range(0.14, 0.27)
        var x := cos(a) * r
        var z := sin(a) * r
        if z < -0.05 and absf(x) < 0.13:
            continue
        var ln := randf_range(0.9, 1.9)
        var pv := _node(head, Vector3(x, randf_range(0.0, 0.2), z))
        _mk(pv, CapsuleMesh.new(), Vector3(0, -ln / 2.0, 0), Vector3(0.012, ln / 2.0, 0.012), hair)
        strands.append(pv)
    _mk(head, SphereMesh.new(), Vector3(-0.09, 0.05, -0.15), Vector3(0.085, 0.07, 0.04), white)
    _mk(head, SphereMesh.new(), Vector3(0.09, 0.05, -0.15), Vector3(0.085, 0.07, 0.04), white)
    for i in 17:
        var u := (i - 8) / 8.0
        var x2 := u * 0.14
        var y2 := -0.1 + u * u * 0.05
        _mk(head, BoxMesh.new(), Vector3(x2, y2, -0.14 + u * u * 0.02), Vector3(0.0095, 0.028, 0.008), white)
        _mk(head, BoxMesh.new(), Vector3(x2, y2 - 0.034, -0.14 + u * u * 0.02), Vector3(0.0095, 0.024, 0.008), white)
    var gl := OmniLight3D.new()
    gl.omni_range = 5.0
    gl.light_energy = 0.6
    gl.light_color = Color(0.8, 0.9, 1.0)
    gl.position = Vector3(0, 0.05, -0.4)
    head.add_child(gl)

    # very long arms with elbows and clawed fingers
    var left := _arm(Vector3(-0.22, 2.85, 0), skin)
    arm_l = left[0]
    elbow_l = left[1]
    var right := _arm(Vector3(0.22, 2.85, 0), skin)
    arm_r = right[0]
    elbow_r = right[1]

func _arm(shoulder: Vector3, mat: Material) -> Array:
    var sh := _node(self, shoulder)
    _mk(sh, CapsuleMesh.new(), Vector3(0, -0.5, 0), Vector3(0.045, 0.5, 0.045), mat)
    var el := _node(sh, Vector3(0, -1.0, 0))
    _mk(el, CapsuleMesh.new(), Vector3(0, -0.55, 0), Vector3(0.038, 0.55, 0.038), mat)
    var wrist := _node(el, Vector3(0, -1.1, 0))
    _mk(wrist, BoxMesh.new(), Vector3(0, -0.06, 0), Vector3(0.07, 0.12, 0.03), mat)
    for i in 5:
        var f1 := _node(wrist, Vector3((i - 2) * 0.016, -0.12, 0))
        f1.rotation_degrees = Vector3(12, 0, (i - 2) * 9.0)
        _mk(f1, CapsuleMesh.new(), Vector3(0, -0.14, 0), Vector3(0.009, 0.14, 0.009), mat)
        var f2 := _node(f1, Vector3(0, -0.28, 0))
        f2.rotation_degrees = Vector3(28, 0, 0)
        _mk(f2, CapsuleMesh.new(), Vector3(0, -0.11, 0), Vector3(0.007, 0.11, 0.007), mat)
    return [sh, el]

# ---------- AI ----------
func stop_for_attack():
    state = S.ATTACK
    set_physics_process(false)
    col.set_deferred("disabled", true)
    breath.stop()

func stun(t: float):
    if state == S.ATTACK:
        return
    stun_t = t
    _chase_audio(false)
    Game.play3d(Game.s_roar, global_position, 0.8, 55.0)

# a noise somewhere: investigate it (unless it can already see the player)
func hear(pos: Vector3):
    if stun_t > 0.0 or state == S.ATTACK:
        return
    if state == S.CHASE and lose_timer <= 0.0:
        return
    _chase_audio(false)
    state = S.INVESTIGATE
    target = _clamp(pos)
    leg_t = 14.0

func _chase_audio(on: bool):
    if on == chase_audio:
        return
    chase_audio = on
    breath.stream = Game.s_growl if on else Game.s_breath
    breath.play()
    Game.heart(on)

func _physics_process(delta):
    var p = Game.player
    if p == null or p.dead or Game.over or state == S.ATTACK:
        _animate(0.0, delta)
        return
    if stun_t > 0.0:
        stun_t -= delta
        velocity = Vector3(0, -2.0, 0)
        move_and_slide()
        anim_t += delta * 6.0
        head.rotation_degrees = Vector3(sin(anim_t) * 14.0, sin(anim_t * 1.7) * 30.0, sin(anim_t * 1.3) * 18.0)
        arm_l.rotation_degrees = Vector3(70.0 + sin(anim_t * 1.5) * 20.0, 0, 20)
        arm_r.rotation_degrees = Vector3(70.0 - sin(anim_t * 1.5) * 20.0, 0, -20)
        if stun_t <= 0.0:
            _begin_search(p.global_position, 10.0)
        return
    var pp: Vector3 = p.global_position
    var dist := _flat(pp)
    var sees := _can_see(dist, p)
    var spd := 0.0
    match state:
        S.IDLE:
            timer -= delta
            if sees:
                _begin_chase(pp)
            elif _hears(dist, p):
                _begin_investigate(pp)
            elif timer <= 0.0:
                _pick_patrol()
                state = S.PATROL
        S.PATROL:
            leg_t -= delta
            spd = _go(target, walk_speed, delta)
            if sees:
                _begin_chase(pp)
            elif _hears(dist, p):
                _begin_investigate(pp)
            elif _flat(target) < 1.5 or blocked or leg_t <= 0.0:
                blocked = false
                state = S.IDLE
                timer = randf_range(2.0, 4.5)
        S.INVESTIGATE:
            leg_t -= delta
            spd = _go(target, walk_speed * 1.5, delta)
            if sees:
                _begin_chase(pp)
            elif _flat(target) < 1.5 or blocked or leg_t <= 0.0:
                blocked = false
                _begin_search(target, 6.0)
        S.CHASE:
            if sees:
                last_known = pp
                lose_timer = 0.0
            else:
                lose_timer += delta
            spd = _go(last_known, chase_speed, delta)
            var ad := 3.4 if p.driving else attack_dist
            if not p.hidden and dist < ad and absf(pp.y - global_position.y) < 2.0:
                _begin_attack()
            elif lose_timer > lose_sight or (p.hidden and lose_timer > 1.0) or (not sees and _flat(last_known) < 1.5):
                _begin_search(last_known, 10.0)
        S.SEARCH:
            timer -= delta
            if sees:
                _begin_chase(pp)
            elif _hears(dist, p):
                _begin_investigate(pp)
            else:
                spd = _go(target, walk_speed, delta)
                if _flat(target) < 1.5 or blocked:
                    blocked = false
                    var r := Vector2.from_angle(randf() * TAU) * randf_range(0.0, 7.0)
                    target = _clamp(search_center + Vector3(r.x, 0, r.y))
                if p.hidden and dist < 3.5:
                    discover_t += delta
                    if discover_t >= 1.5:
                        discover_t = 0.0
                        if randf() < 0.3:
                            _begin_attack()
                if state == S.SEARCH and timer <= 0.0:
                    _pick_patrol()
                    state = S.PATROL
    _animate(spd, delta)

func _flat(p: Vector3) -> float:
    return Vector2(p.x - global_position.x, p.z - global_position.z).length()

func _clamp(v: Vector3) -> Vector3:
    return Vector3(clampf(v.x, -bounds, bounds), v.y, clampf(v.z, -bounds, bounds))

func _inside(p: Vector3, margin: float) -> bool:
    return absf(p.x) < 20.5 + margin and p.z > -12.5 - margin and p.z < 12.5 + margin

func _pick_patrol():
    leg_t = 30.0
    if randf() < 0.45 and Game.nav != null:
        var ids := Game.nav.get_point_ids()
        var tries := 0
        while tries < 12:
            tries += 1
            var pos := Game.nav.get_point_position(ids[randi() % ids.size()])
            if _inside(pos, -0.5):
                target = pos
                return
    for i in 20:
        var v := Vector3(randf_range(-bounds, bounds), 0.0, randf_range(-bounds, bounds))
        if not _inside(v, 3.0):
            target = v
            return
    target = Vector3(40, 0, 40)

func _hears(dist: float, p) -> bool:
    return not p.hidden and dist < p.noise_radius

func _can_see(dist: float, p) -> bool:
    if p.hidden:
        return false
    var rng := detect_range * (1.3 if (Game.has_torch and p.light_on) else 1.0)
    if p.crouching:
        rng *= 0.6
    if p.driving:
        rng *= 1.6
    if dist > rng:
        return false
    var fwd: Vector3 = -global_transform.basis.z
    var eye := global_position + Vector3.UP * 3.3 + fwd * 0.5
    var tgt: Vector3 = p.global_position + Vector3.UP * 1.2
    var to := tgt - eye
    if dist > 4.0 and absf(rad_to_deg(Vector2(fwd.x, fwd.z).angle_to(Vector2(to.x, to.z)))) > 70.0:
        return false
    var q := PhysicsRayQueryParameters3D.create(eye, tgt)
    q.exclude = [get_rid()]
    var hit := get_world_3d().direct_space_state.intersect_ray(q)
    if hit.is_empty():
        return true
    return hit["collider"] == p or hit["collider"] == p.car

func _begin_chase(pp: Vector3):
    if state != S.CHASE:
        Game.play3d(Game.s_roar, global_position, 1.0, 70.0)
    _chase_audio(true)
    state = S.CHASE
    lose_timer = 0.0
    last_known = pp

func _begin_investigate(pp: Vector3):
    _chase_audio(false)
    state = S.INVESTIGATE
    target = _clamp(pp)
    leg_t = 14.0

func _begin_search(c: Vector3, t: float):
    _chase_audio(false)
    state = S.SEARCH
    search_center = _clamp(c)
    target = search_center
    timer = t
    discover_t = 0.0

func _begin_attack():
    state = S.ATTACK
    Game.caught(self)

# next point to steer to: straight line outdoors, A* waypoint graph through the mansion
func _next_point(t: Vector3, delta: float) -> Vector3:
    var nav: AStar3D = Game.nav
    if nav == null:
        return t
    var me := global_position
    var me_in := _inside(me, 0.5)
    var t_in := _inside(t, 0.5)
    var entry := Vector3(0, 0, 24)
    if not me_in and not t_in and Vector2(me.x - entry.x, me.z - entry.z).length() > 6.0:
        path.clear()
        return t
    if t_in and not me_in and Vector2(me.x - entry.x, me.z - entry.z).length() > 8.0:
        path.clear()
        return entry
    repath_t -= delta
    if path.is_empty() or repath_t <= 0.0 or t.distance_to(path_goal) > 1.5:
        repath_t = 0.6
        path_goal = t
        var a := nav.get_closest_point(me)
        var b := nav.get_closest_point(t)
        path = Array(nav.get_point_path(a, b))
        path.append(t)
        path_i = 0
    while path_i < path.size() - 1 and Vector2(me.x - path[path_i].x, me.z - path[path_i].z).length() < 1.2 and absf(me.y - path[path_i].y) < 2.5:
        path_i += 1
    if not me_in and not t_in and path_i >= path.size() - 1:
        path.clear()
        return t
    return path[path_i]

func _go(tt: Vector3, speed: float, delta: float) -> float:
    var t := _next_point(tt, delta)
    var d := t - global_position
    d.y = 0.0
    if d.length() < 0.05:
        return 0.0
    var dir := d.normalized()
    if evade_t > 0.0:
        dir = dir.rotated(Vector3.UP, deg_to_rad(90.0 * evade_side))
        evade_t -= delta
    var tb := Basis.looking_at(dir, Vector3.UP)
    global_transform.basis = global_transform.basis.orthonormalized().slerp(tb, clampf(turn_speed * delta, 0.0, 1.0))
    var fwd: Vector3 = -global_transform.basis.z
    var align := clampf(fwd.dot(dir) * 1.5, 0.0, 1.0)
    var before := global_position
    velocity = Vector3(fwd.x * speed * align, -3.0, fwd.z * speed * align)
    move_and_slide()
    for i in get_slide_collision_count():
        var c := get_slide_collision(i)
        if absf(c.get_normal().y) < 0.5 and c.get_collider() != Game.player and evade_t <= 0.0:
            evade_t = 0.7
            evade_side = 1.0 if randf() < 0.5 else -1.0
    var moved := Vector2(global_position.x - before.x, global_position.z - before.z).length()
    if moved < speed * align * delta * 0.2:
        stuck_t += delta
    else:
        stuck_t = 0.0
    if stuck_t > 1.2:
        stuck_t = 0.0
        blocked = true
    return speed * align

func _animate(spd: float, delta: float):
    anim_t += delta * (1.0 + spd * 1.2)
    var base_a := 55.0 if state == S.CHASE else (20.0 if (state == S.INVESTIGATE or state == S.SEARCH) else 4.0)
    arm_base = lerpf(arm_base, base_a, delta * 3.0)
    var sw := sin(anim_t * 3.0) * clampf(spd * 6.0, 6.0, 28.0) if spd > 0.1 else sin(anim_t * 0.8) * 3.0
    arm_l.rotation_degrees = Vector3(arm_base + sw, 0, 4)
    arm_r.rotation_degrees = Vector3(arm_base - sw, 0, -4)
    var bend := 25.0 if state == S.CHASE else 12.0
    elbow_l.rotation_degrees.x = bend
    elbow_r.rotation_degrees.x = bend
    skirt.rotation = Vector3(sin(anim_t * 0.9) * 0.03, 0, sin(anim_t * 1.1) * 0.03)
    var yaw_amp := 35.0 if (state == S.IDLE or state == S.SEARCH) else 8.0
    head.rotation_degrees = Vector3(sin(anim_t * 0.3) * 6.0, sin(anim_t * 0.45) * yaw_amp, sin(anim_t * 0.25) * 8.0)
    for i in strands.size():
        var s: Node3D = strands[i]
        s.rotation = Vector3(sin(anim_t * 1.3 + i) * 0.08, 0, cos(anim_t * 1.1 + i * 0.7) * 0.08)
