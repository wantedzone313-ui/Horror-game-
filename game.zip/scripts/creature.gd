extends CharacterBody3D
# "The Smiler": tall thin creature. States: Idle, Patrol, Investigate, Chase, Search, Attack.
# Placeholder model built from primitives. Faces -Z.

enum S { IDLE, PATROL, INVESTIGATE, CHASE, SEARCH, ATTACK }

var state = S.PATROL
var walk_speed := 1.5
var chase_speed := 4.3
var detect_range := 18.0
var lose_sight := 5.0
var attack_dist := 1.8
var turn_speed := 3.0
var bounds := 85.0

var arm_l: Node3D
var arm_r: Node3D
var leg_l: Node3D
var leg_r: Node3D
var head: Node3D
var col: CollisionShape3D
var breath: AudioStreamPlayer3D
var target := Vector3.ZERO
var last_known := Vector3.ZERO
var search_center := Vector3.ZERO
var timer := 0.0
var lose_timer := 0.0
var discover_t := 0.0
var stuck_t := 0.0
var evade_t := 0.0
var evade_side := 1.0
var anim_t := 0.0
var arm_base := 0.0
var blocked := false

func _ready():
    _build()
    _pick_patrol()
    breath = AudioStreamPlayer3D.new()
    breath.stream = Game.s_breath
    breath.max_distance = 28.0
    breath.unit_size = 4.0
    add_child(breath)
    breath.play()

# ---------- model ----------
func _mat(c: Color, glow := false) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    if glow:
        m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    else:
        m.roughness = 1.0
    return m

func _mk(parent: Node3D, mesh: Mesh, pos: Vector3, scl: Vector3, mat: Material) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    mi.position = pos
    mi.scale = scl
    mi.material_override = mat
    parent.add_child(mi)
    return mi

func _limb(pivot_pos: Vector3, mat: Material, scl: Vector3, y_off: float) -> Node3D:
    var p := Node3D.new()
    p.position = pivot_pos
    add_child(p)
    _mk(p, CapsuleMesh.new(), Vector3(0, y_off, 0), scl, mat)
    return p

func _build():
    var skin := _mat(Color(0.015, 0.015, 0.018))
    var hair := _mat(Color(0.005, 0.005, 0.006))
    var white := _mat(Color.WHITE, true)
    col = CollisionShape3D.new()
    var cs := CapsuleShape3D.new()
    cs.radius = 0.35
    cs.height = 3.2
    col.shape = cs
    col.position = Vector3(0, 1.6, 0)
    add_child(col)
    _mk(self, CapsuleMesh.new(), Vector3(0, 2.0, 0), Vector3(0.42, 0.85, 0.26), skin)
    leg_l = _limb(Vector3(-0.14, 1.15, 0), skin, Vector3(0.14, 0.55, 0.14), -0.55)
    leg_r = _limb(Vector3(0.14, 1.15, 0), skin, Vector3(0.14, 0.55, 0.14), -0.55)
    head = Node3D.new()
    head.position = Vector3(0, 3.0, 0)
    add_child(head)
    _mk(head, SphereMesh.new(), Vector3.ZERO, Vector3(0.42, 0.5, 0.4), skin)
    _mk(head, CapsuleMesh.new(), Vector3(0, -0.45, 0.12), Vector3(0.55, 1.0, 0.3), hair)
    _mk(head, CapsuleMesh.new(), Vector3(-0.24, -0.5, 0.0), Vector3(0.1, 0.9, 0.12), hair)
    _mk(head, CapsuleMesh.new(), Vector3(0.24, -0.5, 0.0), Vector3(0.1, 0.9, 0.12), hair)
    _mk(head, SphereMesh.new(), Vector3(-0.1, 0.05, -0.19), Vector3.ONE * 0.07, white)
    _mk(head, SphereMesh.new(), Vector3(0.1, 0.05, -0.19), Vector3.ONE * 0.07, white)
    for i in 9:
        var x := (i - 4) * 0.028
        var y := -0.13 + (i - 4) * (i - 4) * 0.0035
        _mk(head, BoxMesh.new(), Vector3(x, y, -0.18), Vector3(0.014, 0.04, 0.01), white)
    var gl := OmniLight3D.new()
    gl.omni_range = 5.0
    gl.light_energy = 0.5
    gl.position = Vector3(0, 0.05, -0.4)
    head.add_child(gl)
    arm_l = _arm(Vector3(-0.3, 2.7, 0), skin)
    arm_r = _arm(Vector3(0.3, 2.7, 0), skin)

func _arm(shoulder: Vector3, mat: Material) -> Node3D:
    var p := _limb(shoulder, mat, Vector3(0.06, 0.75, 0.06), -0.75)
    for i in 4:
        var f := Node3D.new()
        f.position = Vector3(0, -1.45, 0)
        f.rotation_degrees.z = (i - 1.5) * 14.0
        p.add_child(f)
        _mk(f, CapsuleMesh.new(), Vector3(0, -0.2, 0), Vector3(0.015, 0.22, 0.015), mat)
    return p

# ---------- AI ----------
func stop_for_attack():
    state = S.ATTACK
    set_physics_process(false)
    col.set_deferred("disabled", true)
    breath.stop()

func _physics_process(delta):
    var p = Game.player
    if p == null or p.dead or Game.over or state == S.ATTACK:
        _animate(0.0, delta)
        return
    var pp: Vector3 = p.global_position
    var dist := _flat(pp)
    var sees := _can_see(dist, p)
    var spd := 0.0
    match state:
        S.IDLE:
            timer -= delta
            if sees:
                _begin_chase(pp)
            elif _hears(dist, p):
                _begin_investigate(pp)
            elif timer <= 0.0:
                _pick_patrol()
                state = S.PATROL
        S.PATROL:
            spd = _go(target, walk_speed, delta)
            if sees:
                _begin_chase(pp)
            elif _hears(dist, p):
                _begin_investigate(pp)
            elif _flat(target) < 1.5 or blocked:
                blocked = false
                state = S.IDLE
                timer = randf_range(2.0, 4.5)
        S.INVESTIGATE:
            spd = _go(target, walk_speed * 1.5, delta)
            if sees:
                _begin_chase(pp)
            elif _flat(target) < 1.5 or blocked:
                blocked = false
                _begin_search(target, 6.0)
        S.CHASE:
            if sees:
                last_known = pp
                lose_timer = 0.0
            else:
                lose_timer += delta
            spd = _go(last_known, chase_speed, delta)
            if not p.hidden and dist < attack_dist and absf(pp.y - global_position.y) < 1.5:
                _begin_attack()
            elif lose_timer > lose_sight or (p.hidden and lose_timer > 1.0) or (not sees and _flat(last_known) < 1.5):
                _begin_search(last_known, 10.0)
        S.SEARCH:
            timer -= delta
            if sees:
                _begin_chase(pp)
            elif _hears(dist, p):
                _begin_investigate(pp)
            else:
                spd = _go(target, walk_speed, delta)
                if _flat(target) < 1.5 or blocked:
                    blocked = false
                    var r := Vector2.from_angle(randf() * TAU) * randf_range(0.0, 7.0)
                    target = _clamp(search_center + Vector3(r.x, 0, r.y))
                if p.hidden and dist < 3.5:
                    discover_t += delta
                    if discover_t >= 1.5:
                        discover_t = 0.0
                        if randf() < 0.3:
                            _begin_attack()
                if state == S.SEARCH and timer <= 0.0:
                    _pick_patrol()
                    state = S.PATROL
    _animate(spd, delta)

func _flat(p: Vector3) -> float:
    return Vector2(p.x - global_position.x, p.z - global_position.z).length()

func _clamp(v: Vector3) -> Vector3:
    return Vector3(clampf(v.x, -bounds, bounds), 0.0, clampf(v.z, -bounds, bounds))

func _pick_patrol():
    target = Vector3(randf_range(-bounds, bounds), 0.0, randf_range(-bounds, bounds))

func _hears(dist: float, p) -> bool:
    return not p.hidden and dist < p.noise_radius

func _can_see(dist: float, p) -> bool:
    if p.hidden:
        return false
    var rng := detect_range * (1.3 if p.light_on else 1.0)
    if p.crouching:
        rng *= 0.6
    if dist > rng:
        return false
    var fwd: Vector3 = -global_transform.basis.z
    var eye := global_position + Vector3.UP * 2.9 + fwd * 0.5
    var tgt: Vector3 = p.global_position + Vector3.UP * 1.2
    var to := tgt - eye
    if dist > 4.0 and absf(rad_to_deg(Vector2(fwd.x, fwd.z).angle_to(Vector2(to.x, to.z)))) > 70.0:
        return false
    var q := PhysicsRayQueryParameters3D.create(eye, tgt)
    q.exclude = [get_rid()]
    var hit := get_world_3d().direct_space_state.intersect_ray(q)
    if hit.is_empty():
        return true
    return hit["collider"] == p

func _begin_chase(pp: Vector3):
    if state != S.CHASE:
        Game.play2d(Game.s_scare, 0.22)
    state = S.CHASE
    lose_timer = 0.0
    last_known = pp

func _begin_investigate(pp: Vector3):
    state = S.INVESTIGATE
    target = _clamp(pp)

func _begin_search(c: Vector3, t: float):
    state = S.SEARCH
    search_center = _clamp(c)
    target = search_center
    timer = t
    discover_t = 0.0

func _begin_attack():
    state = S.ATTACK
    Game.caught(self)

func _go(t: Vector3, speed: float, delta: float) -> float:
    var d := t - global_position
    d.y = 0.0
    if d.length() < 0.05:
        return 0.0
    var dir := d.normalized()
    if evade_t > 0.0:
        dir = dir.rotated(Vector3.UP, deg_to_rad(90.0 * evade_side))
        evade_t -= delta
    var tb := Basis.looking_at(dir, Vector3.UP)
    global_transform.basis = global_transform.basis.orthonormalized().slerp(tb, clampf(turn_speed * delta, 0.0, 1.0))
    var fwd: Vector3 = -global_transform.basis.z
    var align := clampf(fwd.dot(dir) * 1.5, 0.0, 1.0)
    var before := global_position
    velocity = Vector3(fwd.x * speed * align, -2.0, fwd.z * speed * align)
    move_and_slide()
    for i in get_slide_collision_count():
        var c := get_slide_collision(i)
        if absf(c.get_normal().y) < 0.5 and c.get_collider() != Game.player and evade_t <= 0.0:
            evade_t = 0.7
            evade_side = 1.0 if randf() < 0.5 else -1.0
    if (global_position - before).length() < speed * align * delta * 0.2:
        stuck_t += delta
    else:
        stuck_t = 0.0
    if stuck_t > 1.2:
        stuck_t = 0.0
        blocked = true
    return speed * align

func _animate(spd: float, delta: float):
    anim_t += delta * (1.0 + spd * 1.2)
    var base_a := 55.0 if state == S.CHASE else (20.0 if (state == S.INVESTIGATE or state == S.SEARCH) else 4.0)
    arm_base = lerpf(arm_base, base_a, delta * 3.0)
    var sw := sin(anim_t * 3.0) * clampf(spd * 6.0, 6.0, 28.0) if spd > 0.1 else sin(anim_t * 0.8) * 3.0
    arm_l.rotation_degrees = Vector3(arm_base + sw, 0, 4)
    arm_r.rotation_degrees = Vector3(arm_base - sw, 0, -4)
    leg_l.rotation_degrees.x = -sw if spd > 0.1 else 0.0
    leg_r.rotation_degrees.x = sw if spd > 0.1 else 0.0
    var yaw_amp := 35.0 if (state == S.IDLE or state == S.SEARCH) else 8.0
    head.rotation_degrees = Vector3(sin(anim_t * 0.3) * 6.0, sin(anim_t * 0.45) * yaw_amp, sin(anim_t * 0.25) * 8.0)
