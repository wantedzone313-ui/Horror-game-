extends CharacterBody3D
# First-person player: move, look, crouch, sprint, torch (must be found), rifle, throwing cans, hiding in lockers, driving.

const WALK := 2.6
const RUN := 4.8
const CROUCH_SPEED := 1.3
const LOOK_SENS := 0.0035
const BASE_ENERGY := 14.0

const CanScript = preload("res://scripts/thrown_can.gd")
const Assets = preload("res://scripts/assets.gd")

var cam: Camera3D
var light: SpotLight3D
var muzzle: OmniLight3D
var torch_vm: Node3D
var gun_vm: Node3D
var col: CollisionShape3D
var capsule: CapsuleShape3D
var health := 100.0
var dead := false
var hidden := false
var driving := false
var car = null
var crouching := false
var noise_radius := 0.5
var battery := 100.0
var light_on := true
var busy := false
var pitch := 0.0
var yaw_off := 0.0
var pitch_off := 0.0
var base_yaw := 0.0
var near = null
var hide_spot = null
var hide_cam_base := Vector3.ZERO
var scan_t := 0.0
var step_t := 0.0
var bob_t := 0.0
var ui_t := 0.0
var gun_cd := 0.0

func _ready():
    Game.player = self
    capsule = CapsuleShape3D.new()
    capsule.radius = 0.35
    capsule.height = 1.8
    col = CollisionShape3D.new()
    col.shape = capsule
    col.position.y = 0.9
    add_child(col)
    cam = Camera3D.new()
    cam.position = Vector3(0, 1.65, 0)
    cam.fov = 70.0
    cam.far = 150.0
    add_child(cam)
    cam.make_current()
    light = SpotLight3D.new()
    light.spot_range = 38.0
    light.spot_angle = 38.0
    light.spot_attenuation = 0.6
    light.light_energy = BASE_ENERGY
    light.light_color = Color(1, 0.95, 0.8)
    light.shadow_enabled = true
    light.position = Vector3(0.2, -0.15, -0.2)
    light.visible = false
    cam.add_child(light)
    var fill := OmniLight3D.new()
    fill.omni_range = 6.0
    fill.light_energy = 0.12
    fill.light_color = Color(0.55, 0.65, 0.85)
    fill.position = Vector3(0, 1.4, 0)
    add_child(fill)
    muzzle = OmniLight3D.new()
    muzzle.omni_range = 9.0
    muzzle.light_energy = 3.0
    muzzle.light_color = Color(1.0, 0.8, 0.5)
    muzzle.position = Vector3(-0.2, -0.2, -0.9)
    muzzle.visible = false
    cam.add_child(muzzle)
    torch_vm = _make_torch_vm()
    gun_vm = _make_gun_vm()
    torch_vm.visible = false
    gun_vm.visible = false
    Game.ui.set_health(1.0)
    Game.ui.refresh_inventory()
    refresh_battery()

func _make_torch_vm() -> Node3D:
    var t := Node3D.new()
    var bm := StandardMaterial3D.new()
    bm.albedo_color = Color(0.06, 0.06, 0.07)
    bm.metallic = 0.7
    bm.roughness = 0.4
    var body := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 0.035
    cm.bottom_radius = 0.03
    cm.height = 0.3
    body.mesh = cm
    body.material_override = bm
    body.rotation_degrees.x = 90.0
    t.add_child(body)
    var head := MeshInstance3D.new()
    var hm := CylinderMesh.new()
    hm.top_radius = 0.065
    hm.bottom_radius = 0.037
    hm.height = 0.1
    head.mesh = hm
    head.material_override = bm
    head.rotation_degrees.x = 90.0
    head.position = Vector3(0, 0, -0.2)
    t.add_child(head)
    t.position = Vector3(-0.3, -0.27, -0.5)
    t.rotation_degrees = Vector3(0, 8, 0)
    Assets.on_top(t)
    cam.add_child(t)
    return t

func _make_gun_vm() -> Node3D:
    var holder := Node3D.new()
    var g := Assets.load_model("gun")
    if g != null:
        g.scale = Vector3.ONE * 0.62
        g.position = Vector3(0, 0, 0)
        holder.add_child(g)
        Assets.on_top(g)
    holder.position = Vector3(0.3, -0.34, -0.55)
    holder.rotation_degrees = Vector3(0, -6, 0)
    cam.add_child(holder)
    return holder

func get_torch():
    torch_vm.visible = true
    light_on = true
    refresh_battery()

func get_gun():
    gun_vm.visible = true

func _input(event):
    if event is InputEventKey and event.pressed and not event.echo:
        match event.keycode:
            KEY_F:
                Game.ui.pressed["flash"] = true
            KEY_E:
                Game.ui.pressed["action"] = true
            KEY_C:
                Game.ui.pressed["crouch"] = true
            KEY_I:
                Game.ui.pressed["bag"] = true
            KEY_SPACE:
                Game.ui.pressed["fire"] = true
            KEY_G:
                Game.ui.pressed["throw"] = true

func _kb() -> Vector2:
    var v := Vector2.ZERO
    if Input.is_key_pressed(KEY_W):
        v.y += 1
    if Input.is_key_pressed(KEY_S):
        v.y -= 1
    if Input.is_key_pressed(KEY_A):
        v.x -= 1
    if Input.is_key_pressed(KEY_D):
        v.x += 1
    return v

func _physics_process(delta):
    if dead or Game.over:
        return
    var ui = Game.ui
    gun_cd = maxf(0.0, gun_cd - delta)
    if ui.take("flash"):
        toggle_light()
    if ui.take("bag"):
        ui.toggle_inventory()
    if ui.take("fire") and Game.has_gun:
        fire()
    if ui.take("throw"):
        throw_can()
    _battery(delta)
    if busy:
        return
    if driving:
        _drive_update()
        return
    if hidden:
        _hidden_update()
        return
    _look()
    _move(delta)
    scan_t -= delta
    if scan_t <= 0.0:
        scan_t = 0.1
        _scan()
    if ui.take("action") and near != null:
        var it = near
        near = null
        ui.set_action("")
        it.interact(self)

func _look():
    var l: Vector2 = Game.ui.take_look()
    rotation.y -= l.x * LOOK_SENS
    pitch = clampf(pitch - l.y * LOOK_SENS, -1.4, 1.4)
    cam.rotation.x = pitch

func _move(delta):
    var m: Vector2 = (Game.ui.move + _kb()).limit_length(1.0)
    if Game.ui.take("crouch"):
        crouching = not crouching
    var sprinting: bool = (Game.ui.sprint or Input.is_key_pressed(KEY_SHIFT)) and not crouching and m.y > 0.1
    var sp := CROUCH_SPEED if crouching else (RUN if sprinting else WALK)
    var dir: Vector3 = (transform.basis.x * m.x + (-transform.basis.z) * m.y) * sp
    velocity.x = dir.x
    velocity.z = dir.z
    velocity.y -= 18.0 * delta
    if is_on_floor():
        velocity.y = maxf(velocity.y, -1.0)
    move_and_slide()
    var h := lerpf(capsule.height, 1.1 if crouching else 1.8, delta * 8.0)
    capsule.height = h
    col.position.y = h / 2.0
    var moving := m.length_squared() > 0.05
    noise_radius = 0.5 if not moving else (3.0 if crouching else (14.0 if sprinting else 7.0))
    if moving:
        bob_t += delta * (11.0 if sprinting else 7.0)
    var cy := (0.95 if crouching else 1.65) + (sin(bob_t) * 0.035 if moving else 0.0)
    cam.position.y = lerpf(cam.position.y, cy, delta * 10.0)
    cam.position.z = 0.0
    if moving:
        step_t -= delta * (1.7 if sprinting else 1.0) * (0.6 if crouching else 1.0)
        if step_t <= 0.0:
            step_t = 0.55
            Game.play2d(Game.s_step, 0.15 if crouching else 0.4)

func _scan():
    var best = null
    var bd := 99.0
    var c := global_position
    for n in get_tree().get_nodes_in_group("interactable"):
        var reach: float = n.reach if "reach" in n else 2.0
        var d := Vector2(c.x - n.global_position.x, c.z - n.global_position.z).length()
        if d < reach and d < bd and absf(c.y + 0.9 - n.global_position.y) < 2.4:
            bd = d
            best = n
    if best != near:
        near = best
        Game.ui.set_action(near.prompt() if near != null else "")

# ---------- weapons ----------
func fire():
    if gun_cd > 0.0:
        return
    if Game.ammo <= 0:
        Game.toast("Out of ammo.")
        gun_cd = 0.4
        return
    gun_cd = 0.4
    Game.ammo -= 1
    Game.play2d(Game.s_shot, 1.0)
    muzzle.visible = true
    get_tree().create_timer(0.07).timeout.connect(func(): muzzle.visible = false)
    var tw := create_tween()
    tw.tween_property(gun_vm, "position:z", -0.45, 0.05)
    tw.tween_property(gun_vm, "position:z", -0.55, 0.15)
    var from := cam.global_position
    var to := from + (-cam.global_transform.basis.z) * 70.0
    var q := PhysicsRayQueryParameters3D.create(from, to)
    q.exclude = [get_rid()]
    var hit := get_world_3d().direct_space_state.intersect_ray(q)
    if not hit.is_empty() and hit["collider"].has_method("stun"):
        hit["collider"].stun(6.0)
        Game.toast("Direct hit! It is stunned.")
    Game.alert_noise(global_position, 60.0)
    Game.ui.refresh_inventory()

func throw_can():
    if Game.throwables <= 0:
        return
    Game.throwables -= 1
    var c := CanScript.new()
    get_parent().add_child(c)
    var fwd: Vector3 = -cam.global_transform.basis.z
    c.global_position = cam.global_position + fwd * 0.6
    c.linear_velocity = fwd * 12.0 + Vector3.UP * 3.0
    Game.ui.refresh_inventory()

# ---------- driving ----------
func enter_car(c):
    driving = true
    car = c
    col.set_deferred("disabled", true)
    velocity = Vector3.ZERO
    yaw_off = 0.0
    pitch_off = 0.0
    crouching = false
    capsule.height = 1.8
    Game.ui.set_action("exit")
    Game.toast("Drive: joystick up = gas, down = brake, sideways = steer")

func _drive_update():
    var l: Vector2 = Game.ui.take_look()
    yaw_off = clampf(yaw_off - l.x * LOOK_SENS, -1.5, 1.5)
    pitch_off = clampf(pitch_off - l.y * LOOK_SENS, -0.6, 0.6)
    global_position = car.global_position
    rotation.y = car.rotation.y + yaw_off
    cam.rotation.x = pitch_off
    cam.position = Vector3(-0.35, 0.95, 0.2)
    noise_radius = 38.0 if absf(car.speed) > 1.0 else 6.0
    if Game.ui.take("action"):
        exit_car()

func exit_car():
    var c = car
    driving = false
    car = null
    c.release()
    var side: Vector3 = -c.global_transform.basis.x * 2.4
    global_position = c.global_position + side
    global_position.y = c.global_position.y + 0.1
    rotation.y = c.rotation.y
    pitch = 0.0
    col.set_deferred("disabled", false)
    cam.position = Vector3(0, 1.65, 0)
    near = null
    Game.ui.set_action("")

# ---------- hiding (lockers) ----------
func enter_hide(s):
    hide_spot = s
    _hide_routine(s, true)

func _hide_routine(s, enter: bool):
    busy = true
    velocity = Vector3.ZERO
    col.set_deferred("disabled", true)
    Game.ui.set_action("")
    if s.door != null:
        s.set_door(true)
        await get_tree().create_timer(0.45).timeout
    var tpos: Vector3
    var tyaw: float
    var tpitch := 0.0
    if enter:
        hidden = true
        tpos = s.cam_pos - Vector3(0, cam.position.y, 0)
        tyaw = deg_to_rad(s.cam_yaw)
    else:
        hidden = false
        pitch = pitch_off
        yaw_off = 0.0
        pitch_off = 0.0
        tpos = s.exit_pos
        tyaw = deg_to_rad(s.exit_yaw)
        tpitch = clampf(pitch, -0.5, 0.5)
    var tw := create_tween().set_parallel(true).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    tw.tween_property(self, "global_position", tpos, 0.7)
    tw.tween_property(self, "rotation:y", lerp_angle(rotation.y, tyaw, 1.0), 0.7)
    tw.tween_property(cam, "rotation:x", tpitch, 0.7)
    await tw.finished
    if s.door != null:
        s.set_door(false)
    if enter:
        hide_cam_base = cam.position
        base_yaw = rotation.y
        Game.ui.set_action("exit")
    else:
        col.set_deferred("disabled", false)
        crouching = false
        hide_spot = null
        near = null
        pitch = cam.rotation.x
    busy = false

func _hidden_update():
    var l: Vector2 = Game.ui.take_look()
    yaw_off = clampf(yaw_off - l.x * LOOK_SENS * 0.5, -0.6, 0.6)
    pitch_off = clampf(pitch_off - l.y * LOOK_SENS * 0.5, -0.35, 0.35)
    rotation.y = base_yaw + yaw_off
    cam.rotation.x = pitch_off
    var t := Time.get_ticks_msec()
    cam.position = hide_cam_base + Vector3(sin(t * 0.0009) * 0.008, sin(t * 0.0017) * 0.01, 0.0)
    noise_radius = 0.0
    if Game.ui.take("action"):
        _hide_routine(hide_spot, false)

# ---------- torch / health ----------
func _battery(delta):
    if not Game.has_torch:
        light.visible = false
        return
    if light_on:
        battery -= 0.35 * delta
        if battery <= 0.0:
            battery = 0.0
            light_on = false
            Game.toast("Torch died.")
            if Game.batteries > 0:
                replace_battery()
    light.visible = light_on
    var k := 1.0
    if light_on and battery < 15.0:
        k = 0.15 if randf() < 0.12 else 0.85
    light.light_energy = BASE_ENERGY * k
    ui_t -= delta
    if ui_t <= 0.0:
        ui_t = 0.25
        refresh_battery()

func toggle_light():
    if not Game.has_torch:
        Game.toast("You don't have a torch yet.")
        return
    if not light_on and battery <= 0.0:
        Game.toast("Battery empty.")
        if Game.batteries > 0:
            replace_battery()
        return
    light_on = not light_on
    Game.play2d(Game.s_click, 0.7)
    refresh_battery()

func replace_battery():
    if Game.batteries <= 0:
        Game.toast("No spare batteries.")
        return
    if battery > 90.0:
        Game.toast("Battery is still fresh.")
        return
    Game.batteries -= 1
    battery = 100.0
    light_on = true
    Game.play2d(Game.s_click, 0.8)
    Game.toast("Battery replaced.")
    Game.ui.refresh_inventory()
    refresh_battery()

func refresh_battery():
    Game.ui.set_battery(battery, light_on)

func heal(a: float):
    health = minf(100.0, health + a)
    Game.ui.set_health(health / 100.0)

func use_medkit():
    if Game.medkits <= 0:
        Game.toast("No medkits.")
        return
    if health >= 100.0:
        Game.toast("Health is full.")
        return
    Game.medkits -= 1
    heal(50.0)
    Game.toast("Used medkit (+50)")
    Game.ui.refresh_inventory()
