extends RigidBody3D
# Thrown tin can: clangs loudly on impact and distracts the creature.

var hit_done := false

func _ready():
    mass = 0.4
    contact_monitor = true
    max_contacts_reported = 4
    var cs := CollisionShape3D.new()
    var sh := CylinderShape3D.new()
    sh.radius = 0.06
    sh.height = 0.14
    cs.shape = sh
    add_child(cs)
    var mi := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 0.06
    cm.bottom_radius = 0.06
    cm.height = 0.14
    cm.radial_segments = 10
    mi.mesh = cm
    var m := StandardMaterial3D.new()
    m.albedo_color = Color(0.45, 0.2, 0.12)
    m.metallic = 0.6
    m.roughness = 0.5
    mi.material_override = m
    add_child(mi)
    body_entered.connect(_on_hit)
    get_tree().create_timer(12.0).timeout.connect(queue_free)

func _on_hit(_b):
    if hit_done:
        return
    hit_done = true
    Game.play3d(Game.s_clang, global_position, 1.0, 45.0)
    Game.alert_noise(global_position, 40.0)
