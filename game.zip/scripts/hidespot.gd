extends Node3D
# Interactable hiding place (locker). cam_pos = camera while hidden, exit_pos = where the player stands after leaving. Yaw in degrees (0 faces -Z).
# Optional "door" pivot swings open and closed around the hide/exit animation.

var cam_pos := Vector3.ZERO
var cam_yaw := 0.0
var exit_pos := Vector3.ZERO
var exit_yaw := 0.0
var door: Node3D = null
var tw: Tween

func _ready():
    add_to_group("interactable")

func prompt() -> String:
    return "hide"

func interact(p):
    p.enter_hide(self)

func set_door(open: bool):
    if door == null:
        return
    if tw:
        tw.kill()
    tw = create_tween()
    tw.tween_property(door, "rotation_degrees:y", -105.0 if open else 0.0, 0.4).set_trans(Tween.TRANS_SINE)
    Game.play3d(Game.s_creak, global_position, 0.35, 15.0)
