extends Node3D
# Interactable hiding place. cam_pos = where the camera sits while hidden, exit_pos = where the player stands after leaving. Yaw in degrees (0 faces -Z).

var cam_pos := Vector3.ZERO
var cam_yaw := 0.0
var exit_pos := Vector3.ZERO
var exit_yaw := 0.0

func _ready():
    add_to_group("interactable")

func prompt() -> String:
    return "HIDE"

func interact(p):
    p.enter_hide(self)
