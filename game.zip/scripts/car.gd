extends CharacterBody3D
# Drivable arcade car. Front is -Z. Needs petrol (find a petrol can). Joystick: up = gas, down = brake/reverse, left/right = steer.

var speed := 0.0
var fuel := 0.0
var driver = null
var reach := 3.8
var engine: AudioStreamPlayer3D

func _ready():
    add_to_group("interactable")
    var cs := CollisionShape3D.new()
    var sh := BoxShape3D.new()
    sh.size = Vector3(1.9, 1.5, 4.8)
    cs.shape = sh
    cs.position = Vector3(0, 0.8, 0)
    add_child(cs)
    engine = AudioStreamPlayer3D.new()
    engine.stream = Game.s_engine
    engine.max_distance = 60.0
    engine.unit_size = 8.0
    add_child(engine)

func prompt() -> String:
    return "drive" if fuel > 0.0 else "refuel"

func interact(p):
    if fuel <= 0.0:
        if Game.fuel_cans > 0:
            Game.fuel_cans -= 1
            fuel = 100.0
            Game.toast("Car refueled. Tap again to drive.")
            Game.ui.refresh_inventory()
        else:
            Game.toast("No fuel. Find a petrol can.")
        return
    driver = p
    engine.play()
    p.enter_car(self)

func release():
    driver = null
    engine.stop()

func _kb() -> Vector2:
    var v := Vector2.ZERO
    if Input.is_key_pressed(KEY_W):
        v.y += 1
    if Input.is_key_pressed(KEY_S):
        v.y -= 1
    if Input.is_key_pressed(KEY_A):
        v.x -= 1
    if Input.is_key_pressed(KEY_D):
        v.x += 1
    return v

func _physics_process(delta):
    var thr := 0.0
    var st := 0.0
    if driver != null and not Game.over:
        var m: Vector2 = Game.ui.move + _kb()
        thr = clampf(m.y, -1.0, 1.0)
        st = clampf(m.x, -1.0, 1.0)
        if fuel <= 0.0:
            thr = minf(thr, 0.0)
    if thr > 0.05:
        speed += thr * 9.0 * delta
        fuel = maxf(0.0, fuel - delta * 1.2)
        if fuel <= 0.0 and driver != null:
            Game.toast("Out of fuel!")
    elif thr < -0.05:
        speed += thr * 12.0 * delta
    else:
        speed = move_toward(speed, 0.0, 3.0 * delta)
    speed = clampf(speed, -5.0, 15.0)
    if absf(speed) > 0.3:
        rotation.y -= st * 1.5 * delta * clampf(speed / 5.0, -1.0, 1.0)
    var vy := -1.0 if is_on_floor() else velocity.y - 18.0 * delta
    var fwd: Vector3 = -global_transform.basis.z
    velocity = Vector3(fwd.x * speed, vy, fwd.z * speed)
    move_and_slide()
    for i in get_slide_collision_count():
        var c := get_slide_collision(i)
        var o = c.get_collider()
        if o != null and o.has_method("stun"):
            if absf(speed) > 5.0:
                o.stun(5.0)
                Game.toast("You hit it!")
                speed *= 0.4
        elif absf(c.get_normal().y) < 0.5:
            speed *= 0.6
    if driver != null:
        engine.pitch_scale = 0.8 + absf(speed) * 0.07
